/***************************************************************************
 * Copyright 2001-2007 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.crawl.io.dowloaded;

import org.vietspider.crawl.link.Link;
import org.vietspider.io.CrawlerConfig;
import org.vietspider.je.codes.Md5UrlDatabases;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Dec 25, 2007  
 */
public final class SimpleMd5TitleDatabases extends Md5UrlDatabases {

  SimpleMd5TitleDatabases(String group) throws Exception {
    super("track/title/" + group, "title", 
        group, 1*24*60*60*1000, Math.min(CrawlerConfig.EXPIRE_DATE, 2), 3*1024*1024);
  }

//  public boolean isEmptyTemp() { return codes.isEmpty(); }

  public void write(Link link) throws Throwable {
    super.write(link.getTitleId(), 1);
  }

  public boolean search(Link link) throws Throwable {
    if(isClose()) return true;
    if(link.getTitleId() == null) return false;
    int value = super.read(link.getTitleId());
    if(value != -1) {
//    System.out.println(" da thay link bi download "+ link.getAddress());
      return true;
    }
   return false;
  }

}
