/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.         *
 **************************************************************************/
package org.vietspider.crawl.io.dowloaded;

import java.io.File;
import java.io.FileFilter;
import java.util.Calendar;

import org.vietspider.common.Application;
import org.vietspider.common.io.ConcurrentSetInt;
import org.vietspider.common.io.ConcurrentSetIntFile;
import org.vietspider.common.io.DataOfDay;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.io.codes.CacheCodesLoader;
import org.vietspider.io.codes.CodesTracker;
import org.vietspider.io.codes.FileCodesReader;
import org.vietspider.io.codes.FileCodesWriter;
/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 26, 2008  
 */
public final class FileDownloadedTracker extends CodesTracker<ConcurrentSetInt> {
  
  private ConcurrentSetInt codes;
  private File folder = null;
  
  private FileCodesReader reader;
  
  private int date = -1;
  private CacheCode cacheCode;
  
  public FileDownloadedTracker(String path) {
    this(UtilFile.getFolder(path));
  }
  
  public FileDownloadedTracker(File folder_) {
    this.folder = folder_;  
    codes = new ConcurrentSetIntFile();
    reader = new FileCodesReader();
    writer = new FileCodesWriter();
    cacheCode = new CacheCode(folder);
    
    Application.addShutdown(new Application.IShutdown() {
      
      public String getMessage() {
        if(folder != null) {
          System.out.println(folder.getAbsolutePath());
        }
        return getClass().getName(); 
      }
      
      public void execute() {
        execute = false;
        if(cacheCode != null) cacheCode.exit();
        
        System.out.println(" == > "+ folder.getAbsolutePath());
        
        if(codes.size() < 1) return;
        
        File tempFile = new File(folder, "codes.temp2");
        System.out.println(" prepare save temp file " + tempFile.getAbsolutePath() + " at " + Calendar.getInstance().getTime());
        saveTemp(folder, "codes.temp2", codes);
        System.out.println(" finish save temp file " + tempFile.getAbsolutePath() + " at " + Calendar.getInstance().getTime());
      }
    });

    Calendar calendar = Calendar.getInstance();
    date = calendar.get(Calendar.DAY_OF_MONTH);
    
    CacheCodesLoader codeLoader = new CacheCodesLoader();
    
    File f = new File(folder, "codes.temp");
    if(f.exists())  {
      codeLoader.load(f, codes);
      f.delete();
    }
    
    f = new File(folder, "codes.temp2");
    if(f.exists())  {
      codeLoader.load(f, codes);
      f.delete();
    }
    
    new Thread(this).start();
  }
  
  public void run() {
    while(execute) {
      synchronizeReader();
      synchronizedWriter();
      
      if(codes.size() > 0) {
//        SimpleDateFormat dateFormat = CalendarUtils.getFolderFormat();
//        File f = new File(folder, dateFormat.format(Calendar.getInstance().getTime()));
        File f = new File(folder, DataOfDay.getDateFoder());
        writer.write(f, codes);
        new Thread(writer).start();
      }
      
      Calendar calendar = Calendar.getInstance();
      execute = calendar.get(Calendar.DAY_OF_MONTH) == date;
      
      try {
        Thread.sleep(2*60*1000);
      }catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    
//    synchronizedWriter();
    if(codes.size() < 1) return;
    // khoi phuc lai code cu
//    SimpleDateFormat dateFormat = CalendarUtils.getFolderFormat();
//    File f = new File(folder, dateFormat.format(Calendar.getInstance().getTime()));
    File f = new File(folder, DataOfDay.getDateFoder());
    writer.write(f, codes);
    writer.save();
  }
  
  public void write(int code) {
    if(codes.contains(code)) return;
    codes.add(code);
  }
  
  public boolean search(int code, boolean resave) {
    if(codes.contains(code)) return true;

//    synchronizedWriter();

    File [] files = UtilFile.listFiles(folder, new FileFilter() {
      public boolean accept(File ele) {
        if(ele.isDirectory()) return false;
        return ele.getName().length() == 10;
      }
    });  

    if(files == null || files.length < 1) return false;

//    reader.putData(files[0], code);
    
//    synchronizeReader();
    
//    try {
//      if(reader.getPosition() != -1) return true;
//    } catch (Exception e) {
//      return true;
//    }

    int size = Math.min(files.length, DownloadedTracker.MAX_DATE);
    for(int i = 0; i < size; i++) {
      ConcurrentSetInt ccodes = cacheCode.getCodes(files[i]);
      if(ccodes != null) {
        if(!ccodes.contains(code)) continue;
      } else {
        if(reader.search(files[i], code) == -1) continue;
      }
      if(resave) codes.add(code);
      return true;
    }
    return false;
  }
  
  private void synchronizeReader() {
    synchronized (reader) {
      while(reader.isRunning()) {
        try {
          reader.wait(); 
        } catch (InterruptedException e) {
        }
      }
    }
  }
  
  public boolean isEmptyTemp() { return codes.size() < 1; }
  
}
