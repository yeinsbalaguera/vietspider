/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.crawl.io.indexbak;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.vietspider.content.tp.DocumentFactory;
import org.vietspider.content.tp.model.SummarizeDocument;
import org.vietspider.content.tp.model.TopicTracking;
import org.vietspider.crawl.plugin.PluginData;
import org.vietspider.html.Group;
import org.vietspider.html.HTMLNode;
import org.vietspider.html.Name;
import org.vietspider.html.util.CharacterUtil;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 18, 2009  
 */
class PluginData2TopicTrackerBak {
  
  private Name [] styles = {Name.FONT, Name.SUB, Name.SUP};
  private char [] endSentences  = {'.', ':', '?'};
  
  private Pattern wordPattern = Pattern.compile("\\b[\\p{L}\\p{Digit}]");
  
  TopicTracking convert(
      DocumentFactory factory, PluginData pluginData) throws Exception {
    List<HTMLNode> textNodes = pluginData.getCloneTextNodes();
    if(textNodes == null) return null;
    
    String id  = pluginData.getMeta().getId();
    String group = pluginData.getGroup().getType();
    int minRelation = pluginData.getGroup().getMinPercentRelation();
    if(pluginData.isWebPage()) minRelation = 75;
    int rangeRelation = pluginData.getGroup().getDateRangeRelation();
    
    TopicTracking topicTracking = new TopicTracking(id, group, minRelation, rangeRelation);
    char [] lastElement = null;
    
    CharacterUtil charUtil = new CharacterUtil();
    
    StringBuilder builder = new StringBuilder();
    
    for(HTMLNode node : textNodes)  {
      char [] chars = node.getValue();
      if(chars.length < 1) continue;
      
      int counter = charUtil.count(chars);    
      if(lastElement != null 
          && isSentence(lastElement) 
          && counter < 5) continue;
      
      /** only for webpage, safe data */
      if(pluginData.isWebPage()) {
        counter = countWords(new String(chars));
        if(counter < 20) continue;
      }
      
      if(!isStyle(node) && !isSentence(chars)){
        char [] nText = new char[chars.length+1];
        System.arraycopy(chars, 0, nText, 0, nText.length-1);
        nText[chars.length] = '.';
        chars = nText;
      }
      builder.append(chars).append(' ');
      lastElement = chars;
    }
    
    SummarizeDocument summarize = factory.create(topicTracking.getMetaId(), builder.toString());
    topicTracking.setSummarize(summarize);

    return topicTracking;
  }
  
  private boolean isSentence(char[] text){
    char c = text[text.length - 1]; 
    for(char ele : endSentences){
      if(c == ele) return true;
    }
    return false;
  }
  
  public int countWords(CharSequence charSeq){
    int start = 0;
    int counter = 0;
    Matcher matcher = wordPattern.matcher(charSeq);
    while(matcher.find(start)) {
      start = matcher.start() + 1;
      counter++;
    }
    return counter;
  }
  
  private boolean isStyle(HTMLNode node){
    if(node.getConfig().type() == Group.Fontstyle.class) return true;
    if(node.getConfig().type() == Group.Phrase.class) return true;
    for(Name name : styles) {
      if(node.getName() == name) return false;
    }
    return false;
  }
  
}
