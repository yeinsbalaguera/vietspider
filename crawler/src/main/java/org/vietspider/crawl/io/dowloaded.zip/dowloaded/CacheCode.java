/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.crawl.io.dowloaded;

import java.io.File;
import java.io.FileFilter;
import java.lang.ref.SoftReference;
import java.util.Hashtable;

import org.vietspider.common.io.ConcurrentSetInt;
import org.vietspider.common.io.ConcurrentSetIntCacher;
import org.vietspider.common.io.UtilFile;
import org.vietspider.io.SystemProperties;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jun 13, 2008  
 */
public final class CacheCode extends Thread {
  
  private final static String SIZE_OF_CACHE_CODE = "size.of.cache.code"; 
  private volatile int size = 5;
  
  private final static long mb = 1024*1024l;

  private volatile Hashtable<File, SoftReference<ConcurrentSetInt>> list;
  
  private volatile File folder;
  private volatile boolean execute = true;
  
  public CacheCode(File folder_) {
    this.folder = folder_;
    list = new Hashtable<File, SoftReference<ConcurrentSetInt>>();
    
    SystemProperties system = SystemProperties.getInstance();
    String propertyValue = system.getValue(SIZE_OF_CACHE_CODE);
    try {
      if(propertyValue != null) size = Integer.parseInt(propertyValue);
    } catch (Exception e) {
      size = 5;
    }
    this.start();
  }
  
  public void run() {
    while(execute) {
//      Runtime runtime = Runtime.getRuntime();
//      long max  = runtime.maxMemory();
//      long total  = runtime.totalMemory();
//      long free = max - total;
//      LogService.getInstance().setMessage("free memory: "+ ((free/1024)/1024) + " mb");
//      if(free > 1000*mb) {
//        size = 40;
//      } else if(free > 500*mb) {
//        size = 30;
//      } else if(free > 240*mb) {
//        size = 20;
//      } else if(free > 120*mb) {
//        size = 10;
//      } else if(free > 64*mb) {
//        size = 5;
//      } else {
//        size = 0;
//      }
      
      if(list.size() < size) {
        loadData();
      } else {
        list.clear();
      }
      
      try {
        Thread.sleep(10*60*1000);
      } catch (Exception e) {
      }
    } 
  }
  
  private void loadData() {
    File [] files = UtilFile.listFiles(folder, new FileFilter() {
      public boolean accept(File ele) {
        return ele.getName().length() == 10;
      }
    });
    
//    CacheCodesLoader codeLoader = new CacheCodesLoader();
    
    for(int i = 1; i < Math.min(size+1, files.length); i++) {
      if(files[i].length() > mb) continue;
      SoftReference<ConcurrentSetInt> ref = list.get(files[i]);
      if(ref != null) {
        ConcurrentSetInt codes = ref.get(); 
        if(codes != null && !codes.isEmpty()) continue;
      }
      ConcurrentSetInt codes = new ConcurrentSetIntCacher();
      codes.loadFile(files[i]);
      list.put(files[i], new SoftReference<ConcurrentSetInt>(codes));
    }
  }
  
  ConcurrentSetInt getCodes(File file) {
    SoftReference<ConcurrentSetInt> ref = list.get(file);
    if(ref == null) return null;
    ConcurrentSetInt codes = ref.get();
    if(codes == null || codes.isEmpty()) {
      list.remove(file);
      return null;
    }
    return codes;
  }
  
  void exit() { execute = false; }
  
}
