/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.crawl.io.dowloaded;

import java.util.Hashtable;
import java.util.Iterator;

import org.vietspider.common.Application;
import org.vietspider.common.Install;
import org.vietspider.io.codes.CodesTracker;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Mar 12, 2008  
 */
public final class DownloadedTrackerBak extends Thread {
  
  private volatile static DownloadedTrackerBak dtracker;
  
  public synchronized static DownloadedTrackerBak getInstance() {
    if(dtracker == null) {
      dtracker = new DownloadedTrackerBak();
      dtracker.start();
    }
    return dtracker;
  }
  
  public volatile static int CACHE_SIZE = 128000;
  
  public volatile static int FILE_SIZE = 512*1024;
  
  static {
    if(Application.LICENSE == Install.SEARCH_SYSTEM) {
      CACHE_SIZE = 1000000;
      FILE_SIZE = 5*1024*1024;
    }
  }
  
  public volatile  static int MAX_DATE = 31;
  
  private final static long TIMEOUT = 30*60*1000L;
  
  private Hashtable<String, CodesTracker<?>> holder = new Hashtable<String, CodesTracker<?>>();
  
  public void run() {
    while(true) {
      Iterator<String> iterator = holder.keySet().iterator();
      while(iterator.hasNext()) {
        String key = iterator.next();
        CodesTracker<?> tracker = holder.get(key);
        if(tracker.isEndSession()) {
          iterator.remove();
          continue;
        }
        
        if(!tracker.isEmptyTemp() || 
            System.currentTimeMillis() - tracker.getLastAccess() < TIMEOUT) continue;
        
        tracker.endSession();
        holder.remove(key);
      }
      try {
        Thread.sleep(10*1000) ;
      } catch(Exception ex) {
      }
    }
  }

  private CodesTracker<?> getTracker(String group) {
    CodesTracker<?> tracker = holder.get(group);
    if(tracker == null || tracker.isEndSession()) {
      String path = "track/downloaded/"+group+"/";
      try {
        tracker = new CacheDownloadedTracker(path);
      } catch (IndexOutOfBoundsException e) {
        tracker = new FileDownloadedTracker(path);
      }
//      System.out.println(" create "+ tracker.getClass());
      holder.put(group, tracker);
      return tracker;
    }
    
    if(tracker instanceof CacheDownloadedTracker) {
      CacheDownloadedTracker cacheTracker = (CacheDownloadedTracker) tracker;
      if(cacheTracker.isOutOfSize()) {
        cacheTracker.endSession();
        String path = "track/downloaded/"+group+"/";
        holder.put(group, new FileDownloadedTracker(path));
      }
    }
    return tracker; 
  }
  
  synchronized public static void save(String group, int code) {
//    DownloadedTracker<?> tracker = getInstance(group);
//    tracker.write(code);
    CodesTracker<?> tracker = getInstance().getTracker(group);
    tracker.setLastAccess(System.currentTimeMillis());
    tracker.write(code);
  }
  
  synchronized public static boolean search(String group, int code, boolean resave) {
//    DownloadedTracker<?> tracker = getInstance(group);
//    return tracker.search(code);
    CodesTracker<?> tracker = getInstance().getTracker(group);
    tracker.setLastAccess(System.currentTimeMillis());
    return tracker.search(code, resave);
  }

}
