/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.crawl.io.indexbak;

import java.util.Iterator;
import java.util.Queue;
import java.util.Set;

import org.vietspider.content.tp.model.SummarizeDocument;
import org.vietspider.content.tp.model.TopicTracking;
import org.vietspider.content.tp.word.Word;
import org.vietspider.content.tp.word.WordList;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 18, 2009  
 */
class MemoryComputorBak {
  
  MemoryComputorBak() {
  }
  
  
  void compute(Set<SummarizeDocument> docs, Queue<TopicTracking> queue, TopicTracking topic) {
    Iterator<TopicTracking> iterator = queue.iterator();
    while(iterator.hasNext()) {
      TopicTracking temp = iterator.next();
      if(search(topic.getSummarize(), temp.getSummarize())) {
        docs.add(temp.getSummarize());
      }
    }
  }
  
  boolean search(SummarizeDocument pattern, SummarizeDocument doc) {
    WordList pWords = pattern.getNouns();
    Word[] words = doc.getNouns().getWord();
    for(int i = 0; i < words.length; i++) {
      if(pWords.contains(words[i].getValue())) return true;
    }
    return false;
  }
  
  
}
