/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.crawl.io.indexbak;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.headvances.vietspider.SystemProperties;
import org.headvances.vietspider.database.DatabaseService;
import org.headvances.vietspider.idm2.EIDFolder2;
import org.vietspider.bean.Article;
import org.vietspider.bean.Meta;
import org.vietspider.bean.Relation;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.content.tp.DocumentFactory;
import org.vietspider.content.tp.model.SummarizeDocument;
import org.vietspider.content.tp.model.TopicTracking;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 18, 2009  
 */
class TopicTrackingSearcherBak {
  
  protected DocumentFactory factory;
  
  private IndexerComputorBak indexerComputorBak;
  protected MemoryComputorBak memoryComputorBak;
  
  private boolean checkDuplicate = true;
  
  private int maxDate = 3;
  
  protected volatile Queue<TopicTracking> waitData = new ConcurrentLinkedQueue<TopicTracking>();
  
  TopicTrackingSearcherBak() {
    try {
      factory = new DocumentFactory();
      memoryComputorBak = new MemoryComputorBak();
      indexerComputorBak = new IndexerComputorBak(factory);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    } 
    
    try {
      SystemProperties system = SystemProperties.getInstance();
      checkDuplicate = !("false".equals(system.getValue("mining.check.duplicate")));
    } catch (Exception e) {
    }
  }
  
  void computeRelationInMemory() {
    Iterator<TopicTracking> iterator = waitData.iterator();
    while(iterator.hasNext()) {
      TopicTracking topic = iterator.next();
      memoryComputorBak.compute(topic.getRelationDocs(), waitData, topic);
    }
  }
  
  private void searchIndex(TopicTracking topic) throws Exception {
    File file  = UtilFile.getFolder("content/indexed/"+topic.getGroup().toString());
    File [] files = UtilFile.listFiles(file);

    if(files != null) {
      for(int i = Math.min(maxDate, files.length)-1; i > -1; i--) {
        try {
          indexerComputorBak.search(topic.getRelationDocs(), 
              files[i].getAbsolutePath(), topic.getSummarize());
        } catch (Exception e) {
          LogService.getInstance().setMessage(e, e.toString());
        }
      }
    }
  }
  
  public void searchRelation(TopicTracking topic) throws Exception{
    searchIndex(topic);
    Set<SummarizeDocument> docs = topic.getRelationDocs();
    if(docs.size() < 1) return;
    
//    System.out.println(" tong cong "+ topic.getMetaId()+ " : "+ docs.size());
    
    if(docs.contains(topic.getSummarize())) {
      docs.remove(topic.getSummarize());
    }

    List<Relation> relations = new ArrayList<Relation>();
    List<Relation> duplicates = new ArrayList<Relation>();
    boolean duplicate = false;
    
    Map<String, Meta> cachedMetas = new HashMap<String, Meta>();
    SummarizeDocument summarize = topic.getSummarize(); 
    
    for(SummarizeDocument doc : docs){      
      double m = factory.compare(summarize, doc);
      if(m < topic.getMinPercentRelation()) continue;   
      if(m > 100) m = 100;

      Relation relation = new Relation();

      String metaId = topic.getMetaId();
      String relationId = doc.getId().toString();

      // check duplicate data
      int type = isDuplicate(cachedMetas, metaId, relationId, m);
      if(type == 0) {
        duplicate = true;
        if(!existsInDuplicate(duplicates, relationId, metaId)) {
          Relation duplicateRelation = new Relation();
          duplicateRelation.setMeta(relationId);
          duplicateRelation.setRelation(metaId);
          duplicateRelation.setPercent((int)m);
          duplicates.add(duplicateRelation);
        }
      } else if(type == 1) {
        duplicate = true;
      }

//      System.out.println(topic.getMetaId()+ " : " + doc.getId() + " : "+ m);
    
      relation.setMeta(metaId);
      relation.setRelation(relationId);
      if(check(relations, relation.getRelation())) continue;

      relation.setPercent((int)m);
      relations.add(relation);
    }
    
//    System.out.println(" cuoi cung "+ topic.getMetaId()+ " : "+ relations.size());

    topic.addRelations(relations);

    if(!duplicate)  return;
    
    EIDFolder2.write(null, topic.getMetaId(), Article.DELETE);
//    IDTracker.getInstance().update(meta.getMetaId(), -1);
    
    if(duplicates.size() < 1) return;
    DatabaseService.getSaver().save(duplicates);
  }
  
  boolean existsInDuplicate(List<Relation> duplicates, String metaId, String relationId){    
    for(Relation ele : duplicates){
      String eMetaId = ele.getMeta();
      String eRelationId = ele.getRelation();
      if(eMetaId.equals(metaId) && eRelationId.equals(relationId)) return true;
    }
    return false;
  }
  
  int isDuplicate(Map<String, Meta> metas, String metaId, String relId, double rate){ 
    if(rate < 90) return -1;
    
    if(checkDuplicate) return 0;
    
    Meta meta = getMeta(metas, metaId);
    if(meta == null) return -1;
    
    Meta relation = getMeta(metas, relId);
    if(relation == null) return -1;
    
    if(relation.getDomain().equals(meta.getDomain())) return 1;
    
    return -1; 
  }
  
  boolean check(List<Relation> relations, String id){    
    for(Relation ele : relations){
      if(ele.getRelation().equals(id)) return true;
    }
    return false;
  }
  
  private Meta getMeta(Map<String, Meta> cachedMetas, String id) {
    try {
      Meta meta = cachedMetas.get(id); 
      if(meta == null) {
        meta  = DatabaseService.getLoader().loadMeta(id);
        cachedMetas.put(id, meta);
      }
      return meta;
    } catch (Exception e) {
      return null;
    }
  }
}
