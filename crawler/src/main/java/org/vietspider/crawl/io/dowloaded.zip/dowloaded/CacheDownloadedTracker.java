/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.       *
 **************************************************************************/
package org.vietspider.crawl.io.dowloaded;

import java.io.File;
import java.io.FileFilter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.vietspider.common.Application;
import org.vietspider.common.io.ConcurrentSetInt;
import org.vietspider.common.io.ConcurrentSetIntCacher;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;
import org.vietspider.io.codes.CacheCodeWriter;
import org.vietspider.io.codes.CodesTracker;
import org.vietspider.io.codes.FileCodesReader;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 26, 2008  
 */
class CacheDownloadedTracker extends CodesTracker<ConcurrentSetInt> {
  
  private ConcurrentSetInt codes;
  private File folder;
  protected File file;
  
  private int date = -1;
  
  private volatile int total = 0;
  private volatile int counter = 0;
  
  private CacheCode cacheCode;

  public CacheDownloadedTracker(String path) throws IndexOutOfBoundsException {
    this(UtilFile.getFolder(path));
  }
  
  public CacheDownloadedTracker(File folder_)  throws IndexOutOfBoundsException {
    this.folder = folder_;  
    codes = new ConcurrentSetIntCacher();
    writer = new CacheCodeWriter();
    cacheCode = new CacheCode(folder);
    
    Application.addShutdown(new Application.IShutdown() {
      
      public String getMessage() {
        if(folder != null) {
          System.out.println(folder.getAbsolutePath());
        }
        return getClass().getName(); 
      }
      
      public void execute() {
        execute = false;
        if(cacheCode != null) cacheCode.exit();
        
        if(counter < 1) return;
        
        System.out.println(" == > "+ file.getAbsolutePath());
        
        File tempFile = new File(folder, "codes.temp2");
        System.out.println(" prepare save temp file " + tempFile.getAbsolutePath() + " at " + Calendar.getInstance().getTime());
        saveTemp(folder, "codes.temp2", codes);
        System.out.println(" finish save temp file " + tempFile.getAbsolutePath() + " at " + Calendar.getInstance().getTime());
        
        counter = 0;
      }
    });

    Calendar calendar = Calendar.getInstance();
    date = calendar.get(Calendar.DAY_OF_MONTH);
    SimpleDateFormat dateFormat = CalendarUtils.getFolderFormat();
    file = new File(folder, dateFormat.format(calendar.getTime()));
    if(file.length() >= DownloadedTrackerBak.FILE_SIZE) throw new IndexOutOfBoundsException(); 
    
//    CacheCodesLoader downloadedLoader = new CacheCodesLoader();

    codes.loadFile(file);
//    downloadedLoader.load(file, codes);
    
    File f = new File(folder, "codes.temp");
    if(f.exists())  {
      codes.loadFile(f);
//      downloadedLoader.load(f, codes);
      f.delete();
    }
    
    f = new File(folder, "codes.temp2");
    if(f.exists())  {
      codes.loadFile(f);
//      downloadedLoader.load(f, codes);
      f.delete();
    }
    
    new Thread(this).start();
  }
  
  public void run() {
    total = codes.size();
    while(execute) {
      if(counter > 10) {
        synchronizedWriter();
        counter = 0;
        writer.write(file, codes);
        new Thread(writer).start();
      }
      
      Calendar calendar = Calendar.getInstance();
      execute = calendar.get(Calendar.DAY_OF_MONTH) == date;
      
      try {
        Thread.sleep(3*60*1000);
      }catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    
    synchronizedWriter();
    if(counter < 1) return;
    counter = 0;
    writer.write(file, codes);
    writer.save();
  }
  
  public void write(int code) {
    if(!execute) return;
    codes.add(code);
    counter++;
    total++;
  }

  boolean isOutOfSize() { return total >= DownloadedTrackerBak.CACHE_SIZE; }
  
  public boolean search(int code, boolean resave) {
    if(codes.contains(code)) return true;

    File [] files = UtilFile.listFiles(folder, new FileFilter() {
      public boolean accept(File ele) {
        if(ele.getName().equals(file.getName())) return false;
        return ele.getName().length() == 10;
      }
    });
    
    if(files == null) return false;
    
    FileCodesReader reader = new FileCodesReader();
    int size = Math.min(files.length, DownloadedTracker.MAX_DATE);
    for(int i = 0; i < size; i++) {
      ConcurrentSetInt ccodes = cacheCode.getCodes(files[i]);
      if(ccodes != null) {
        if(!ccodes.contains(code)) continue;
      } else {
        if(reader.search(files[i], code) == -1) continue;
      }
      if(resave) codes.add(code);
      counter++;
      return true;
    }
    return false;
  }
  
  public boolean isEmptyTemp() { return counter < 1; }
  
}
