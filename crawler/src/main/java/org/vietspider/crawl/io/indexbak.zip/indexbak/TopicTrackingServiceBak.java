/***************************************************************************
 * Copyright 2001-2007 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.crawl.io.indexbak;

import java.io.File;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.headvances.vietspider.database.DatabaseService;
import org.vietspider.common.Application;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.content.tp.index.TopicTrackingIndexer;
import org.vietspider.content.tp.model.TopicTracking;
import org.vietspider.crawl.plugin.PluginData;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Oct 8, 2007  
 */
class TopicTrackingServiceBak extends TopicTrackingSearcherBak implements Runnable {

  private final static long TIMEOUT = 5*60*1000L;
  
  private volatile static TopicTrackingServiceBak INSTANCE =  null;

  static TopicTrackingServiceBak getInstance() { return INSTANCE; }
  
  static void createInstance() {
    INSTANCE = new TopicTrackingServiceBak(); 
    new Thread(INSTANCE).start();
  }

  private int total = 0;
  
  private Map<String, TopicTrackingIndexer> holder = new ConcurrentHashMap<String, TopicTrackingIndexer>();
  private PluginData2TopicTrackerBak converter;

  private TopicTrackingServiceBak() {
    converter = new PluginData2TopicTrackerBak();
    
    Application.addShutdown(new Application.IShutdown() {
      
      public String getMessage() { return "Close Topic Tracking Service";}

      public int getPriority() { return 2; }

      public void execute() {
        commit();
        
        Iterator<String> iterator = holder.keySet().iterator();
        while(iterator.hasNext()) {
          String key = iterator.next();
          TopicTrackingIndexer tracker = holder.get(key);
          tracker.close();
        }
      }
    });
  }
  
  public void put(PluginData pluginData) {
    try {
      put(converter.convert(factory, pluginData));
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }
  
  
  public void put(TopicTracking topic) {
    if(topic == null) return;
    waitData.add(topic);
  }

  public void run() {
    while(true){
      commit();
      closeExpire();
      
//      System.out.println(" total index "+ total);
      
      try {
        Thread.sleep(10*1000);
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }    
  }
  
  private void commit() {
    computeRelationInMemory();
    
    Set<TopicTrackingIndexer> commits = new HashSet<TopicTrackingIndexer>();
    
    while(!waitData.isEmpty()) {
      TopicTracking topic = waitData.poll();
      try {
        TopicTrackingIndexer indexer = index(topic);
        if(indexer != null) commits.add(indexer);
      } catch (OutOfMemoryError e) {
        Runtime.getRuntime().gc();
      }
    } 
    
    Iterator<TopicTrackingIndexer> iterator = commits.iterator();
    while(iterator.hasNext()) {
      TopicTrackingIndexer indexer = iterator.next();
      indexer.commit();
    }
  }

  private TopicTrackingIndexer index(TopicTracking topic) {
    total++;
    
    try {
      searchRelation(topic);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
    
    File indexFile = UtilFile.getFolder("content/indexed/"+topic.getGroup().toString()+"/"+ topic.getDate());
    TopicTrackingIndexer indexer = getDatabase(indexFile);
    
    try {
      // write document to indexing directory
      indexer.write(factory.toDocument(topic.getSummarize()));
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
    
//    System.out.println(" chuan bi save "+ topic.getMetaId()+ " : "+ topic.getRelations().size());
    
    try {
      DatabaseService.getSaver().save(topic.getRelations());
    } catch (Exception e) {
      LogService.getInstance().setMessage(e, null);
    }
    
    return indexer;
  }
  
  public synchronized TopicTrackingIndexer getDatabase(File file){
    String path  = file.getAbsolutePath();
    TopicTrackingIndexer tracker = holder.get(path);
    if(tracker != null && !tracker.isClose()) return tracker;
    try {
      tracker = new TopicTrackingIndexer(file);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(path, e);
    }
    if(tracker != null) holder.put(path, tracker);
    return tracker;
  }

  public void closeExpire()  {
    Iterator<String> iterator = holder.keySet().iterator();
    org.vietspider.common.util.Queue<String> queue = 
      new org.vietspider.common.util.Queue<String>();

    while(iterator.hasNext()) {
      String key = iterator.next();
      TopicTrackingIndexer tracker = holder.get(key);
      if(System.currentTimeMillis() - tracker.getLastAccess() >= TIMEOUT) {
        queue.push(key);
      } else if(tracker.isClose()) {
        queue.push(key);
      } 
    }

    while(queue.hasNext()) {
      String key = queue.pop();
      TopicTrackingIndexer tracker = holder.get(key);
      holder.remove(key);
      if(tracker == null) continue;
      tracker.close();
    }
  }

}
