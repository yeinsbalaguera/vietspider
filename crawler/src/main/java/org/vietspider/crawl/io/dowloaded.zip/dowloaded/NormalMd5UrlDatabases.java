/***************************************************************************
 * Copyright 2001-2007 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.crawl.io.dowloaded;

import org.vietspider.je.codes.Md5UrlDatabases;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Dec 25, 2007  
 */
public final class NormalMd5UrlDatabases extends Md5UrlDatabases {

  NormalMd5UrlDatabases(String group, String name, String source) throws Exception {
    super("track/url/site/" + group + "/" + name , "url", source, 10*24*60*60*1000, 3, 3*1024*1024);
  }
  

//  public boolean isEmptyTemp() { return codes.isEmpty(); }

}
