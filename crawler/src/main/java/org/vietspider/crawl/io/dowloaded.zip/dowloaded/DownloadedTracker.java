/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.crawl.io.dowloaded;

import java.util.Hashtable;
import java.util.Iterator;

import org.vietspider.common.Application;
import org.vietspider.common.io.LogService;
import org.vietspider.common.text.NameConverter;
import org.vietspider.crawl.CrawlExecutor;
import org.vietspider.crawl.link.Link;
import org.vietspider.je.codes.Md5UrlDatabases;

import com.sleepycat.je.recovery.RecoveryException;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Mar 12, 2008  
 */
final class DownloadedTracker extends Thread {
  
  private volatile static DownloadedTracker dtracker;
  
  synchronized static DownloadedTracker getInstance() {
    if(dtracker == null) {
      dtracker = new DownloadedTracker();
      dtracker.start();
    }
    return dtracker;
  }
  
  public final static short URL = 0;
  public final static short FORUM = 1;
  public final static short TITLE = 2;
  public final static short NORMAL = 2;
  
  public volatile  static int MAX_DATE = 31;
  
  private final static long TIMEOUT = 10*60*1000L;
  
  private Hashtable<String, Md5UrlDatabases> holder = new Hashtable<String, Md5UrlDatabases>();
  
  public void run() {
    while(true) {
      Iterator<String> iterator = holder.keySet().iterator();
      while(iterator.hasNext()) {
        String key = iterator.next();
        Md5UrlDatabases tracker = holder.get(key);
        if(System.currentTimeMillis() - tracker.getLastAccess() >= TIMEOUT) {
//          System.out.println(" close and remove "+ key + " : "+ tracker.hashCode());
          tracker.close();
          holder.remove(key);
          break;
        } else if(tracker.isClose()) {
//          System.out.println(" remove "+ key + " : "+ tracker.hashCode());
          holder.remove(key);
          break;
        } else {
          try {
          tracker.nextDatabase();
          } catch (Exception e) {
          }
        }
      }
      
      try {
        Thread.sleep(15*1000) ;
      } catch(Exception ex) {
      }
    }
  }
  
  public void registry(final String group, final short type) {
    new Thread() {
      public void run() {
        try {
          if(type == FORUM) {
            createForumTracker(group);
          } else if(type == TITLE){
            createTitleTracker(group);
          } else {
            createUrlTracker(group);
          }
        } catch (Exception e) {
        }  
      } 
    }.start() ; 
  }
  
  private synchronized void createUrlTracker(String group) {
    Md5UrlDatabases tracker = holder.get("URL/"+group);
    if(tracker != null && !tracker.isClose()) return;
    try {
      tracker = new SimpleMd5UrlDatabases(group);
    } catch (RecoveryException e) {
      LogService.getInstance().setThrowable(group, e.getCause());
      LogService.getInstance().setThrowable(group, e);
      Application.addError(this);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(group, e);
      Application.addError(this);
    }
    holder.put("URL/"+group, tracker);
  }
  
  private synchronized void createTitleTracker(String group) {
    Md5UrlDatabases tracker = holder.get("TITLE/"+group);
    if(tracker != null && !tracker.isClose()) return;
    try {
      tracker = new SimpleMd5TitleDatabases(group);
    } catch (RecoveryException e) {
      LogService.getInstance().setThrowable(group, e.getCause());
      LogService.getInstance().setThrowable(group, e);
      Application.addError(this);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(group, e);
      Application.addError(this);
    }
    holder.put("TITLE/"+group, tracker);
  }

  private synchronized void createForumTracker(String source) {
    //    String source = executor.getValue().getFullName();
    Md5UrlDatabases tracker = holder.get("FORUM/" + source);
    if(tracker != null && !tracker.isClose()) return;
    try {
      NameConverter converter = new NameConverter();
      tracker = new ForumMd5UrlDatabases(converter.encode(source), source);
    } catch (RecoveryException e) {
      LogService.getInstance().setThrowable(source, e.getCause());
      LogService.getInstance().setThrowable(source, e);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(source, e);
    }
    holder.put("FORUM/" + source, tracker);
  }
  
 /* private synchronized void createNormalTracker(String group, String source) {
    //    String source = executor.getValue().getFullName();
    Md5UrlDatabases tracker = holder.get(group + "/" + source);
    if(tracker != null && !tracker.isClose()) return;
    try {
      NameConverter converter = new NameConverter();
      tracker = new NormalMd5UrlDatabases(group, converter.encode(source), source);
    } catch (RecoveryException e) {
      LogService.getInstance().setThrowable(source, e.getCause());
      LogService.getInstance().setThrowable(source, e);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(source, e);
    }
    holder.put(group+"/" + source, tracker);
  }*/

  private synchronized SimpleMd5UrlDatabases getUrlTracker(String group) {
    Md5UrlDatabases tracker = holder.get("URL/"+group);
    return (SimpleMd5UrlDatabases)tracker; 
  }
  
  private synchronized SimpleMd5TitleDatabases getTitleTracker(String group) {
    Md5UrlDatabases tracker = holder.get("TITLE/"+group);
    return (SimpleMd5TitleDatabases)tracker; 
  }
  
  public synchronized ForumMd5UrlDatabases getForumTracker(CrawlExecutor executor) {
    if(executor.getValue() == null) return null;
    String source = executor.getValue().getFullName();
    Md5UrlDatabases tracker = holder.get("FORUM/" + source);
    return (ForumMd5UrlDatabases)tracker; 
  }
  
  public static void saveUrl(Link link) throws Throwable {
    String group = link.getSource().getGroup();    
    SimpleMd5UrlDatabases tracker = getInstance().getUrlTracker(group);
    if(tracker == null) return;
    tracker.write(link);
  }
  
  public static boolean searchUrl(Link link) throws Throwable {
    String group = link.getSource().getGroup();    
    SimpleMd5UrlDatabases tracker = getInstance().getUrlTracker(group);
    if(tracker == null) return true;
    return tracker.search(link);
  }
  
  public static void saveTitle(Link link) throws Throwable {
    String group = link.getSource().getGroup();    
    SimpleMd5TitleDatabases tracker = getInstance().getTitleTracker(group);
    if(tracker == null) return;
    tracker.write(link);
  }
  
  public static boolean searchTitle(Link link) throws Throwable {
    String group = link.getSource().getGroup();    
    SimpleMd5TitleDatabases tracker = getInstance().getTitleTracker(group);
    if(tracker == null) return true;
    return tracker.search(link);
  }

}
