/***************************************************************************
 * Copyright 2003-2006 by VietSpider - All rights reserved.  *
 *    *
 **************************************************************************/
package org.vietspider.db.database.test;

import java.util.List;

import org.vietspider.bean.Meta;
import org.vietspider.db.database.DatabaseUtils;
import org.vietspider.db.database.MetaList;

/**
 *  Author : Nhu Dinh Thuan
 *          Email:nhudinhthuan@yahoo.com
 * Feb 11, 2007
 */
public class DataUtils implements DatabaseUtils {

  @Override
  public void execute(String... sqls) throws Exception {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void loadEvent(String date, MetaList list) throws Exception {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void loadTopArticles(int top, MetaList list) throws Exception {
    // TODO Auto-generated method stub
    
  }

  @Override
  public List<Meta> loadTopEvent() throws Exception {
    return null;
  }

  @Override
  public void searchMeta(String pattern, MetaList list) throws Exception {
  }

}
