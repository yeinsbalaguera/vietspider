/***************************************************************************
 * Copyright 2003-2006 by VietSpider - All rights reserved.  *
 *    *
 **************************************************************************/
package org.vietspider.db.database.test;

import java.util.List;

import org.vietspider.bean.Article;
import org.vietspider.bean.Content;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Image;
import org.vietspider.bean.Meta;
import org.vietspider.bean.Relation;
import org.vietspider.db.database.DatabaseWriter;
/**
 *  Author : Nhu Dinh Thuan
 *          Email:nhudinhthuan@yahoo.com
 * Feb 8, 2007
 */
public class DataSetter implements DatabaseWriter {

  @Override
  public void save(Image image) throws Exception {
  }

  @Override
  public void save(List<Relation> relations) throws Exception {
    for(Relation relation : relations) {
      System.out.println(relation.getMeta()+ " : "+ relation.getRelation() + " : "+ relation.getPercent());
    }
  }

  @Override
  public void save(Article article) throws Exception {
  }
  
  @Override
  public void save(Meta meta, Domain domain, Content content) throws Exception {
  }

  @Override
  public void save(Relation relation) throws Exception {
      System.out.println(relation.getMeta()+ " : "+ relation.getRelation() + " : "+ relation.getPercent());
  }

  @Override
  public void set(Content content) throws Exception {
  }

}
