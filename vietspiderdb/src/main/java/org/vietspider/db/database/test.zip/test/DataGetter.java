/***************************************************************************
 * Copyright 2003-2006 by VietSpider - All rights reserved.  *
 *    *
 **************************************************************************/
package org.vietspider.db.database.test;

import java.util.ArrayList;
import java.util.List;

import org.vietspider.bean.Article;
import org.vietspider.bean.Content;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Image;
import org.vietspider.bean.Meta;
import org.vietspider.bean.Relation;
import org.vietspider.db.database.DatabaseReader;
import org.vietspider.db.database.MetaList;

/**
 *  Author : Nhu Dinh Thuan
 *          Email:nhudinhthuan@yahoo.com
 * Feb 8, 2007
 */
public class DataGetter implements DatabaseReader {

  @Override
  public Article loadArticle(String id) throws Exception {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public List<Article> loadArticles(String[] metaIds) throws Exception {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Content loadContent(String metaId) throws Exception {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public List<Content> loadContentForMining() throws Exception {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Image loadImage(String id) throws Exception {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public List<Image> loadImages(String metaId) throws Exception {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Meta loadMeta(String id) throws Exception {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public void loadMetaFromDomain(Domain domain, MetaList list) throws Exception {
    // TODO Auto-generated method stub
    
  }

  @Override
  public List<Meta> loadMetaFromDomain(String id) throws Exception {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public List<Relation> loadRelation(String metaId) throws Exception {
    // TODO Auto-generated method stub
    return null;
  }

  public DataGetter() throws Exception {
    super();
  }

  public List<String> loadDateFromDomain() throws Exception {
     return new ArrayList<String>();
  }
  
  public Domain loadDomainById(String id) throws Exception {
    return null;
  }

}
