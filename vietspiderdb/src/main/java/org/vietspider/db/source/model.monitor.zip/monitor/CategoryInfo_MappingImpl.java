package org.vietspider.monitor;


import org.vietspider.monitor.CategoryInfo;
import org.vietspider.token.attribute.*;
import org.vietspider.parser.xml.XMLNode;
import org.vietspider.serialize.Object2XML;
import org.vietspider.serialize.XML2Object;
import org.vietspider.serialize.SerializableMapping;
import java.util.*;
import org.vietspider.monitor.SourceInfo;


public class CategoryInfo_MappingImpl implements SerializableMapping<CategoryInfo> {

	private final static int code=22053093;

	public CategoryInfo create() {
		return new CategoryInfo();
	}

	public void toField(CategoryInfo object, XMLNode node, String name, String value) throws Exception {
		if(name.equals("category")) {
			object.setCategory(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("sources")) {
			List<SourceInfo> list = null;
			list = object.getSources();
			if(list == null) list = new ArrayList<SourceInfo>();
			XML2Object.getInstance().mapCollection(list, SourceInfo.class, node);
			object.setSources(list);
			return;
		}

	}

	public XMLNode toNode(CategoryInfo object) throws Exception {
		XMLNode node = new XMLNode("category-info");
		Attributes attrs  = new Attributes(node);
		Object2XML mapper = Object2XML.getInstance();
		mapper.addNode(object.getCategory(), node, false, "category");
		mapper.addNode(object.getSources(), node, false, "sources", "item", "org.vietspider.monitor.SourceInfo");
		return node;
	}
}
