/***************************************************************************
 * Copyright 2001-2011 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.db2.content;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.vietspider.bean.Article;
import org.vietspider.bean.Image;
import org.vietspider.common.Application;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;
import org.vietspider.db.content.ArticleDatabase;
import org.vietspider.db.content.ArticleDatabases;
import org.vietspider.db.database.DatabaseReader.IArticleIterator;
import org.vietspider.handler.ImageIO;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 11, 2011  
 */
public class BabuDatabaseTest extends Thread {

  public BabuDatabaseTest() {
    this.start();
  }

  public void run() {
    try {
      index();
    } catch (Throwable e) {
      LogService.getInstance().setThrowable(e);
    }

    try {
      Thread.sleep(15*1000l);
    } catch (Exception e) {
    }
    System.exit(0);
  }
  
  private void index () throws Throwable {
    File folder = UtilFile.getFolder("content/database");
    File [] files = folder.listFiles();
//    for(int i = 0; i < Math.min(files.length, 2); i++) {
    for(int i = 0; i < files.length; i++) {
      if(files[i].isDirectory()) index(files[i]);
    }
  }


  private void index(File folder) throws Throwable {
    LogService.getInstance().setMessage(null, "Babu Database " + folder.getAbsolutePath());
    ArticleDatabases databases = (ArticleDatabases)ArticleDatabases.getInstance();
    if(databases == null) return;
    ArticleDatabase database = (ArticleDatabase)databases.getDatabase(null, folder, true);
    
    ArticleBabuDatabases babuDatabases = 
        new ArticleBabuDatabases(new File("D:\\Temp\\babudb\\"));
    //    System.out.println(folder.getAbsolutePath() + " : " + database);
    if(database == null) return;
    
    IArticleIterator iterator = database.getIterator();
    int counter = 0;
    ImageIO imageIO = new ImageIO("content/images/");
    while(iterator.hasNext()) {
      Article article = iterator.next(Article.NORMAL);
      
      List<Image> images = article.getImages();
      if(images != null) {
        for(int i = 0; i < images.size(); i++) {
          Image image = images.get(i);
          Date date = new SimpleDateFormat("yyyyMMdd").parse(article.getId().substring(0, 8));
          String dateValue = CalendarUtils.getFolderFormat().format(date);
          File imgFolder  = UtilFile.getFolder("content/images/"+ dateValue);
          imageIO.loadImage(image, imgFolder);
        }
      }
      
      babuDatabases.save(article);
      
      counter++;
      
      if(counter%100 == 0) {
        try {
          Thread.sleep(10*1000l);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
      
      if(counter%100 == 0) {
        LogService.getInstance().setMessage(null, "Babu database " + counter + " articles.");
      }
    }
    
    try {
      database.close();
    } catch (Exception e) {
    }
    
    try {
      Thread.sleep(30*1000);
    } catch (Exception e) {
    }
    

    LogService.getInstance().setMessage(null, "Babu Database save " + counter + " articles.");
    //    databases.close(database);
  }
  
  public static void main(String[] args) throws Exception {
//    File file = new File("D:\\VietSpider Build 18\\data\\");
//    File file  = new File("D:\\java\\test\\vsnews\\data\\");
    File file  = new File("D:\\Program\\VietSpiderBuild19\\data\\");
    System.setProperty("save.link.download", "true");
    System.setProperty("vietspider.data.path", file.getCanonicalPath());
    System.setProperty("vietspider.test", "true");
    
    Application.PRINT = false;
    
    new BabuDatabaseTest();
  }

}
