/***************************************************************************
 * Copyright 2003-2006 by VietSpider - All rights reserved.  *
 *    *
 **************************************************************************/
package org.vietspider.db.database;

import org.vietspider.common.io.LogService;
import org.vietspider.db.SystemProperties;
import org.vietspider.db.content.DataCleaner;
import org.vietspider.db.content.DataGetter;
import org.vietspider.db.content.DataSetter;
import org.vietspider.db.content.DataUtils;

/**
 *  Author : Nhu Dinh Thuan
 *          Email:nhudinhthuan@yahoo.com
 * Feb 8, 2007
 */
public class DatabaseService {

  //  public static int PAGE_SIZE = 10;

  /* private static ThreadSoftRef<SaveData> SAVE_DATA;
  private static ThreadSoftRef<DeleteData> DELETE_DATA;
  private static ThreadSoftRef<LoadData> LOAD_DATA;
  private static ThreadSoftRef<UtilData> UTIL_DATA;

  static {
    try{
      ClassLoader classLoader = Thread.currentThread().getContextClassLoader();

      PropertiesFile ioProperties = new PropertiesFile(); 
      File file = UtilFile.getFile("/System", "data.properties");
      Properties dataPros = ioProperties.load(file);

      String path = dataPros.getProperty("SaveData");
      Class<?> clazz = null;
      if(path != null && path.trim().length() > 0){
        clazz = classLoader.loadClass(path);
      }else{
        clazz = DataSetter.class;
      }      
      SAVE_DATA = new ThreadSoftRef<SaveData>(clazz);


      path = dataPros.getProperty("DeleteData");
      if(path != null && path.trim().length() > 0){
        clazz = classLoader.loadClass(path);
      }else{
        clazz = DataCleaner.class;
      } 
      DELETE_DATA = new ThreadSoftRef<DeleteData>(clazz);

      path = dataPros.getProperty("LoadData");
      if(path != null && path.trim().length() > 0){
        clazz = classLoader.loadClass(path);
      }else{
        clazz = DataGetter.class;
      } 
      LOAD_DATA = new ThreadSoftRef<LoadData>(clazz);

      path = dataPros.getProperty("UtilData");
      if(path != null && path.trim().length() > 0){
        clazz = classLoader.loadClass(path);
      }else{
        clazz = UtilityData.class;
      }     
      UTIL_DATA = new ThreadSoftRef<UtilData>(clazz);
    }catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      System.exit(-1);
    }
  }*/

  //  private static Class<?> saveClazz;
  //  private static Class<?> loadClazz;
  //  private static Class<?> cleanClazz;
  //  private static Class<?> utilClazz;

  private static DatabaseWriter writer;
  private static DatabaseReader loader;
  private static DatabaseCleaner cleaner;
  private static DatabaseUtils utils;

  static {
    try {
      writer = (DatabaseWriter) loadInstance("dataSaver", DataSetter.class);
      loader = (DatabaseReader) loadInstance("dataGetter", DataGetter.class);
      cleaner = (DatabaseCleaner) loadInstance("dataCleaner", DataCleaner.class);
      utils = (DatabaseUtils) loadInstance("dataUtils", DataUtils.class);
    } catch (Exception e) {
      LogService.getInstance().setThrowable("APPLICATION", e);
      System.exit(0);
    }
  }

  //"dataSaver"
  private static Object loadInstance(String label, Class<?> clazz) throws Exception {
    SystemProperties properties = SystemProperties.getInstance();
    String clazzName = properties.getValue(label);
    if(clazzName == null || clazzName.trim().isEmpty()) {
      clazzName  = clazz.getName();
      properties.putValue(label, clazzName);
    }
    try {
      return Class.forName(clazzName).newInstance();
    } catch (ClassNotFoundException e) {
      properties.putValue(label, clazz.getName());
      return clazz.newInstance();
    } 
  }

  public static DatabaseWriter getSaver() { return writer; }

  //  public static JdbcDataWriter getSaver() { return ServicesContainer.get(WebdbDataSetter.class); }

  public static DatabaseCleaner getDelete() { return cleaner;  }

  public static DatabaseReader getLoader(){ return loader;  }

  //  public static JdbcDataReader getLoader(){ return ServicesContainer.get(WebdbDataGetter.class); }

  public static DatabaseUtils getUtil(){  return utils; }
}
