/***************************************************************************
 * Copyright 2003-2006 by VietSpider - All rights reserved.  *
 *    *
 **************************************************************************/
package org.vietspider.db.database;

import java.util.List;

import org.vietspider.bean.Article;
import org.vietspider.bean.Content;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Image;
import org.vietspider.bean.Meta;
import org.vietspider.bean.Relation;

/**
 *  Author : Nhu Dinh Thuan
 *          Email:nhudinhthuan@yahoo.com
 * Feb 8, 2007
 */
public interface DatabaseReader {
  
  public List<String> loadDateFromDomain() throws Exception ;  
  
  public Domain loadDomainById(String id) throws Exception ;
  
  public Article loadArticle(String id) throws Exception;
  
//  public Article loadShortArticle(String id) throws Exception;
  
  public List<Article> loadArticles(String [] metaIds) throws Exception;
  
  public void loadMetaFromDomain(Domain domain, MetaList list) throws Exception ;
  
  public List<Meta> loadMetaFromDomain(String id) throws Exception ;
  
  public List<Content> loadContentForMining() throws Exception;
  
  public Content loadContent(String metaId) throws Exception;
  
//  public int countMetaFromDomain(Domain domain) throws Exception ;
  
  public List<Relation> loadRelation(String metaId) throws Exception;
  
  public Image loadImage(String id) throws Exception ;
  
  public Meta loadMeta(String id) throws Exception;
  
  public List<Image> loadImages(String metaId) throws Exception ;
  
}
