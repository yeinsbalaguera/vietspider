/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.headvances.vietspider.content.pg;

import java.io.Serializable;
import java.util.Hashtable;

import org.vietspider.bean.Article;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Oct 27, 2009  
 */
public class Data implements Serializable  {

  private static final long serialVersionUID  = 1L;

  private long  id;
  private byte[] meta;
  private byte[] content;
  private byte[] domain;
  private byte[] nlp;
  private byte[] relations;
  
  private Hashtable<String, byte[]> images = new Hashtable<String, byte[]>();
//  private Hashtable<String, byte[]> imageRaws = new Hashtable<String, byte[]>();
  
  private int status = Article.WAIT;
  
  public Data() {
  }

  public long getId() { return id; }
  public void setId(long id) { this.id = id; }

  public int getStatus() { return status; }
  public void setStatus(int status) { this.status = status;  }
  
  public byte[] getMeta() { return meta;  }
  public void setMeta(byte[] meta) {    this.meta = meta; }

  public byte[] getContent() { return content;  }
  public void setContent(byte[] content) { this.content = content;  }
  
  public byte[] getDomain() { return domain;  }
  public void setDomain(byte[] domain) { this.domain = domain;  }

  public byte[] getNlp() { return nlp; }
  public void setNlp(byte[] nlp) { this.nlp = nlp; }

  public byte[] getRelations() { return relations; }
  public void setRelations(byte[] relations) { this.relations = relations; }

  public Hashtable<String, byte[]> getImages() { return images; }
  public void setImages(Hashtable<String, byte[]> images) { this.images = images; }
  
//  public Hashtable<String, byte[]> getImageRaws() {
//    return imageRaws;
//  }
//
//  public void setImageRaws(Hashtable<String, byte[]> imageRaws) {
//    this.imageRaws = imageRaws;
//  }

  public static long getSerialversionuid() { return serialVersionUID;  }

  public String toString() { return "[id = " + id + " ]"; }
  public int compareTo(Data o) {
    return ((Comparable<Long>)id).compareTo(o.getId());
  }
}
