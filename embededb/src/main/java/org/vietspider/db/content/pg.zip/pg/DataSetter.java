/***************************************************************************
 * Copyright 2003-2006 by VietSpider - All rights reserved.  *
 *    *
 **************************************************************************/
package org.headvances.vietspider.content.pg;

import java.util.ArrayList;
import java.util.List;

import org.headvances.vietspider.SystemProperties;
import org.headvances.vietspider.content.ArticleDatabases;
import org.headvances.vietspider.database.DatabaseWriter;
import org.headvances.vietspider.nlp.NLPExtractor;
import org.vietspider.bean.Article;
import org.vietspider.bean.Content;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Image;
import org.vietspider.bean.Meta;
import org.vietspider.bean.NLPRecord;
import org.vietspider.bean.Relation;
/**
 *  Author : Nhu Dinh Thuan
 *          Email:nhudinhthuan@yahoo.com
 * Feb 8, 2007
 */
public class DataSetter implements DatabaseWriter {
  
  private boolean nlp = false;
  
  public DataSetter() {
    SystemProperties properties = SystemProperties.getInstance();
    nlp = "true".equalsIgnoreCase(properties.getValue("nlp"));
    ArticleDatabases.getInstance().setType(ArticleDatabases.ACORN);
  }

  public void save(Image image) throws Exception {
    ArticleDatabases.getInstance().save(image);
  }

  public void save(List<Relation> relations) throws Exception {
    Article article = new Article();
    article.setRelations(relations);
    ArticleDatabases.getInstance().save(article);
  }

  public void save(Article article) throws Exception {
    Meta meta = article.getMeta();
    Content content = article.getContent();
    Domain domain = article.getDomain();
    NLPRecord nlpRecord = null;
    if(nlp) {
      nlpRecord = NLPExtractor.getInstance().extract(meta, domain, content);
      article.setNlpRecord(nlpRecord);
    }
    ArticleDatabases.getInstance().save(article);
  }

  @Deprecated()
  @SuppressWarnings("unused")
  public void save(Meta meta, Domain domain, Content content) throws Exception {
    throw new UnsupportedOperationException();
   /* Article article = new Article();
    article.setMeta(meta);
    article.setContent(content);
    article.setDomain(domain);
    NLPRecord nlpRecord = null;
    if( ArticleDatabases.getInstance().isNLP()) {
      nlpRecord = NLPExtractor.getInstance().extract(meta, domain, content);
      article.setNlpRecord(nlpRecord);
    }
    ArticleDatabases.getInstance().save(article);*/
  }

  public void save(Relation relation) throws Exception {
    Article article = new Article();
    List<Relation> relations = new ArrayList<Relation>();
    relations.add(relation);
    article.setRelations(relations);
    ArticleDatabases.getInstance().save(article);
  }

  public void set(Content content) throws Exception {
    Article article = new Article();
    article.setContent(content);
    ArticleDatabases.getInstance().save(article);
  }

}
