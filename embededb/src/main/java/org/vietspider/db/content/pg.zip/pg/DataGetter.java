/***************************************************************************
 * Copyright 2003-2006 by VietSpider - All rights reserved.  *
 *    *
 **************************************************************************/
package org.headvances.vietspider.content.pg;

import java.util.ArrayList;
import java.util.List;

import org.headvances.vietspider.content.ArticleDatabase;
import org.headvances.vietspider.content.ArticleDatabases;
import org.headvances.vietspider.database.DatabaseReader;
import org.headvances.vietspider.database.MetaList;
import org.headvances.vietspider.idm2.EntryReader;
import org.headvances.vietspider.idm2.IEntryDomain;
import org.headvances.vietspider.idm2.SimpleEntryDomain;
import org.vietspider.bean.Article;
import org.vietspider.bean.Content;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Image;
import org.vietspider.bean.Meta;
import org.vietspider.bean.Relation;

/**
 *  Author : Nhu Dinh Thuan
 *          Email:nhudinhthuan@yahoo.com
 * Feb 8, 2007
 */
public class DataGetter implements DatabaseReader {
  
  public DataGetter() {
    ArticleDatabases.getInstance().setType(ArticleDatabases.ACORN);
  }

  @Override
  public Article loadArticle(String id) throws Exception {
    return ArticleDatabases.getInstance().loadArticle(id, ArticleDatabase.NORMAL);
  }

  @Override
  public List<Article> loadArticles(String[] metaIds) throws Exception {
    List<Article> articles = new ArrayList<Article>();
    for(int i = 0; i < metaIds.length; i++) {
      articles.add(loadArticle(metaIds[i]));
    }
    return articles;
  }

  @Override
  public Content loadContent(String metaId) throws Exception {
    Article article = ArticleDatabases.getInstance().loadArticle(metaId, ArticleDatabase.NORMAL);
    return article.getContent();
  }

  @Override
  public List<Content> loadContentForMining() throws Exception {
    return new ArrayList<Content>();
  }

  @Override
  public Image loadImage(String id) throws Exception {
    return ArticleDatabases.getInstance().loadImage(id);
  }

  @Override
  public List<Image> loadImages(String metaId) throws Exception {
    List<Image> images = new ArrayList<Image>();
    int counter = 1;
    while(counter < 500) {
      String id = metaId + "." + String.valueOf(counter);
      Image image = ArticleDatabases.getInstance().loadImage(id);
      if(image == null) break;
      images.add(image);
      counter++;
    }
    return images;
  }

  @Override
  public Meta loadMeta(String id) throws Exception {
    Article article = ArticleDatabases.getInstance().loadArticle(id, ArticleDatabase.NORMAL);
    return article.getMeta();
  }

  @Override
  public void loadMetaFromDomain(Domain domain, MetaList list) throws Exception {
  }

  @Override
  public List<Meta> loadMetaFromDomain(String id) throws Exception {
    Domain domain = ArticleDatabases.getInstance().loadDomain(id);
    List<Meta> metas = new ArrayList<Meta>();
    if(domain == null) return metas;
    
    IEntryDomain entryDomain = new SimpleEntryDomain(domain);
    
    MetaList metaList = new MetaList("vietspider");
    for(int page = 1; page <= 100; page++) {
      metaList.setCurrentPage(page);
      EntryReader entryReader = new EntryReader();
      entryReader.read(entryDomain, metaList, -1);
      List<Article> articles = metaList.getData();
      if(articles.size() < 1) break;
      for(int i = 0; i < articles.size(); i++) {
        if(articles.get(i) == null) continue;
        metas.add(articles.get(i).getMeta());
      }
    }
    return metas;
  }

  @Override
  public List<Relation> loadRelation(String metaId) throws Exception {
    return null;
  }


  public List<String> loadDateFromDomain() throws Exception {
     return new ArrayList<String>();
  }
  
  public Domain loadDomainById(String id) throws Exception {
    return null;
  }

}
