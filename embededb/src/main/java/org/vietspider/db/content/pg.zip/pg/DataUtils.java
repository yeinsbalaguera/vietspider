/***************************************************************************
 * Copyright 2003-2006 by VietSpider - All rights reserved.  *
 *    *
 **************************************************************************/
package org.headvances.vietspider.content.pg;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.headvances.vietspider.content.ArticleDatabases;
import org.headvances.vietspider.database.DatabaseUtils;
import org.headvances.vietspider.database.MetaList;
import org.vietspider.bean.Meta;

/**
 *  Author : Nhu Dinh Thuan
 *          Email:nhudinhthuan@yahoo.com
 * Feb 11, 2007
 */
public class DataUtils implements DatabaseUtils {

  @Override
  public void execute(String... sqls) throws Exception {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void loadEvent(String _date, MetaList data) throws Exception {
   /* SimpleDateFormat dateFormat  = CalendarUtils.getDateFormat();
    ArticleDatabase articleDatabase = 
      ArticleDatabases.getInstance().getDatabase(dateFormat.parse(_date));
    CommonDatabase relationDatabase = articleDatabase.getRelationDb();
    List<Relations> relations = new ArrayList<Relations>();
    List<String> ids = relationDatabase.loadKey(0, 1500);
    for(int i = 0 ; i < ids.size(); i++) {
      try {
        String metaId = ids.get(i);
        Relations rels = articleDatabase.loadRelations(metaId);
        if(rels.getRelations().size() < 1) continue;
        rels.setMetaId(metaId);
        relations.add(rels);
      } catch (Throwable e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    
    Collections.sort(relations, new Comparator<Relations>(){
      public int compare(Relations relation1, Relations relation2){
        return relation2.getRelations().size() - relation1.getRelations().size();
      }
    });
    
    int total = relations.size();
    int totalPage = total / DatabaseService.PAGE_SIZE ;
    if (total % DatabaseService.PAGE_SIZE > 0) totalPage++ ;
    data.setTotalPage(totalPage);
    int currentPage = data.getCurrentPage();
    int from = (currentPage - 1)*DatabaseService.PAGE_SIZE;
//    int to = Math.min(currentPage*DatabaseService.PAGE_SIZE, total);
    
    List<Article> articles = new ArrayList<Article>();
    for(int i = from; i < relations.size(); i++){
      try {
        Article article =  articleDatabase.loadArticle(relations.get(i).getMetaId());
        if(article.getMetaRelation().size() < 1) continue;
        articles.add(article);
        if(articles.size() >= DatabaseService.PAGE_SIZE) break;
      } catch (Throwable e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    data.setData(articles);*/
  }

  @Override
  public void loadTopArticles(int top, MetaList list) throws Exception {
    /*ArticleDatabase articleDatabase = ArticleDatabases.getInstance().getDatabase(date);
    CommonDatabase database =   articleDatabase.getRelationDb();
    List<String> ids = database.loadKey(0, 15);
    for(int i = 0; i < ids.size(); i++) {
      try {
        Article article = articleDatabase.loadArticle(ids.get(i));
        if(article != null) list.getData().add(article);
      } catch (Throwable e) {
        LogService.getInstance().setMessage(null, e.toString());
      }
    }*/
    
  }

  @Override
  public List<Meta> loadTopEvent() throws Exception {
    Calendar calendar = Calendar.getInstance();
    Date date = calendar.getTime(); 
//    ArticleDatabase2 articleDatabase = (ArticleDatabase2)ArticleDatabases.getInstance().getDatabase(date);
//    CommonDatabase relationDatabase = articleDatabase.getRelationDb();
    List<Meta> metas = new ArrayList<Meta>();
//    List<String> ids = relationDatabase.loadKey(0, 15);
//    for(int i = 0; i < ids.size(); i++) {
//      try {
//        Meta meta = articleDatabase.loadMeta(ids.get(i));
//        if(meta != null) metas.add(meta);
//      } catch (Throwable e) {
//        LogService.getInstance().setMessage(null, e.toString());
//      }
//    }
    return metas;
  }

  @Override
  public void searchMeta(String pattern, MetaList list) throws Exception {
  }

}
