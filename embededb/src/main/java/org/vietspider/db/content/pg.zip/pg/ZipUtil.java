/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.headvances.vietspider.content.pg;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.vietspider.common.io.LogService;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Oct 27, 2009  
 */
class ZipUtil {
  
  static byte [] compress(byte [] bytes) {
    ByteArrayOutputStream byteArrayStream = new ByteArrayOutputStream();
    try {
      GZIPOutputStream gzip = new GZIPOutputStream(byteArrayStream);
      gzip.write(bytes, 0, bytes.length);
      gzip.close();
      return byteArrayStream.toByteArray();
    } catch (Exception e) {
      LogService.getInstance().setThrowable("SERVER", e);
      return bytes;
    }
  }

  static byte [] uncompress(byte [] bytes) {
    ByteArrayInputStream input = new ByteArrayInputStream(bytes);
    try {
      GZIPInputStream gzip = new GZIPInputStream(input);
      byte[] tmp = new byte[2048];
      int read;
      ByteArrayOutputStream output = new ByteArrayOutputStream();
      while ((read = gzip.read(tmp)) != -1) {
        output.write(tmp, 0, read);
      }
      gzip.close();
      return output.toByteArray();
    } catch (IOException e) {
      return bytes;
    } catch (Exception e) {
      LogService.getInstance().setThrowable("SERVER", e);
      return bytes;
    }
  }
}
