/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.browser.history;

import java.net.URL;
import java.util.Calendar;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;
import org.vietspider.index.ITextIndex;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 9, 2009  
 */
public class PageIndex extends ITextIndex  {
  
  final public static String FIELD_URL      = "url" ;
  final public static String FIELD_URL_INDEX      = "url_index" ;
  final public static String FIELD_TIME      = "time" ;
  
  private String url;
  private int time = 0;

  public PageIndex() {
    date = CalendarUtils.getDateFormat().format(Calendar.getInstance().getTime());
    expireDate = 30;
    folder = UtilFile.getFolder("client/history/");
  }
  
  public PageIndex(String url) {
    this();
    this.url = url;
    this.id = String.valueOf(url.hashCode());
  }
  
  public PageIndex(String url, String title) {
    this();
    this.url = url;
    this.id = String.valueOf(url.hashCode());
    this.title = title;
  }
  
  public String getUrl() { return url; }
  public void setUrl(String url) {
    this.url = url; 
    this.id = String.valueOf(url.hashCode());
  }
  
  public int getTime() { return time; }
  public void setTime(int time) { this.time = time; }
  
  public void fromDocument(Document document) {
    Field field = document.getField(FIELD_ID);
    id = field.stringValue();
    
    field = document.getField(FIELD_URL);
    url = field.stringValue();
    
    field = document.getField(FIELD_TITLE);
    if(field != null) title = field.stringValue();
    
    field = document.getField(FIELD_TIME);
    if(field != null) time = Integer.parseInt(field.stringValue());
    
    field = document.getField(FIELD_DATE);
    date = field.stringValue();
  }
  
  public Document toDocument() {
    if(url == null || url.trim().isEmpty()) return null;
    
    Document doc = createDocument(1.0f);
    doc.add(new Field(FIELD_URL, url, Field.Store.YES, Field.Index.NOT_ANALYZED));
    doc.add(new Field(FIELD_TIME, String.valueOf(time), Field.Store.YES, Field.Index.NOT_ANALYZED));
    
    StringBuilder builder = new StringBuilder();
    try {
      URL urlInstance = new URL(url);
      String host = urlInstance.getHost().toLowerCase();
      builder.append(host).append(' ');
      int idx = 3;
      while(idx < host.length()) {
        builder.append(host.substring(0, idx)).append(' ');
        idx++;
      }
     
      String [] elements = host.split("\\.");
      for(int i = 0; i < elements.length; i++) {
        if(elements.equals("com") 
            || elements.equals("org")
            || elements.equals("net")
            || elements.equals("info")
            ) continue;
        builder.append(elements[i]).append(' ');
      }
      
      String path = urlInstance.getPath();
      elements = path.toLowerCase().split("/");
      for(int i = 0; i < elements.length; i++) {
        builder.append(elements[i]).append(' ');
      }
    } catch (Exception e) {
    }
    
    Field urlIndexField = new Field(FIELD_URL_INDEX , builder.toString(), Field.Store.YES, Field.Index.ANALYZED) ;
    urlIndexField.setBoost(2.0f) ;
    doc.add(urlIndexField);

    return doc;
  }
  
  public int getExpireDate() { return 15; }
  
}
