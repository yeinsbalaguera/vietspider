/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.browser.history;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Query;
import org.apache.lucene.util.Version;
import org.vietspider.common.io.UtilFile;
import org.vietspider.index.DbIndexers;
import org.vietspider.index.DbSearcher;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 9, 2009  
 */
public class URLSearcher {
  
  private DbSearcher searcher;
  
  public URLSearcher() {
    File folder = UtilFile.getFolder("client/history/");
    searcher = new DbSearcher(DbIndexers.getInstance(), folder.getAbsolutePath());
  }
  
  public List<PageIndex> search(String pattern) throws Exception {
    List<PageIndex> data = new ArrayList<PageIndex>();
//    StringBuilder builder = new StringBuilder();
//    builder.append(PageIndex.FIELD_URL_INDEX).append(':').append(pattern);
//    builder.append(" OR ");
//    builder.append(PageIndex.FIELD_TITLE_INDEX).append(':').append(pattern);
//    
//    StandardAnalyzer analyzer = new StandardAnalyzer(Version.LUCENE_31);
//    QueryParser parser = new QueryParser(PageIndex.FIELD_URL_INDEX, analyzer);
//    Query query = parser.parse(builder.toString());
//   
//    List<Document> documents = searcher.search(query, 100);
//    for(int i = 0; i < documents.size(); i++) {
//      PageIndex pageIndex = new PageIndex();
//      pageIndex.fromDocument(documents.get(i));
//      data.add(pageIndex);
//    }
    
    return data;
  }
}
