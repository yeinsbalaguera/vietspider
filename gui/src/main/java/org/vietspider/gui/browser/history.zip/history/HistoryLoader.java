/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.browser.history;

import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.widgets.Text;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.common.util.Worker;
import org.vietspider.gui.browser.UIToolbar;
import org.vietspider.ui.widget.CCombo;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 10, 2009  
 */
public class HistoryLoader extends Worker {

  private CCombo combo;
  private String pattern;
  private String[] items ;
  private URLSuggestion suggestion;
  private UIToolbar toolbar;
  private Text text;

  public HistoryLoader(UIToolbar toolbar_, CCombo control) {
    this.toolbar = toolbar_;
    this.combo = control;
    text = combo.text; 
    text.addKeyListener(new KeyAdapter() {
      public void keyReleased(KeyEvent event) {
        if (event.keyCode == SWT.ARROW_UP || event.keyCode == SWT.ARROW_DOWN) {
          event.doit = false;
          if ((event.stateMask & SWT.ALT) != 0) {
//            if (isDropped()) suggestion.getList().setFocus ();
            return;
          }

          if (isDropped())  {
            suggestion.handleArrowKey(event);
            return;
          }
          
        } else if(event.keyCode == SWT.ESC) {
          text.setText(pattern);
          text.setFocus();
          text.setSelection(pattern.length(), pattern.length());
          if (isDropped())  {
            dropped();
            return;
          }
        } else if(event.keyCode == SWT.CR) {
          if (isDropped() && suggestion.getList().isFocusControl()) return;
          toolbar.browse();
        }
      }
      
    });
  }

  public void abort() {
    ClientConnector2.currentInstance().abort();
  }

  public void before() {
    pattern = combo.getText().trim();
  }

  public void execute() {
    try {
      items = searchURL();
    }catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void after() {
    if(suggestion != null) suggestion.dispose();
    if(items == null || items.length < 1) return;
    suggestion = new URLSuggestion(toolbar, combo, items);
  }

  private String[] searchURL() {
    URLSearcher seacher = new URLSearcher(); 
    try {
      List<PageIndex> list = seacher.search(pattern);
      
      String [] values = new String[list.size()];
      for(int i = 0; i < list.size(); i++) {
        values[i] = list.get(i).getUrl()+ "   ->   "+ list.get(i).getTitle();
      }
      return values;
    } catch (Exception e) {
      return new String[0];
    }
  }

  private boolean isDropped() {
    return suggestion != null && !suggestion.isDisposed();
  }
  
  public void dropped() {
    if(suggestion == null) return;
    suggestion.dispose();
    suggestion = null;
  }
}
