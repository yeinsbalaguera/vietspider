/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.browser.history;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.vietspider.generic.ColorCache;
import org.vietspider.gui.browser.UIToolbar;
import org.vietspider.ui.widget.CCombo;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 8, 2009  
 */
class URLSuggestion {

  protected List list;
  protected Shell popup;

  private CCombo _editor;
  private Text text; 
  
  private UIToolbar toolbar;
  
  private String pattern;

  public URLSuggestion(UIToolbar toolbar_, CCombo editor, String [] elements) {
    this.toolbar = toolbar_;
    text = editor.text;
    pattern = text.getText();

    popup = new Shell (editor.getShell(), SWT.NO_TRIM | SWT.ON_TOP);
    popup.setLayout(new FillLayout());
    
    this._editor = editor;

    _editor.getShell().addShellListener(new ShellAdapter() {
      @SuppressWarnings("unused")
      public void shellDeiconified(ShellEvent e) {
        popup.dispose();
      }
    });

    popup.addShellListener(new ShellAdapter() {
      @SuppressWarnings("unused")
      public void shellDeactivated(ShellEvent e) {
        popup.dispose();
      }
    });

    text.addFocusListener(new FocusAdapter() {
      @SuppressWarnings("unused")
      public void focusLost(FocusEvent e) {
        if(isDisposed()) return;
        if(text.isFocusControl() || list.isFocusControl()) return;
        popup.dispose();
      }
    });

    list = new List (popup, SWT.V_SCROLL | SWT.BORDER);  
    list.setBackground (ColorCache.getInstance().getWhite());
    list.setFont(text.getFont());
    list.setItems(elements);

    list.addKeyListener(new KeyListener() {
      public void keyReleased(KeyEvent event) {
        if(popup.isDisposed()) return;
        if(event.keyCode == SWT.ESC) {
          text.setText(pattern);
          text.setFocus();
          text.setSelection(pattern.length(), pattern.length());
          popup.dispose();
          
        } 
        if (event.keyCode == SWT.ARROW_UP || event.keyCode == SWT.ARROW_DOWN) {
          setValueToText();
          return;
        }
        
        if(event.keyCode == SWT.CR) {
          text.setFocus();
          toolbar.browse();
          popup.dispose();
          return;
        }
      }

      @Override
      public void keyPressed(KeyEvent event) {
        if (event.keyCode != SWT.ARROW_UP && event.keyCode != SWT.ARROW_DOWN) {
          if(Character.isLetterOrDigit(event.character) || 
              event.character == '!' || event.character == '%' ||
              event.character == '-' || event.character == '+' ||
              event.character == '*' || event.character == '/' ||
              event.character == '>' || event.character == '<' ||
              event.character == '=' || event.character == '|' ||
              event.character == '&' || event.character == ',' ||
              event.character == '.' ||  event.character == '^' 
          ) {
            int pos = text.getCaretPosition();
            String value = text.getText();
            value = value.substring(0, pos) + String.valueOf(event.character) + value.substring(pos);
            text.setText(value);
            text.setFocus();
            text.setSelection(pos+1, pos+1);
          }
          return;
        } 
      
      }
    });
   
    list.addMouseListener(new MouseAdapter() {
      @SuppressWarnings("unused")
      public void mouseDoubleClick(MouseEvent e) {
        setValueToText();
        popup.dispose();
        toolbar.browse();
        return;
      }
    });
    
    Display display = text.getDisplay();
    Rectangle parentRect = display.map (text.getParent(), null, text.getBounds ());

    int x = parentRect.x - 2 ;
    int y = parentRect.y + _editor.getSize().y;
    popup.setLocation(x, y);
    int height = list.getItemHeight()*Math.min(15, list.getItemCount())+ 15;
    popup.setSize(_editor.getSize().x, height);
    popup.setVisible(true);
  }

  public void dispose() {
    if(popup.isDisposed()) return;
    popup.dispose();
  }

  public boolean isDisposed() { return popup.isDisposed(); }

  void handleArrowKey(KeyEvent event) {
    int oldIndex = list.getSelectionIndex ();
    if (event.keyCode == SWT.ARROW_UP && popup.isVisible()) {
      select (Math.max (oldIndex - 1, 0));
    } else if( popup.isVisible()) {
      select (Math.min (oldIndex + 1, list.getItemCount () - 1));
    }
    if (oldIndex != list.getSelectionIndex ()) {
      Event e = new Event();
      e.time = event.time;
      e.stateMask = event.stateMask;
    }
    
    if(list.getSelectionCount() > 0) {
      setValueToText();
      list.setFocus();
    }
    event.doit = false;
  }

  public void select (int index) {
    if (index == -1) {
      list.deselectAll ();
      return;
    }

    if (0 <= index && index < list.getItemCount()) {
      if (index != list.getSelectionIndex()) {
        list.select (index);
        list.showSelection ();
      }
    }
  }

  void deselectAll () { list.deselectAll (); }

  public List getList() { return list; }
  
  private void setValueToText() {
    if(list.getSelectionCount() < 1) return;
    String url = list.getSelection()[0];
    int idx = url.indexOf("  -> "); 
    if(idx > -1) url = url.substring(0, idx);
    if(url !=  null) _editor.setText(url); 
  }
}
