package org.vietspider.content.vietstock;

import java.util.HashMap;
import java.util.Iterator;

import org.eclipse.swt.widgets.Control;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.client.common.PluginClientHandler;
import org.vietspider.common.util.Worker;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.waiter.ThreadExecutor;


/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 13, 2008  
 */
public class SyncContentPlugin extends org.vietspider.content.SyncContentPlugin {
  
  private ChannelSelector selector;
  
  public void invoke(Object...objects) {
    if(!enable || values == null || values.length < 1) return;
    final Control link = (Control) objects[0];
    if(selector == null) {
      loadChannel(link, values[0]);
      return;
    }
    selector.setMetaId(values[0]);
    selector.show();
  }
  
  private void loadChannel(final Control link, final String metaId) {
    Worker excutor = new Worker() {

      private String error = null;
      private HashMap<String, String> maps = new HashMap<String, String>();

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
      }

      public void execute() {
        try {
          PluginClientHandler handler = new PluginClientHandler();
          String value = handler.send("sync.content.to.database", "load.channel", (String)null);
          
          if(value.indexOf('/') < 1) { 
            error = value;
          } else {
            String [] elements = value.split("\n");
            for(String element : elements) {
              String [] data = element.split("/");
              if(data.length > 1) maps.put(data[0], data[1]);
            }
          }
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(link.getShell(), new Exception(error));
          return;
        }
        String [] channelIds = new String[maps.size()];
        String [] channelValues = new String[maps.size()];
        
        Iterator<String> iterator = maps.keySet().iterator();
        int index = 0;
        while(iterator.hasNext()) {
          channelIds[index] = iterator.next();
          channelValues[index] = maps.get(channelIds[index]);
          index++;
        }
        
        selector = new ChannelSelector(link.getShell(), channelIds, channelValues);
        selector.setMetaId(metaId);
      }
    };
    new ThreadExecutor(excutor, link).start();
  }
  

}
