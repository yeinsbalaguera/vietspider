/***************************************************************************
 * Copyright 2001-2010 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.tradekey;

import java.util.List;

import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.vietspider.chars.refs.RefsDecoder;
import org.vietspider.parser.xml.XMLNode;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 2, 2010  
 */
public class CategoryUtils {
  static String clean(String value) {
    int start = 0;
    while(start < value.length()) {
      char c = value.charAt(start);
      if(Character.isLetterOrDigit(c)) break;
      start++;
    }
    int end = value.length() - 1;
    while(end > 0) {
      char c = value.charAt(end);
      if(Character.isLetterOrDigit(c)) break;
      end--;
    }
    return value.substring(start, end+1);
  }
  
  static void searchTag(List<String> tags, XMLNode node, String name) {
    List<XMLNode> children  = node.getChildren();
    if(children == null) return;
    if(node.isNode(name)) {
      if(children.size() > 0 ) {
        String text = node.getChild(0).getTextValue();
        RefsDecoder decoder = new RefsDecoder();
        text = new String(decoder.decode(text.toCharArray()));
        String [] elements = text.split(",");
        for(int k = 0; k < elements.length; k++) {
          tags.add(clean(elements[k]));
        }
      }
    }
    for(int i = 0; i < children.size(); i++) {
      searchTag(tags, children.get(i), name);
    }
  }
  
  static void searchTreeItem(Tree tree, List<String> tags) {
    for(int i = 0;  i< tags.size(); i++) {
//      System.out.println(" ====================  >"+ tags.get(i));
      TreeItem item  = searchTreeItem(tree.getItems(), tags.get(i));
      if(item == null) continue;
      tree.setSelection(item);
      tree.setFocus();
      return;
    }
  }
  
  static TreeItem searchTreeItem2(Tree tree, List<String> tags) {
    for(int i = 0;  i< tags.size(); i++) {
//      System.out.println(" ====================  >"+ tags.get(i));
      TreeItem item  = searchTreeItem(tree.getItems(), tags.get(i));
      if(item == null) continue;
      return item;
    }
    return null;
  }
  
  static TreeItem searchTreeItem(TreeItem [] items, String category) {
    if(items == null) return null;
    for(int i = 0; i < items.length; i++) {
//      System.out.println(items[i].getText());
      if(items[i].getText().equalsIgnoreCase(category)) return items[i];
      TreeItem item = searchTreeItem(items[i].getItems(), category);
      if(item != null) return item;
    }
    
    return null;
  }
}
