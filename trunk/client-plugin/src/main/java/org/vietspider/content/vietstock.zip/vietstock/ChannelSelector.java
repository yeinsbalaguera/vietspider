/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.vietstock;

import java.util.prefs.Preferences;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.client.common.PluginClientHandler;
import org.vietspider.common.util.Worker;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.ApplicationFactory;
import org.vietspider.ui.widget.UIDATA;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 15, 2008  
 */
class ChannelSelector {
  
  private Shell shell;

  private String [] channelIDs;
  
  private Button [] buttons;
  
  private Text txtUserId;
  
  private Button butImage;
  
  private boolean isSaveImage = false;
  
  private String metaId;
  
  protected ScrolledComposite scrolled;
  
  ChannelSelector(Shell parent, String [] ids, String [] values) {
    shell = new Shell(parent, SWT.TITLE | SWT.RESIZE | SWT.APPLICATION_MODAL);
    ApplicationFactory factory = new ApplicationFactory(shell, "VietStock", getClass().getName());
    shell.setText(factory.getLabel("title"));
    factory.setComposite(shell);
    shell.setLayout(new GridLayout(1, false));
    
    this.channelIDs = ids;
    
    final org.eclipse.swt.widgets.Group group ;
    factory.setComposite(shell);
    
    scrolled = new ScrolledComposite(shell, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
    
    GridData gridData = new GridData(GridData.FILL_BOTH);
    GridLayout gridLayout = new GridLayout(3, false);
    factory.setComposite(scrolled);
    group = factory.createGroup("grpChannel", gridData, gridLayout);
    factory.setComposite(group);
    
    buttons = new Button[values.length];
    for(int i = 0; i < buttons.length; i++) {
      buttons[i] = new Button(group, SWT.RADIO);
      buttons[i].setText(values[i]);
      buttons[i].setFont(UIDATA.FONT_9);
    }
    
    scrolled.setLayoutData(new GridData(GridData.FILL_BOTH));
    scrolled.setContent(group);
    scrolled.setExpandHorizontal(true);
    scrolled.setExpandVertical(true);

    scrolled.addControlListener(new ControlAdapter() {
      @SuppressWarnings("unused")
      public void controlResized(ControlEvent e) {
        Rectangle r = scrolled.getClientArea();
        scrolled.setMinSize(group.computeSize(r.width, SWT.DEFAULT));
      }
    });
    
    Composite bottomComposite = new Composite(shell, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
//    gridData.horizontalSpan = 2;
    bottomComposite.setLayoutData(gridData);
    RowLayout rowLayout = new RowLayout();
    bottomComposite.setLayout(rowLayout);
    rowLayout.justify = true;
    factory.setComposite(bottomComposite);
    
    Composite imageComposite = new Composite(bottomComposite, SWT.NONE);
    rowLayout = new RowLayout();
    imageComposite.setLayout(rowLayout);
    rowLayout.justify = true;
    factory.setComposite(imageComposite);
    
    butImage = factory.createButton("butImage", SWT.CHECK,  new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        isSaveImage = butImage.getSelection();
      }   
    }); 
    
    Composite userComposite = new Composite(bottomComposite, SWT.NONE);
    gridLayout = new GridLayout(2, false);
    gridLayout.marginHeight = 0;
    gridLayout.horizontalSpacing = 0;
    gridLayout.verticalSpacing = 0;
    gridLayout.marginWidth = 0;
    userComposite.setLayout(gridLayout);
    
    factory.setComposite(userComposite);
    factory.createLabel("lblUserId");   
    txtUserId = factory.createText();
    String userid  = "";
    try {
      Preferences prefs = Preferences.userNodeForPackage(ChannelSelector.class);
      String vusername = ClientConnector2.currentInstance().getUsername();
      userid  = prefs.get(vusername + ".account.username", "");
    } catch (Exception e) {
      
    }
    if(userid == null || userid.trim().isEmpty()) userid  = "9";
    txtUserId.setText(userid);
    gridData = new GridData();
    gridData.widthHint = 20;
    txtUserId.setLayoutData(gridData);
    
    Composite bottom = new Composite(shell, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
//    gridData.horizontalSpan = 2;
    bottom.setLayoutData(gridData);
    rowLayout = new RowLayout();
    bottom.setLayout(rowLayout);
    rowLayout.justify = true;
    
    factory.setComposite(bottom);
    
    factory.createButton("butOk", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        for(int i = 0; i < buttons.length; i++) {
          if(!buttons[i].getSelection()) continue;
          synchronizedData(channelIDs[i]);
          break;
        }
      }   
    }); 
    
    factory.createButton("butClose", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        shell.setVisible(false);
      }   
    });
   
    Rectangle displayRect = UIDATA.DISPLAY.getBounds();
    int x = (displayRect.width - 350) / 2;
    int y = (displayRect.height - 300)/ 2;
    shell.setImage(parent.getImage());
    shell.setLocation(x, y);
    shell.setSize(650, 400);
    shell.open();
  }
  
  public void show() {  shell.setVisible(true);  }

  public boolean isSaveImage() { return isSaveImage; }

  public void setMetaId(String metaId) { this.metaId = metaId; }
  
  private void synchronizedData(final String selectedChannel) {
    if(txtUserId.getText().trim().isEmpty()) {
      ClientLog.getInstance().setMessage(txtUserId.getShell(), new Exception("Please, enter user id"));
      return;
    }
    
    Preferences prefs = Preferences.userNodeForPackage(ChannelSelector.class);
    String username_ = ClientConnector2.currentInstance().getUsername();
    prefs.put(username_ + ".account.username", txtUserId.getText());
    
    Worker excutor = new Worker() {

      private String error = null;
      private String userId;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
        userId = txtUserId.getText();
      }

      public void execute() {
        try {
          StringBuilder builder = new StringBuilder(metaId);
          builder.append('\n').append(selectedChannel).
          append('\n').append(isSaveImage).append('\n').append(userId);
          PluginClientHandler handler = new PluginClientHandler();
          error = handler.send("sync.content.to.database", "save", builder.toString());
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(shell, new Exception(error));
          return;
        } 
        ClientLog.getInstance().setMessage(shell, new Exception("Synchronized Successfull!"));
        shell.setVisible(false);
      }
    };
    new ThreadExecutor(excutor, shell).start();
  }

}
