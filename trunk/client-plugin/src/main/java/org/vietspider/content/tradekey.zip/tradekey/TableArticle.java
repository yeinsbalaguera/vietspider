/***************************************************************************
 * Copyright 2001-2010 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.tradekey;


import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.TreeItem;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.client.common.PluginClientHandler;
import org.vietspider.common.util.Worker;
import org.vietspider.parser.xml.XMLDocument;
import org.vietspider.parser.xml.XMLParser;
import org.vietspider.ui.widget.UIDATA;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 2, 2010  
 */
public class TableArticle {

  private Table tblArticles;
  private int size = 10;
  protected TableEditor [] editors;
  protected String [] ids;
  protected String [] categoryIds;
  protected String [] categoryNames;
  private TreeCategories treeCategories;
  
  private Color defaultColor;
  private Color selectedColor;

  public TableArticle(Composite parent, int size) {
    this.size = size;
    tblArticles = new Table(parent, SWT.BORDER);
    tblArticles.setFont(UIDATA.FONT_10);
    tblArticles.setLinesVisible(true);
    tblArticles.setHeaderVisible(false);
    
    defaultColor = new Color(tblArticles.getDisplay(), 255, 255, 255);
    selectedColor = new Color(tblArticles.getDisplay(), 225, 240, 255);

    TableColumn column1 = new TableColumn(tblArticles, SWT.LEFT);
    column1.setText("Title");
    column1.setWidth(350);

    TableColumn column3 = new TableColumn(tblArticles, SWT.LEFT);
    column3.setText("Post?");
    column3.setWidth(50);

    editors = new TableEditor[size];

    for(int i = 0; i < size; i++) {
      TableItem item  = new TableItem(tblArticles, SWT.NONE);
      item.setText(0, "");

      editors[i] = new TableEditor(tblArticles);
      Button button = new Button(tblArticles, SWT.CHECK);
      button.pack();

      //    button.computeSize(SWT.DEFAULT, tableWebsite.getItemHeight()+ 20);
      editors[i].horizontalAlignment = SWT.CENTER;
      editors[i].minimumWidth = button.getSize().x;
      editors[i].setEditor(button, item, 1);

      editors[i].setItem(item);
    }

    final int TEXT_MARGIN2 = 3;
    tblArticles.addListener(SWT.MeasureItem, new Listener() {
      public void handleEvent(Event event) {
        TableItem item = (TableItem)event.item;
        String text = item.getText(event.index);
        Point _size = event.gc.textExtent(text);
        event.width = _size.x + 2 * TEXT_MARGIN2;
        event.height = Math.max(event.height, _size.y + TEXT_MARGIN2);
      }
    });
    tblArticles.addListener(SWT.EraseItem, new Listener() {
      public void handleEvent(Event event) {
        event.detail &= ~SWT.FOREGROUND;
      }
    });
    tblArticles.addListener(SWT.PaintItem, new Listener() {
      public void handleEvent(Event event) {
        TableItem item = (TableItem)event.item;
        String text = item.getText(event.index);
        int yOffset = 0;
        //        if (event.index == 5) {
        Point _size = event.gc.textExtent(text);
        yOffset = Math.max(0, (event.height - _size.y) / 2);
        //        }
        event.gc.drawText(text, event.x + TEXT_MARGIN2, event.y + yOffset, true);
      }
    });

  }

  public void setData(String[] ids, String[] titles) {
    this.ids = ids;
    int max = Math.min(size, ids.length);
    TableItem [] items = tblArticles.getItems();
    int i = 0; 
    for(;i < max; i++) {
      items[i].setText(0, titles[i]+ "\n No Category");
      items[i].setBackground(defaultColor);
      ((Button)editors[i].getEditor()).setSelection(false);
    }
    for(; i < items.length; i++) {
      items[i].setText(0, "");
      items[i].setBackground(defaultColor);
      ((Button)editors[i].getEditor()).setSelection(false);
    }
    
    this.categoryNames = new String[items.length];
    this.categoryIds = new String[items.length];
    autoSelectCategories(0);
  }

  void setTree(TreeCategories _treeCategories) {
    this.treeCategories = _treeCategories;
    treeCategories.getTree().addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")      
      public void widgetSelected(SelectionEvent evt) {
        String [] elements = treeCategories.getSelected();
        if(elements == null) return;
        int selectedIndex = tblArticles.getSelectionIndex();
        if(selectedIndex < 0) selectedIndex = 0;
        setCateForItem(elements[0], elements[1], selectedIndex);
      }
    });

    tblArticles.addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        int selectedIndex = tblArticles.getSelectionIndex();
        if(selectedIndex < 0) return;
        String id = categoryIds[selectedIndex];
        if(id == null) return;
        treeCategories.setSelectById(id);
      }

    });
  }

  List<TradeKeySyncData> getSelectedArticles() {
    List<TradeKeySyncData> list = new ArrayList<TradeKeySyncData>();
    TableItem [] items = tblArticles.getItems();
    for(int i = 0; i < Math.min(items.length, ids.length); i++) {
      Button but = (Button) editors[i].getEditor();
      if(!but.getSelection()) continue;
      TradeKeySyncData syncData = new TradeKeySyncData();
      syncData.setArticleId(ids[i]);
      syncData.setCategoryId(categoryIds[i]);
      list.add(syncData);
    }
    return list;
  }

  void autoSelectCategories(final int index) {
    Worker excutor = new Worker() {

      private List<String> tags ;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
        tags = new ArrayList<String>();
      }

      public void execute() {
        try {
          PluginClientHandler handler = new PluginClientHandler();
          String value  = handler.send("tradekey.sync.data.plugin", "load.content", ids[index]);
          XMLDocument document = XMLParser.createDocument(value, null);
          CategoryUtils.searchTag(tags, document.getRoot(), "cf28");
        } catch (Exception e) {
        }
      }

      public void after() {
        TreeItem item = CategoryUtils.searchTreeItem2(treeCategories.getTree(), tags);
        if(item == null) {
          autoSelectCategories(index+1);
          return;
        }

        String category  = (String)item.getData();
        int idx = category.indexOf('/');
        if(idx < 0) {
          autoSelectCategories(index+1);
          return;
        }
        String cateId = category.substring(0, idx);
        String cateName = category.substring(idx+1);
        setCateForItem(cateId, cateName, index);
        autoSelectCategories(index+1);
      }
    };
    new ThreadExecutor(excutor, tblArticles).start();
  }
  
  private void setCateForItem(String cateId, String cateName, int index) {
    categoryIds[index] = cateId;
    categoryNames[index] = cateName;
    String text = tblArticles.getItem(index).getText();
    int idx = text.indexOf('\n');
    if(idx > 0) text = text.substring(0, idx);
    text += "\n" + cateName;
    tblArticles.getItem(index).setText(0, text);
    tblArticles.getItem(index).setBackground(selectedColor);
    ((Button)editors[index].getEditor()).setSelection(true);
  }


}
