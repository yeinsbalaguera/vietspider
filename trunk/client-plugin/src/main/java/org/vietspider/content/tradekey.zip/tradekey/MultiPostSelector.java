/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.tradekey;

import java.util.List;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.common.util.Worker;
import org.vietspider.content.cms.sync.SyncManager2;
import org.vietspider.model.plugin.Category;
import org.vietspider.net.server.URLPath;
import org.vietspider.serialize.XML2Object;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.services.ClientRM;
import org.vietspider.ui.widget.ApplicationFactory;
import org.vietspider.ui.widget.ShellGetter;
import org.vietspider.ui.widget.ShellSetter;
import org.vietspider.ui.widget.UIDATA;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/**
 * Author : Nhu Dinh Thuan nhudinhthuan@yahoo.com Aug 15, 2008
 */
class MultiPostSelector {

  private static final String UNUSED = "unused";

  private Shell shell;
  private TableArticle tblArticle;
  private TreeCategories treeCategories;

  private List<Category> categories;

  private TradeKeySyncDataPlugin plugin;

  MultiPostSelector(Shell parent, ClientRM resource) {
    shell = new Shell(parent, SWT.CLOSE | SWT.RESIZE | SWT.APPLICATION_MODAL);
    ApplicationFactory factory = new ApplicationFactory(shell, resource, getClass().getName());
    shell.setText("Synchronized data");
    factory.setComposite(shell);
    shell.setLayout(new GridLayout(1, false));

    shell.addShellListener(new ShellAdapter() {
      public void shellClosed(ShellEvent e) {
        new ShellSetter(MultiPostSelector.class, shell);
        shell.setVisible(false);
        e.doit = false;
      }
    });

    factory.setComposite(shell);

    GridData gridData = new GridData(GridData.FILL_BOTH);

    SashForm sashMain = new SashForm(shell, SWT.HORIZONTAL);
    sashMain.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_WIDGET_BACKGROUND));
    gridData = new GridData(GridData.FILL_BOTH);    
    gridData.grabExcessHorizontalSpace = true;
    sashMain.setLayoutData(gridData);

    tblArticle = new TableArticle(sashMain, 10);

    treeCategories = new TreeCategories(sashMain, null);
    tblArticle.setTree(treeCategories);
    Menu menu = new Menu(factory.getComposite().getShell(), SWT.POP_UP);
    treeCategories.getTree().setMenu(menu);
    MenuItem item =  new MenuItem(menu, SWT.NONE);
    item.setText("Reload Categories");    
    item.addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        loadCategries();
      }
    });
    //  treeCategories.setLinesVisible(false);

    Composite bottom = new Composite(shell, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    // gridData.horizontalSpan = 2;
    bottom.setLayoutData(gridData);
    RowLayout rowLayout = new RowLayout();
    bottom.setLayout(rowLayout);
    rowLayout.justify = true;
    factory.setComposite(bottom);

//    if(XPWidgetTheme.isPlatform()) {
//      factory.createCButton("butNextPage", new SelectionAdapter() {
//        @SuppressWarnings(UNUSED)
//        public void widgetSelected(SelectionEvent evt) {
//          if(plugin != null) plugin.nextPage();
//        }
//      });
//    } else {
      factory.createButton("butNextPage", new SelectionAdapter() {
        @SuppressWarnings(UNUSED)
        public void widgetSelected(SelectionEvent evt) {
          if(plugin != null) plugin.nextPage();
        }
      });
//    }

    SelectionAdapter syncListener = new SelectionAdapter() {
      @SuppressWarnings(UNUSED)
      public void widgetSelected(SelectionEvent evt) {
        List<TradeKeySyncData> datas = tblArticle.getSelectedArticles();
        for(int i = 0; i < datas.size(); i++) {
          //          System.out.println(" chuan bi sync "+ datas.get(i).getArticleId());
          SyncManager2.getInstance(shell).sync(datas.get(i));
        }
        if(plugin != null) plugin.nextPage();
      }
    };

//    if(XPWidgetTheme.isPlatform()) {
//      factory.createCButton("butOk", syncListener);
//    } else {
      factory.createButton("butOk", syncListener);
//    }

//    if(XPWidgetTheme.isPlatform()) {
//      factory.createCButton("butClose", new SelectionAdapter() {
//        @SuppressWarnings(UNUSED)
//        public void widgetSelected(SelectionEvent evt) {
//          new ShellSetter(MultiPostSelector.class, shell);
//          shell.setVisible(false);
//        }
//      });
//    } else {
      factory.createButton("butClose", new SelectionAdapter() {
        @SuppressWarnings(UNUSED)
        public void widgetSelected(SelectionEvent evt) {
          new ShellSetter(MultiPostSelector.class, shell);
          shell.setVisible(false);
        }
      });
//    }


    loadCategries();

    Rectangle displayRect = UIDATA.DISPLAY.getBounds();
    int x = (displayRect.width - 350) / 2;
    int y = (displayRect.height - 300) / 2;
    shell.setImage(parent.getImage());
    new ShellGetter(MultiPostSelector.class, shell, 450, 300, x, y);
//    XPWidgetTheme.setWin32Theme(shell);
    shell.open();
  }

  public void setData(String[] ids, String[] titles) {
    if(treeCategories.getTree().getItemCount() < 1) loadCategries();
    tblArticle.setData(ids, titles);
    shell.setVisible(true);
  }

  public void loadCategries() {
    Worker excutor = new Worker() {

      private String error = null;
      private XMLTradeKeyConfig config;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
      }

      public void execute() {
        try {
          Header[] headers = new Header[] {
              new BasicHeader("action", "load.file"),
              new BasicHeader("file", "system/plugin/tradekey.config") 
          };

          ClientConnector2 connector = ClientConnector2.currentInstance();
          byte[] bytes = connector.post(URLPath.FILE_HANDLER, new byte[0], headers);

          config = XML2Object.getInstance().toObject(XMLTradeKeyConfig.class, bytes);
        } catch (Exception e) {
          error = e.toString();
        }

      }

      public void after() {
        if (error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(shell, new Exception(error));
          return;
        }
        if (config == null) return;
        categories = config.getCategories();
        treeCategories.getTree().removeAll();
        treeCategories.createCategories(categories);
      }
    };
    new ThreadExecutor(excutor, shell).start();
  }

  public void invokeSetup() {
    new TradeKeySetup(shell.getShell());
  }

  public void setPlugin(TradeKeySyncDataPlugin plugin) {
    this.plugin = plugin;
  }


}
