/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.tradekey;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.vietspider.chars.refs.RefsDecoder;
import org.vietspider.common.io.RWData;
import org.vietspider.common.io.UtilFile;
import org.vietspider.html.HTMLDocument;
import org.vietspider.html.HTMLNode;
import org.vietspider.html.Name;
import org.vietspider.html.NodeIterator;
import org.vietspider.html.parser.HTMLParser2;
import org.vietspider.model.plugin.Category;
import org.vietspider.net.client.HttpMethodHandler;
import org.vietspider.net.client.WebClient;
import org.vietspider.token.attribute.Attribute;
import org.vietspider.token.attribute.Attributes;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 24, 2009  
 */
public class CategoriesDetector {

//  private String loginURL;
  private String homepage;

//  private String username;
//  private String password;

  private  WebClient webClient = new WebClient();

  private List<Category> categories = new ArrayList<Category>();

  public CategoriesDetector(String homepage/*, String loginURL, String username, String password*/) {
    this.homepage = homepage;
//    this.loginURL  = loginURL;
//    this.username = username;
//    this.password = password;
  }

  public void detect(String url) throws Exception {
    categories = detectSingle(url);
    for(int i = 0; i < categories.size(); i++) {
      detectSubCategories(url, categories.get(i));
    }
  }

  private void detectSubCategories(String url, Category category) throws Exception {
    StringBuilder builder = new StringBuilder(url);
    builder.append("index.php?option=com_mtree&task=listcats&cat_id=");
    builder.append(category.getCategoryId()); 
    List<Category> subCategories = detectSingle(builder.toString());
    if(subCategories.size() < 1) return;
    category.setSubCategories(subCategories);
    for(int i = 0; i < subCategories.size(); i++) {
      detectSubCategories(url, subCategories.get(i));
    }
  }

  private List<Category> detectSingle(String url)  throws Exception {
//    System.out.println(" = ===  >"+ url);
    List<Category> list = new ArrayList<Category>();
    //    System.out.println(" homepage "+ homepage);
    //    System.out.println(" login  "+loginURL );
    //    System.out.println(" cateURL "+ url);
    //    System.out.println(username+ " : "+ password);
    webClient.setURL(homepage, new URL(homepage));

    //    HttpMethodHandler handler = new HttpMethodHandler(webClient);
    //    HttpSessionUtils httpSession = new HttpSessionUtils(handler, "Error");
    //    StringBuilder builder = new StringBuilder(loginURL).append('\n');
    //    builder.append(username).append(':').append(password);
    //    boolean login = httpSession.login(builder.toString(), "utf-8", new URL(homepage), homepage);
    //    if(!login) throw new Exception("Cann't login to website!");

    byte [] data = get(url, 0);
    HTMLDocument document = new HTMLParser2().createDocument(data, "utf-8");
    //    System.out.println(document.getTextValue());
    NodeIterator iterator = document.getRoot().iterator();
    while(iterator.hasNext()) {
      HTMLNode node = iterator.next();
      if(!node.isNode(Name.DIV)) continue;
      String text = new String(node.getValue());
      if(text.indexOf("moduletable_menu") < 0) continue;
      detectNode(list, node);
      break;
    }
    return list;
  }

  private void detectNode(List<Category> list, HTMLNode root) {
    NodeIterator iterator = root.iterator();
    while(iterator.hasNext()) {
      HTMLNode node = iterator.next();
      if(!node.isNode(Name.A)) continue;
      Attributes attributes = node.getAttributes(); 
      Attribute attribute = attributes.get("href");
      if(attribute == null) continue;
      String link  = attribute.getValue();
      if(link.indexOf("cat_id") < 0 
          || link.indexOf("listcats") < 0) continue; 
      detectNode(list, node, link);
    }
  }

  private void detectNode(List<Category> list, HTMLNode node, String link) {
    String id = getId(link);
//    System.out.println(link +" === > "+ id);
    if(id == null || contains(categories, id) || contains(list, id)) return;
    
    for(int i = 0; i < list.size(); i++) {
      if(id.equals(list.get(i).getCategoryId())) return;
    }

    if(node.getChildren().size() < 1) return;
    String name = node.getChild(0).getTextValue().trim();
    if(name.isEmpty()) return;

    RefsDecoder decoder = new RefsDecoder();
    name = new String(decoder.decode(name.toCharArray()));
    Category category = new Category();
    category.setCategoryName(name);
    category.setCategoryId(id);
    list.add(category);
  }

  private boolean contains(List<Category>list, String id) {
    for(int i = 0; i < list.size(); i++) {
      Category category = list.get(i);
      if(category.getCategoryId().equals(id)) return true;
      if(contains(category.getSubCategories(), id)) return true; 
    }
    return false;
  }

  private String getId(String link) {
    int start = link.indexOf("cat_id");
    if(start < 0) return null;
    int end  = link.indexOf("&", start);
    if(end == -1) end  = link.length();
    if(start+6 >= end) return null;
    String id = link.substring(start+7, end);
    if(id.trim().isEmpty()) return null;
    if(id.indexOf('#') > -1) return null;
    return id;
  }

  public List<Category> getCategories() {
    return categories;
  }

  public void setCategories(List<Category> categories) {
    this.categories = categories;
  }

  public byte[] get(String url, int time) throws Exception {
    try {
      byte [] bytes = loadCached(url);
      if(bytes != null) return bytes;
      
      HttpMethodHandler httpMethod = new HttpMethodHandler(webClient);
      HttpResponse response = httpMethod.execute(url, homepage);
      if(response == null) throw new Exception("No response!");

      StatusLine statusLine = response.getStatusLine();
      int statusCode = statusLine.getStatusCode();

      switch (statusCode) {
      case HttpStatus.SC_NOT_FOUND:
      case HttpStatus.SC_NO_CONTENT:
      case HttpStatus.SC_BAD_REQUEST:
      case HttpStatus.SC_REQUEST_TIMEOUT:
      case HttpStatus.SC_NOT_ACCEPTABLE:
      case HttpStatus.SC_SERVICE_UNAVAILABLE:
      case 999:{
        throw new Exception(url + " " + statusLine.getReasonPhrase());
      }
      default:
        break;
      }

      byte [] data = httpMethod.readBody();
      if(data.length > 100) saveCached(url, data);
      return data;
    } catch (Exception e) {
      if(time >= 3) throw e; 
      return get(url, time+1);
    }
  }

  private byte[] loadCached(String url) throws Exception {
    File folder = UtilFile.getFolder("system/plugin/cached/");
    File file  = new File(folder, String.valueOf(url.hashCode()));
    if(file.exists() && file.length() > 10) return RWData.getInstance().load(file);
    return null;
  }

  private void saveCached(String url, byte [] bytes) throws Exception {
    File folder = UtilFile.getFolder("system/plugin/cached/");
    File file  = new File(folder, String.valueOf(url.hashCode()));
    RWData.getInstance().save(file, bytes);
  }

}
