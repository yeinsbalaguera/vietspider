/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.tradekey;

import java.util.List;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TreeItem;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.common.util.Worker;
import org.vietspider.content.cms.CMSChannelSelector;
import org.vietspider.content.cms.sync.SyncManager2;
import org.vietspider.model.plugin.Category;
import org.vietspider.net.server.URLPath;
import org.vietspider.serialize.XML2Object;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.services.ClientRM;
import org.vietspider.ui.widget.ApplicationFactory;
import org.vietspider.ui.widget.ShellGetter;
import org.vietspider.ui.widget.ShellSetter;
import org.vietspider.ui.widget.UIDATA;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 15, 2008  
 */
class SinglePostSelector extends CMSChannelSelector {
  
  private List<Category> categories;
  private TreeCategories treeCategories;
//  private Button butPublished;
//  private Button butFrontpage;
  
  private boolean isShowMessage = true;
  
  SinglePostSelector(Shell parent, ClientRM rm) {
    super("tradekey", parent, rm, "TradeKey Plugin");
  }
  
  @Override
  @SuppressWarnings("unused")
  protected void createOption(String plugin, ApplicationFactory factory) {
    Composite optionComposite = new Composite(factory.getComposite(), SWT.NONE);
    GridData gridData = new GridData(GridData.FILL_HORIZONTAL);
//    gridData.horizontalSpan = 2;
    optionComposite.setLayoutData(gridData);
//    rowLayout = new RowLayout();
    optionComposite.setLayout(new GridLayout(2, false));
//    rowLayout.justify = true;
    
    Composite userComposite = new Composite(optionComposite, SWT.NONE);
    userComposite.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
    GridLayout gridLayout = new GridLayout(1, false);
    userComposite.setLayout(gridLayout);
    factory.setComposite(userComposite);
    
//    File licenseFile = LicenseVerifier.loadLicenseFile();
//    boolean license = LicenseVerifier.verify(licenseFile);
    
    Composite articleComposite = new Composite(optionComposite, SWT.NONE);
    gridLayout = new GridLayout(1, false);
    articleComposite.setLayout(gridLayout);
    factory.setComposite(articleComposite);
  }
  
  public void invokeSetup() {
    new TradeKeySetup(shell.getShell());
  }
  
  public void sync() {
    new ShellSetter(SinglePostSelector.this.getClass(), shell);
    shell.setVisible(false); 
    
    String cateId = treeCategories.getSelectedId();
    if(cateId == null) {
      ClientLog.getInstance().setMessage(shell, new Exception("No category"));
      return;
    }
    
//    System.out.println(" ====> "+ category+ " : " + category.substring(0, index));
    
    TradeKeySyncData syncData = new TradeKeySyncData();
    syncData.setArticleId(metaId);
    syncData.setCategoryId(cateId);
    syncData.setDebug(butDebug.getSelection());
    
    syncData.setShowMessage(isShowMessage);
    
    SyncManager2.getInstance(shell).sync(syncData);
  }
  
  public void setMetaId(String metaId) {
    super.setMetaId(metaId);
    treeCategories.getTree().setSelection(new TreeItem[0]);
//    if(butChannels != null) loadDefaultCategory("tradekey.sync.data.plugin");
    treeCategories.autoSelectCategory(metaId);
  }
  
  public void loadCategries() {
    Worker excutor = new Worker() {

      private String error = null;
      private XMLTradeKeyConfig config;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
      }

      public void execute() {
        try {
          Header [] headers = new Header[] {
              new BasicHeader("action", "load.file"),
              new BasicHeader("file", "system/plugin/tradekey.config")
          };
          
          ClientConnector2 connector = ClientConnector2.currentInstance();
          byte [] bytes = connector.post(URLPath.FILE_HANDLER, new byte[0], headers);

          config = XML2Object.getInstance().toObject(XMLTradeKeyConfig.class, bytes);
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(shell, new Exception(error));
          return;
        }
        if(config == null) return;
        
        treeCategories.getTree().removeAll();
        categories = config.getCategories();
        treeCategories.createCategories(categories);
        
        isShowMessage = config.isAlertMessage();
        
        if(butChannels != null) loadDefaultCategory("tradekey.sync.article.plugin");
      }
    };
    new ThreadExecutor(excutor, shell).start();
  }
  
  protected void init(Shell parent, ApplicationFactory factory, String title) {
    shell = new Shell(parent, SWT.CLOSE | SWT.RESIZE | SWT.APPLICATION_MODAL);
    factory.setComposite(shell);
    shell.setText(title);
    shell.setLayout(new GridLayout(1, false));

    shell.addShellListener(new ShellAdapter() {
      public void shellClosed(ShellEvent e) {
        shell.setVisible(false);
        e.doit = false;
      }
    });

    final KeyAdapter keyAdapter = new KeyAdapter() {
      public void keyPressed(KeyEvent event) {
        if(event.keyCode == SWT.CR) sync();
      }
    };

    Composite main = new Composite(shell, SWT.NONE);
    main.setLayout(new GridLayout(1, false));
    GridData gridData = new GridData(GridData.FILL_BOTH);
    main.setLayoutData(gridData);
    factory.setComposite(main);

    gridData = new GridData(GridData.FILL_BOTH);
    treeCategories = new TreeCategories(main, gridData);
    Menu menu = new Menu(factory.getComposite().getShell(), SWT.POP_UP);
    treeCategories.getTree().setMenu(menu);
    MenuItem item =  new MenuItem(menu, SWT.NONE);
    item.setText("Reload Categories");    
    item.addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        loadCategries();
      }
    });
//    treeCategories.setLinesVisible(false);
  
    factory.setComposite(main);
    
    butDebug = factory.createButton(SWT.CHECK);
    butDebug.setText("Log error?");
    butDebug.setFont(UIDATA.FONT_10);

    factory.setComposite(main);
    createOption(null, factory);

    factory.setComposite(main);
    createButton(factory, keyAdapter);

    loadCategries();
    
    Rectangle displayRect = UIDATA.DISPLAY.getBounds();
    int x = (displayRect.width - 340) / 2;
    int y = (displayRect.height - 280)/ 2;
    new ShellGetter(SinglePostSelector.class, shell, 550, 300, x, y);
//    XPWidgetTheme.setWin32Theme(shell);
    shell.open();
  }

}
