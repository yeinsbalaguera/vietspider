package org.vietspider.content.thegioixe;

import org.eclipse.swt.widgets.Control;
import org.vietspider.content.drupal.DrupalSyncArticlePlugin;

/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/

/**
 * Author : Nhu Dinh Thuan nhudinhthuan@yahoo.com Aug 13, 2008
 */

public class TGXSyncArticlePlugin extends DrupalSyncArticlePlugin {

	public TGXSyncArticlePlugin() {
	  
	}
	
	public void invokeSetup(Object...objects) {
    if(objects == null || objects.length < 1) return;
    
    final Control link = (Control) objects[0];
    new TGXSetup(link.getShell());
  }

}