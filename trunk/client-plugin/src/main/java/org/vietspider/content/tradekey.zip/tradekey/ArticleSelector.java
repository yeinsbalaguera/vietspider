package org.vietspider.content.tradekey;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.vietspider.ui.widget.UIDATA;

public class ArticleSelector extends Composite {

  private String articleID;

  private Button butTitle;
  private Label lblCategory;
  private String cateId;

  private boolean isShowMessage = true;

  private int index;

  // private Text txtTitle;

  public ArticleSelector(Composite parent, int index) {
    super(parent, SWT.TRANSPARENCY_ALPHA);
    
    setBackgroundMode(SWT.INHERIT_DEFAULT);
    setBackground(new Color(getDisplay(), 255, 255, 255));

    this.index = index;

    GridLayout gridLayout = new GridLayout(1, false);
    setLayout(gridLayout);
    setSize(350, 80);

    butTitle = new Button(this, SWT.CHECK);
    butTitle.setSelection(true);
    GridData gridData = new GridData(GridData.FILL_HORIZONTAL | GridData.HORIZONTAL_ALIGN_END);
    gridData.horizontalSpan = 1;
    butTitle.setToolTipText("Post to TradeKey?");
    butTitle.setFont(UIDATA.FONT_8TB);
    
    lblCategory = new Label(this, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    lblCategory.setLayoutData(gridData);

  }

  void setArticle(String id,
      String title, String cateName, String cateId) {
    this.articleID = id;
    this.cateId = cateId;
    butTitle.setText(String.valueOf(index)+". " + title);
    butTitle.setEnabled(id != null && id.trim().length() > 0);
    butTitle.setSelection(true);
    
    this.setToolTipText(title);

    lblCategory.setText(cateName);

  }

  public boolean enableSelection() {  return butTitle.isEnabled(); }

  public TradeKeySyncData getSyncData() {
    if(!butTitle.isEnabled()) return null;
    if(!butTitle.getSelection()) return null;
    TradeKeySyncData syncData = new TradeKeySyncData();
    syncData.setArticleId(articleID);
    syncData.setCategoryId(cateId);
    syncData.setShowMessage(isShowMessage);

    butTitle.setEnabled(false);
    return syncData;
  }

  void setShowMessage(boolean isShowMessage) {
    this.isShowMessage = isShowMessage;
  }
}
