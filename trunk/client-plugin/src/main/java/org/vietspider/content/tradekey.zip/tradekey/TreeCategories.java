/***************************************************************************
 * Copyright 2001-2010 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.tradekey;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.client.common.PluginClientHandler;
import org.vietspider.common.util.Worker;
import org.vietspider.parser.xml.XMLDocument;
import org.vietspider.parser.xml.XMLParser;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 2, 2010  
 */
public class TreeCategories extends org.vietspider.content.cms.CommonCategoriesTree {

  public TreeCategories(Composite parent, GridData gridData) {
    super(parent, gridData);
  }
  
  void autoSelectCategory(final String id) {
    Worker excutor = new Worker() {
      
      private List<String> tags ;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
        tags = new ArrayList<String>();
      }

      public void execute() {
        try {
          PluginClientHandler handler = new PluginClientHandler();
          String value  = handler.send("tradekey.sync.data.plugin", "load.content", id);
          XMLDocument document = XMLParser.createDocument(value, null);
          CategoryUtils.searchTag(tags, document.getRoot(), "cf28");
        } catch (Exception e) {
        }
      }

      public void after() {
        CategoryUtils.searchTreeItem(tree, tags);
      }
    };
    new ThreadExecutor(excutor, tree).start();
  }
  
  
 
}
