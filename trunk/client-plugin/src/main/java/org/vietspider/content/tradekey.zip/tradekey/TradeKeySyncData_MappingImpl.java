package org.vietspider.content.tradekey;


import org.vietspider.content.tradekey.TradeKeySyncData;
import org.vietspider.token.attribute.*;
import org.vietspider.parser.xml.XMLNode;
import org.vietspider.serialize.Object2XML;
import org.vietspider.serialize.XML2Object;
import org.vietspider.serialize.SerializableMapping;


public class TradeKeySyncData_MappingImpl implements SerializableMapping<TradeKeySyncData> {

	private final static int code=29909270;

	public TradeKeySyncData create() {
		return new TradeKeySyncData();
	}

	public void toField(TradeKeySyncData object, XMLNode node, String name, String value) throws Exception {
		if(name.equals("article-id")) {
			object.setArticleId(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("category-id")) {
			object.setCategoryId(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("debug")) {
			object.setDebug(XML2Object.getInstance().toValue(boolean.class, value));
			return;
		}

	}

	public XMLNode toNode(TradeKeySyncData object) throws Exception {
		XMLNode node = new XMLNode("tradekey-sync-data");
		Attributes attrs  = new Attributes(node);
		Object2XML mapper = Object2XML.getInstance();
		mapper.addNode(object.getArticleId(), node, false, "article-id");
		mapper.addNode(object.getCategoryId(), node, false, "category-id");
		mapper.addPrimitiveNode(object.isDebug(), node, false, "debug");
		return node;
	}
}
