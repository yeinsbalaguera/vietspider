/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.thegioixe;

import java.util.List;

import org.eclipse.swt.widgets.Shell;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.common.util.Worker;
import org.vietspider.content.drupal.DrupalSetup;
import org.vietspider.content.drupal.XMLDrupalConfig.Category;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.waiter.WaitLoading;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 15, 2008  
 */
public class TGXSetup extends DrupalSetup {

  public TGXSetup(Shell parent) {
    super(parent);
    
    txtUploadImage.setEnabled(true);
  }

  protected void detectCategories(final boolean save) {
    if(!check()) return;
    
    Worker excutor = new Worker() {

      private Exception error = null;
      private String cateURL = null;
      
      private CategoriesDetector detector;
      
      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
        String homepage = txtHomepage.getText();
        String login = txtLogin.getText();
        String username = txtUsername.getText();
        String password = txtPassword.getText();
        detector = new CategoriesDetector(homepage, login, username, password);
        cateURL = txtPostAddress.getText();
      }

      public void execute() {
        try {
          detector.detect(cateURL);
        } catch (Exception e) {
          error = e;
        }
      }

      public void after() {
        if(error != null ) {
          ClientLog.getInstance().setMessage(shell, error);
          return;
        }
        List<Category> list = detector.getCategories();
        Category [] categories = list.toArray(new Category[list.size()]);
        if(categories.length < 1) {
          Exception exception = new Exception("Warning: No categories from server. Try again.");
          ClientLog.getInstance().setMessage(shell, exception);
          return;
        }
        setCategoriesData(categories);
        if(save) saveConfig();
      }
    };
    
    WaitLoading loading = new WaitLoading(txtHomepage, excutor);
    loading.open();
  }
  

}
