/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.net.proxy;

import java.io.File;
import java.net.URL;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.conn.HttpHostConnectException;
import org.vietspider.common.io.DataReader;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.html.HTMLDocument;
import org.vietspider.html.HTMLNode;
import org.vietspider.html.Name;
import org.vietspider.html.NodeIterator;
import org.vietspider.html.parser.HTMLParser2;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jun 17, 2009  
 */
public class ProxyLoader extends NetLoader {

  private String[] sites = {"http://www.checker.freeproxy.ru/checker/last_checked_proxies.php"}; 
  private Set<String> refuses = new HashSet<String>();

  public ProxyLoader() {
    File file  = UtilFile.getFile("system/proxy/", "proxy.source.txt");
    try {
      String text = new String(new DataReader().load(file), "utf-8");
      if(!text.trim().isEmpty()) sites = text.split("\n");
    } catch (Exception e) {
    }
  }

  public void load() {
    refuses.clear();
    for(int i = 0; i < sites.length; i++) {
      final String site = sites[i].trim();
      final String fileName = String.valueOf(i);
      Thread thread =  new Thread() {
        public void run() {
          load(fileName, site);
        }
      };
      thread.start();
      try {
        sync(thread, 15*1000);
      } catch (TimeoutException e) {
        try {
          refuses.add(new URL(site).getHost());
        } catch (Exception e2) {
        }
      }
    }
  }

  private void load(String fileName, String address) {
    try {
//      System.out.println("load data from "+ address);
      address = address.trim();
      URL url =  new URL(address);
      String siteHost = url.getHost();
      if(refuses.contains(siteHost)) return;
      
      webClient.setURL(null, url);
      byte[] bytes = loadContent(address);
      if(bytes == null || bytes.length < 10) {
        if(siteHost != null) refuses.add(siteHost);
        return;
      }
      
      String value = toText(bytes);
      Set<String> set = new HashSet<String>();
      Pattern pattern = Pattern.compile("\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}[:]\\p{Digit}+");

      Matcher matcher = pattern.matcher(value);
      while(matcher.find()) {
        set.add(value.substring(matcher.start(), matcher.end()));
        if(set.size() >= 100) save(set, fileName);
      }

      Pattern patternHost = Pattern.compile("\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}");
      Pattern patternPort = Pattern.compile("\\p{Digit}+");
      Matcher matcherHost = patternHost.matcher(value);
      Matcher matcherPort = patternPort.matcher(value);
      int start = 0;
      while(matcherHost.find(start)) {
        int startHost = matcherHost.start();
        int endHost = matcherHost.end();

        String host = value.substring(startHost, endHost);
        if(matcherPort.find(endHost)) {
          int startPort = matcherPort.start();
          int endPort = matcherPort.end();
          start = endPort;
          String port = value.substring(startPort, endPort);
//          System.out.println(" thay co "+ host+ ":" + port);
          set.add(host + ":" + port);
          if(set.size() >= 100) save(set, fileName);
        } else {          
          start = endHost;
        }
      }

      save(set, fileName);
    } catch (HttpHostConnectException e) {
      try {
        refuses.add(new URL(address).getHost());
      } catch (Exception e1) {
      }
      LogService.getInstance().setMessage("PROXY", e, e.toString() + " "+ address);
    } catch (Exception e1) {
      LogService.getInstance().setMessage("PROXY", e1, e1.toString() + " "+ address);
    }
  }
  
  private void save(Set<String> set, String fileName) throws Exception {
    StringBuilder builder = new StringBuilder();
    Iterator<String> iterator = set.iterator();
    while(iterator.hasNext()) {
      if(builder.length() > 0) builder.append('\n');
      builder.append(iterator.next());  
      iterator.remove();
    }
    String value  = builder.toString().trim();
    if(value.isEmpty()) return;

    File file = new File(UtilFile.getFolder("system/proxy/"), fileName+ ".proxy.txt");
    int index = 0;
    while(file.exists()) {
      String name  = fileName+"_"+String.valueOf(index)+ ".proxy.txt";
      file = new File(UtilFile.getFolder("system/proxy/"), name);
      index++;
    }
//    System.out.println(" tinh hinh "+ file.getAbsolutePath() + " : " + value.getBytes("utf-8").length);
    new org.vietspider.common.io.DataWriter().save(file, value.getBytes("utf-8"));
  }
  
  private String toText(byte [] bytes) throws Exception {
    HTMLDocument document  = new HTMLParser2().createDocument(bytes, "utf-8");
    NodeIterator iterator = document.getRoot().iterator();
    StringBuilder builder = new StringBuilder();
    while(iterator.hasNext()) {
      HTMLNode node = iterator.next();
      if(node.isNode(Name.CONTENT)) {
        if(builder.length() > 0) builder.append('\n');
        builder.append(node.getTextValue());
      }
    }
    return builder.toString();
  }

/*  public static void main(String[] args)  throws Exception {
    //    Pattern pattern = Pattern.compile("\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}[:]\\p{Digit}+");
    //    String text = "asdasbd134.151.255.180:3128 CoDeen/PlanetLab? server";
    //    Matcher matcher = pattern.matcher(text);
    //    System.out.println(matcher.find());
    //    System.out.println(text.substring(matcher.start(), matcher.end()));

    File file = new File("D:\\java\\headvances3\\trunk\\vietspider\\startup\\src\\test\\data\\");
    System.setProperty("vietspider.data.path", file.getCanonicalPath());

    ProxyLoader loader = new ProxyLoader();
    loader.load();

  }*/

}
