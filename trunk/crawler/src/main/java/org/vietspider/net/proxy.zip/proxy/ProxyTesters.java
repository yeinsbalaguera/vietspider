/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.net.proxy;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.vietspider.common.io.DataReader;
import org.vietspider.common.io.DataWriter;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jun 18, 2009  
 */
public class ProxyTesters {
  
  void testOld() {
    try {
      File file  = new File(UtilFile.getFolder("system/proxy/"), "proxies.txt");
      if(file.exists() && file.length() > 0) {
        byte [] bytes = new DataReader().load(file);
        File copyFile = new File(UtilFile.getFolder("system/proxy/"), "old.proxy.txt");
        if(!copyFile.exists()) {
          new DataWriter().save(copyFile, bytes);
        } else {
          String value = new String(bytes, "utf-8");
          new DataWriter().append(copyFile, ("\n"+value).getBytes("utf-8"));
        }
      }
      
      File tempFile  = new File(UtilFile.getFolder("system/proxy/"), "proxies.temp.txt");
      tempFile.delete();
      
      file  = new File(UtilFile.getFolder("system/proxy/"), "old.proxy.txt");
      String value = new String(new DataReader().load(file), "utf-8");
      if(value.trim().isEmpty()) return;
      String [] proxies = value.split("\n");
      
      new ProxyTester().test(proxies);
      
      file.delete();
      saveProxies();
    } catch (Exception e) {
    }
  }
  
  boolean existTestFiles() {
    File folder = UtilFile.getFolder("system/proxy/");
    File [] files = folder.listFiles(new FileFilter() {
      public boolean accept(File f) {
        return f.getName().endsWith("proxy.txt");
      }
    });
    
    return files.length > 0;
  }
  
  void testNew() {
    File folder = UtilFile.getFolder("system/proxy/");
    File [] files = folder.listFiles(new FileFilter() {
      public boolean accept(File f) {
        return f.getName().endsWith("proxy.txt");
      }
    });
    
    for(int i = 0; i < files.length; i++) {
      testNew(files[i]);
    }
  }
  
  void testNew(File file) {
    try {
//      System.out.println(file.getAbsolutePath());
      String value = new String(new DataReader().load(file), "utf-8");
      file.delete();
      new ProxyTester().test(value.split("\n"));
      saveProxies();
    } catch (Exception e) {
    }
  }
  
  void saveProxies() {
    try {
      File infile  = UtilFile.getFile("system/proxy/", "proxies.temp.txt");
      if(!infile.exists() || infile.length() < 10) return;
      
      String value  = new String(new DataReader().load(infile), "utf-8");
      String [] elements = value.split("\n");
      List<Data> datas = new ArrayList<Data>();
      for(int i = 0; i < elements.length; i++) {
        if((elements[i] = elements[i].trim()).isEmpty()) continue;
        try {
          add(datas, new Data(elements[i]));
        } catch (Throwable e) {
        }
      }
      
      Collections.sort(datas, new Comparator<Data>() {
        public int compare(Data o1, Data o2) {
          return (int)(o1.getTime() - o2.getTime());
        }
      });
      
      StringBuilder builder = new StringBuilder();
      for(int i = 0; i < datas.size(); i++) {
        if(datas.get(i).getTime() > 3000) continue;
        if(builder.length() > 0) builder.append('\n');
        builder.append(datas.get(i).getProxy());
      }
      
      File outfile  = UtilFile.getFile("system/proxy/", "proxies.txt");
      outfile.delete();
//      System.out.println(" thay co "+ builder);
      new DataWriter().save(outfile, builder.toString().trim().getBytes("utf-8"));
    } catch (IOException e) {
      LogService.getInstance().setMessage("PROXY", null, e.toString());
    } catch (Exception e) {
      LogService.getInstance().setThrowable("PROXY", e);
    }
  }
  
  private void add(List<Data> datas, Data data) {
    for(int i = 0; i < datas.size(); i++) {
      if(datas.get(i).getProxy().equals(data.getProxy())) {
        datas.get(i).setTime((datas.get(i).getTime() + data.getTime())/2);
        return;
      }
    }
    datas.add(data);
  }
  
  private class Data {
    
    private String proxy;
    private long time;
    
    public Data(String line) {
      String [] elements = line.split("/");
      proxy = elements[0];
      time  = Long.parseLong(elements[1].trim());
    }
    
    long getTime() { return time; }
    void setTime(long time) { this.time = time; }
    
    String getProxy() { return proxy; }
  }
  
  public static void main(String[] args) throws Exception {
    File file = new File("D:\\java\\headvances3\\trunk\\vietspider\\startup\\src\\test\\data\\");
    System.setProperty("vietspider.data.path", file.getCanonicalPath());
    
    ProxyTesters testers = new ProxyTesters();
    testers.saveProxies();
  }

}
