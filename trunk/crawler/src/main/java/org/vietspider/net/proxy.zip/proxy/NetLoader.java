/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.net.proxy;

import org.apache.http.HttpResponse;
import org.vietspider.chars.URLEncoder;
import org.vietspider.net.client.HttpMethodHandler;
import org.vietspider.net.client.WebClient;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jun 17, 2009  
 */
class NetLoader {
  
  protected WebClient webClient = new WebClient();
  protected HttpMethodHandler methodHandler = new HttpMethodHandler(webClient);
  
  NetLoader() {
    webClient.setUserAgent("Mozilla/5.0 (compatible; Yahoo! VN Slurp; http://help.yahoo.com/help/us/ysearch/slurp)");
  }
  
  protected byte[] loadContent(String address) throws Exception {
    URLEncoder urlEncoder = new URLEncoder();
    address = urlEncoder.encode(address);

    HttpResponse httpResponse = methodHandler.execute(address, "");
    if(httpResponse == null) return null;

    return methodHandler.readBody();
  }

  void sync(final Thread thread, final int timeout) throws TimeoutException {
    boolean live  = true;
    int elapsed = 0;
    int rate = 500;
    while(live){
      try { 
        Thread.sleep(rate);
      } catch (InterruptedException ioe) {
      }
      
      if(!thread.isAlive() || thread.isInterrupted()) return;

      // Use 'synchronized' to prevent conflicts
      synchronized (this) {
        elapsed += rate;
        if (elapsed > timeout) {
//          System.out.println(" download da bi time out ");
          methodHandler.abort();
          thread.interrupt();
          live = false;
          throw new TimeoutException();
        }
      }
    }
  }
  
  @SuppressWarnings("serial")
  class TimeoutException extends Exception {
  }
}
