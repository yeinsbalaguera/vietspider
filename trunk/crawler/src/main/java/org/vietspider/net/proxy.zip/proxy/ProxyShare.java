/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.net.proxy;

import java.io.File;
import java.net.URL;

import org.vietspider.common.io.DataReader;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jun 18, 2009  
 */
public class ProxyShare extends NetLoader {
  
  private String site ; 

  public ProxyShare() {
    File file  = new File(UtilFile.getFolder("system/proxy/"), "proxy.share.txt");
    if(!file.exists() || file.length()  < 1) return;
    try {
      String text = new String(new DataReader().load(file), "utf-8");
      if(!text.trim().isEmpty()) site= text;
    } catch (Exception e) {
    }
  }
  
  boolean hasShare() {
    return site != null && site.length() > 0;
  }
  
  public void load() {
    try {
      String address = site.trim();
      webClient.setURL(address, new URL(address));
      byte[] bytes = loadContent(address);
      if(bytes == null) return;
      File file = UtilFile.getFile("system/proxy/", "proxies.txt");
      new org.vietspider.common.io.DataWriter().save(file, bytes);
    } catch (Exception e) {
      LogService.getInstance().setMessage("PROXY", e, e.toString() + " "+ site);
    }
  }

}
