/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.net.proxy;

import java.io.File;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.vietspider.chars.URLEncoder;
import org.vietspider.common.io.DataReader;
import org.vietspider.common.io.DataWriter;
import org.vietspider.common.io.UtilFile;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jun 17, 2009  
 */
public class ProxyTester extends NetLoader {

  private String[] sites = {"http://vnexpress.net"}; 
  private int index = 0;
  
  private HttpResponse httpResponse;
  private long start = -1;
  private String proxy = null;

  public ProxyTester() {
    File file  = UtilFile.getFile("system/proxy/", "site.txt");
    try {
      String text = new String(new DataReader().load(file), "utf-8");
      if(!text.trim().isEmpty()) sites = text.split("\n");
    } catch (Exception e) {
    }
  }

  public void test(String[] proxies) {
    for(int i = 0; i < proxies.length; i++) {
      int idx = proxies[i].indexOf('/');
      if(idx > 0) proxies[i] = proxies[i].substring(0, idx);
      
//      System.out.println("\n\n");
      
      httpResponse = null;
      start = -1;
      proxy = proxies[i].trim();
      
      if(ProxyFinderService.TEST) {
        System.out.println(" test proxy: " + proxy);
      }
      
      try {
        setProxy(proxy);
      } catch (Exception e) {
        continue;
      }
      
      Thread thread =  new Thread() {
        public void run() {
          start = System.currentTimeMillis();
          executeResponse();
        }
      };
      
      thread.start();
      
      try {
        sync(thread, 3*1000);
      } catch (TimeoutException e) {
      }
      
//      System.out.println(" chuan bi read data "+ proxy +"  : "+ httpResponse + " : "+ (System.currentTimeMillis() - start));
      
      if(httpResponse == null 
          || System.currentTimeMillis() - start > 3200) return;
//      System.out.println(" ================== > "+ proxy);
      
      thread =  new Thread() {
        public void run() {
          readData();
        }
      };
      thread.start();
      try {
        sync(thread, 5*1000);
      } catch (TimeoutException e) {
      }
      
    }//het for
  }
  
  private String getSite() {
    if(index >= sites.length) index = 0;
    String site = sites[index];
    index++;
    while(site == null || site.trim().isEmpty()){
      if(index >= sites.length) index = 0;
      site = sites[index];
      index++;
    }
    return site;
  }

  private void setProxy(String proxy) throws Exception  {
    String site = getSite();
    webClient.setURL(null, new URL(site));
    //      System.out.println("=== >"+site);
    String [] elements = proxy.split(":");
    String proxyHost = elements[0].trim();
    int proxyPort = Integer.parseInt(elements[1].trim()); 
    webClient.registryProxy(proxyHost, proxyPort, null, null);
  }
  
  private void executeResponse() {
    String address = getSite();
    URLEncoder urlEncoder = new URLEncoder();
    address = urlEncoder.encode(address);
    httpResponse = null;
    try {
      httpResponse = methodHandler.execute(address, "");
    } catch (Exception e) {
    }
  }
  
  private void readData() {
    start = System.currentTimeMillis();
    byte[] bytes =  null;
    try {
      bytes = methodHandler.readBody();
    } catch (Exception e) {
      return;
    }
//    System.out.println(" ================== > "+ proxy + " : "+ bytes);
    if(bytes == null) return;
    
    long time  = System.currentTimeMillis() - start;
//    System.out.println(" ================== > "+ proxy + " : "+ bytes.length+ " : "+ time);
//    if(start < 0 || proxy == null) return;
    
    if(bytes.length <= 10000 || time > 4000) return;
    
//    System.out.println(" bat dau "+ proxy);
//    try {
//      String host = webClient.getHost();
//      String page  = new String(bytes, "utf-8");
//      
////      org.vietspider.common.io.DataWriter writer = new org.vietspider.common.io.DataWriter();
////      java.io.File folder = org.vietspider.common.io.UtilFile.getFolder("track/temp/");
////      java.io.File file = new java.io.File(folder, proxy + ".html");
////      System.out.println(file.getAbsolutePath());
////      writer.save(file, bytes);
////      System.out.println(page);
//      
////      if(page.toLowerCase().indexOf(host) < 0) return;
//    } catch (Exception e) {
//      e.printStackTrace();
//      return;
//    }
    
    proxy  = "\n" + proxy + "/" + String.valueOf(time);
//    System.out.println("==== duoc 1 cai > "+ proxy);
    File file  = new File(UtilFile.getFolder("system/proxy/"), "proxies.temp.txt");
    try {
      new DataWriter().append(file, proxy.getBytes());
    } catch (Exception e) {
      return;
    }
  }
  
  /*public void test() {
      byte[] bytes = loadContent(site);
      if(bytes == null) return;
      
      long end = System.currentTimeMillis();
      long time = end - start;
      if(time > 2000) return;

      if(bytes.length > 10000) {
        proxy  = "\n" + proxyHost + ":" + proxyPort + "/" + String.valueOf(time);
        File file  = new File(UtilFile.getFolder("system/proxy/"), "proxies.temp.txt");
        new DataWriter().append(file, proxy.getBytes());
      }
    } catch (Exception e) {
    }
  }*/


}
