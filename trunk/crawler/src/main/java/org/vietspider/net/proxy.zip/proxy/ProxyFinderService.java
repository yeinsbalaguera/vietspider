/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.net.proxy;

import java.io.File;

import org.vietspider.common.io.UtilFile;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jun 17, 2009  
 */
public class ProxyFinderService extends Thread {
  
  private static ProxyFinderService INSTANCE;
  
  static boolean TEST = false;
  
  public static void startService() {
    if(INSTANCE != null) return;
    INSTANCE = new ProxyFinderService();
  }
  
  public ProxyFinderService() {
    start();
  }
  
  public void run() {
    File file  = new File(UtilFile.getFolder("system/proxy/"), "proxy.source.txt");
    if(!file.exists() || file.length() < 1) {
      file  = new File(UtilFile.getFolder("system/proxy/"), "proxy.share.txt");
    }
    if(!file.exists() || file.length() < 1) return; 
    
    while(true) {
      ProxyShare share = new ProxyShare();
      if(share.hasShare()) {
        share.load();
        
        try {
          Thread.sleep(5*60*1000);
        } catch (Exception e) {
        }
      } else {
        ProxyTesters testers = new ProxyTesters();
        if(!testers.existTestFiles()) {
          ProxyLoader loader = new ProxyLoader();
          loader.load();
        }
        
        testers.testOld();
        testers.testNew();
        
        testers.saveProxies();
        
        try {
          Thread.sleep(file.length() > 0 ? 30*60*1000 : 5*60*1000);
        } catch (Exception e) {
        }
      }
    }
  }
  
  
  public static void main(String[] args) throws Exception {
    File file = new File("D:\\java\\headvances3\\trunk\\vietspider\\startup\\src\\test\\data\\");
    System.setProperty("vietspider.data.path", file.getCanonicalPath());
    
    TEST = true;
    
    ProxyFinderService.startService();
  }
  
}
