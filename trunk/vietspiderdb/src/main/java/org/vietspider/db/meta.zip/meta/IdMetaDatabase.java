/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.       *
 **************************************************************************/
package org.headvances.vietspider.meta;

/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.       *
 **************************************************************************/

import java.io.File;
import java.util.SortedMap;

import org.headvances.storage.record.UriID;
import org.headvances.storage.shard.bdb.UriIDBinding;
import org.headvances.util.html.HttpURL;
import org.vietspider.bean.Meta;
import org.vietspider.common.io.LogService;

import com.sleepycat.bind.tuple.LongBinding;
import com.sleepycat.collections.StoredSortedMap;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Mar 30, 2009  
 */

public class IdMetaDatabase {

  private Environment env;
  private Database db;

  private  volatile boolean isClose = false;

  private SortedMap<Long, UriID> map;

  public IdMetaDatabase(File folder) throws Exception {
    EnvironmentConfig envConfig = new EnvironmentConfig();
    envConfig.setTransactional(false);
    envConfig.setAllowCreate(true);
    envConfig.setCacheSize(512*1024);
    
    this.env = new Environment(folder, envConfig);
    DatabaseConfig dbConfig = new DatabaseConfig();
    dbConfig.setTransactional(false);
    dbConfig.setAllowCreate(true);
    dbConfig.setDeferredWrite(true);
    this.db = env.openDatabase(null, "url", dbConfig);
    UriIDBinding md5Binding = new UriIDBinding();
    LongBinding keyBinding = new LongBinding();
    this.map = new StoredSortedMap<Long, UriID> (db, keyBinding, md5Binding, true);
  }
  
  public void save(Meta meta) throws Throwable {
    long id  = Long.parseLong(meta.getId());
    UriID uriID = new UriID(new HttpURL(meta.getSource())); 
    save(id, uriID);
  }
  
  public void commit() throws Throwable {
    db.sync();
  }

  public void save(long id, UriID value) throws Throwable {
    if(isClose) return;
    if(map.containsKey(id)) return;
    map.put(id, value);
  }

  public UriID search(long id) {
    if (isClose) return null;
    return map.get(id);
  }
  
  public void remove(long id) throws Throwable {
    if (isClose) return;
    map.remove(id);
  }

  public void close() {
    isClose = true;
    internalClose();
  }

  public boolean isClose() { return isClose; }

  private void internalClose()  {
    if (db != null) {
      try {
        db.close();
      } catch (Throwable e) {
        //        e.printStackTrace();
        LogService.getInstance().setMessage("URLDATABASE" , null, e.toString());
      }
      db = null;
    }

    if (env != null) {
      try {
        env.close();
      } catch (Throwable e) {
        LogService.getInstance().setMessage("URLDATABASE" , null, e.toString());
      }
      env = null;
    }
  }

}

