/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.headvances.vietspider.meta;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.headvances.storage.record.UriID;
import org.vietspider.bean.Article;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 28, 2009  
 */
public class ContentRepositories {
  
  private String folder;

  private Map<String, ContentRepository> holder = new ConcurrentHashMap<String, ContentRepository>();
  
  public ContentRepositories(String folder) {
    this.folder = folder;
  }
  
  public void save(Article article) throws Exception  {
    String group  = article.getDomain().getGroup();
    ContentRepository repository = getContentRepository(group);
    repository.save(article);
  }
  
  public Article load(UriID uriId) throws Exception  {
    Iterator<Map.Entry<String, ContentRepository>> iterator = holder.entrySet().iterator();
    while(iterator.hasNext()) {
      Map.Entry<String, ContentRepository> entry = iterator.next();
      Article article = entry.getValue().load(uriId);
      if(article != null) return article;
    }
    return null;
  }
  
  public Article load(String group, UriID uriId) throws Exception  {
    ContentRepository repository = getContentRepository(group);
    return repository.load(uriId);
  }
  
  synchronized ContentRepository getContentRepository(String group) throws Exception {
    ContentRepository repository = holder.get(group);
    if(repository != null) return repository;
    repository = new ContentRepository(folder);
    holder.put(group, repository);
    return repository;
  }
  
  public void commit() throws Exception {
    Iterator<Map.Entry<String, ContentRepository>> iterator = holder.entrySet().iterator();
    while(iterator.hasNext()) {
      Map.Entry<String, ContentRepository> entry = iterator.next();
      entry.getValue().commit();
    }
  }
  
  public void close() throws Exception {
    Iterator<Map.Entry<String, ContentRepository>> iterator = holder.entrySet().iterator();
    while(iterator.hasNext()) {
      Map.Entry<String, ContentRepository> entry = iterator.next();
      entry.getValue().close();
    }
  }
  
}
