/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.headvances.vietspider.meta;

import org.headvances.storage.record.UriID;
import org.headvances.storage.shard.bdb.RecordDB;
import org.vietspider.bean.Article;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 28, 2009  
 */
public class ContentRepository {

  private RecordDB db;

  public ContentRepository(String folder) throws Exception {
    db = new RecordDB(folder, true);
  }

  public void save(Article article) throws Exception  {
    /*Meta meta = article.getMeta();
    Content content = article.getContent();
    String url  = meta.getSource();
    String topic  = meta.getTitle();
    Record record = new Record(url, topic) ;



    long postDate = meta.getCalendar().getTimeInMillis();
    if(meta.getSourceTime() != null) {
      try {
        postDate = CalendarUtils.getDateTimeFormat().parse(meta.getSourceTime()).getTime();
      } catch (Exception e) {
      }
    }

    String mineType = getMimeType(article.getDomain().getGroup());
    WebPage wdata = new WebPage(mineType, url, topic, meta.getDesc(), content.getContent(), postDate);
    wdata.setLanguage(new String[] {"vn", "en"}) ;
    wdata.setSymbolicImageURL(meta.getImage()) ;
    record.add(wdata) ;

    org.headvances.storage.record.Meta rmeta = new org.headvances.storage.record.Meta(url) ;
    rmeta.setCreatedDate(meta.getCalendar().getTimeInMillis());
    record.setMeta(rmeta);
    
    db.save(rmeta.getUriId(), record);*/
  }

  public Article load(UriID uriId) throws Exception  {
    /*Article article = new Article();
    Meta meta = new Meta();
    Content content = new Content();
    
    Record record = db.search(uriId);
    WebPage webPage = record.getEntity(WebPage.NAME, WebPage.class) ;
    
    long createdDate = record.getMeta().getCreatedDate();
    Calendar calendar = Calendar.getInstance();
    calendar.setTimeInMillis(createdDate);
    
    SimpleDateFormat dateFormat = CalendarUtils.getDateTimeFormat();
    
    String time  = null;
    try {
      time  = dateFormat.format(calendar.getTime());
    } catch (Exception e) {
    };
    content.setDate(time);
    meta.setTime(time);
    
    if(webPage.getPostDate() != createdDate) {
      try {
        calendar.setTimeInMillis(webPage.getPostDate());
        meta.setSourceTime(dateFormat.format(calendar.getTime()));
      } catch (Exception e) {
      };
    }
    
    content.setContent(webPage.getContent());
    
    meta.setTitle(webPage.getTitle());
    meta.setDesc(webPage.getDescription());
    meta.setImage(webPage.getSymbolicImageURL());
    meta.setSource(webPage.getUri());*/
    
//    return article;
    return null;
  }

  public void commit() throws Exception {
    db.commit();
  }

  public void close() throws Exception {
    db.close();
  }

  private String getMimeType(String group) {
   /* String mimeType = MimeType.ARTICLE;
    if(group.equalsIgnoreCase(Group.ARTICLE)) {
      mimeType = MimeType.ARTICLE;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_ARTICLE, true);
    } else if(group.equalsIgnoreCase(Group.BLOG)) {
      mimeType = MimeType.BLOG;
      //        stype = generation.getStorageType(IDMapping.WEBDATA_BLOG, true);
    } else if(group.equalsIgnoreCase(Group.CLASSIFIED)) {
      mimeType = MimeType.CLASSIFIED;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_CLASSIFIED, true);
    } else if(group.equalsIgnoreCase(Group.FORUM)) {
      mimeType = MimeType.FORUM;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_FORUM, true);
    } else if(group.equalsIgnoreCase(Group.JOB)) {
      mimeType = MimeType.JOB;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_JOB, true);
      //    } else if(group.equalsIgnoreCase(Group.LITERATURE)) {
      //      mineType = MimeType.LITERATURE;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_LITERATURE, true);
    } else if(group.equalsIgnoreCase(Group.LYRIC)) {
      mimeType = MimeType.LYRIC;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_LYRIC, true);
    } else if(group.equalsIgnoreCase(Group.POETRY)) {
      mimeType = MimeType.POETRY;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_POETRY, true);
    } else if(group.equalsIgnoreCase(Group.PRODUCT)) {
      mimeType = MimeType.PRODUCT;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_PRODUCT, true);
    } else if(group.equalsIgnoreCase(Group.PROFILE)) {
      mimeType = MimeType.PROFILE;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_PROFILE, true);
    } else if(group.equalsIgnoreCase(Group.SEARCHTIONARY)) {
      mimeType = MimeType.SEARCHTIONARY;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_SEARCHTIONARY, true);
    } else if(group.equalsIgnoreCase(Group.SITE)) {
      mimeType = MimeType.SITE;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_SITE, true);
    } else if(group.equalsIgnoreCase(Group.STORY)) {
      mimeType = MimeType.LITERATURE;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_LITERATURE, true);
    } else if(group.equalsIgnoreCase(Group.XML)) {
      mimeType = MimeType.XML;
      //      stype = generation.getStorageType(IDMapping.WEBDATA_XML, true);
    }*/

//    return mimeType;
    return "";
  }

}
