/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.       *
 **************************************************************************/
package org.headvances.vietspider.meta;

/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.       *
 **************************************************************************/

import java.io.File;
import java.util.SortedMap;

import org.vietspider.bean.Domain;
import org.vietspider.common.io.LogService;
import org.vietspider.serialize.Bean2XML;
import org.vietspider.serialize.XML2Bean;

import com.sleepycat.bind.tuple.IntegerBinding;
import com.sleepycat.bind.tuple.StringBinding;
import com.sleepycat.collections.StoredSortedMap;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;

public class DomainDatabase {

  private Environment env;
  private Database db;

  private  volatile boolean isClose = false;

  private SortedMap<Integer, String> map;

  public DomainDatabase(File folder) throws Exception {
    EnvironmentConfig envConfig = new EnvironmentConfig();
    envConfig.setTransactional(false);
    envConfig.setAllowCreate(true);

    envConfig.setCacheSize(128*1024);
    
    this.env = new Environment(folder, envConfig);
    DatabaseConfig dbConfig = new DatabaseConfig();
    dbConfig.setTransactional(false);
    dbConfig.setAllowCreate(true);
    dbConfig.setDeferredWrite(true);
    this.db = env.openDatabase(null, "url", dbConfig);
    IntegerBinding keyBinding = new IntegerBinding();
    StringBinding dataBinding = new StringBinding();
    this.map = new StoredSortedMap<Integer, String> (db, keyBinding, dataBinding, true);
  }
  
  public void save(Domain domain) throws Throwable {
    int key = Integer.parseInt(domain.getId());
    Bean2XML bean2xml = Bean2XML.getInstance();
    String xml = bean2xml.toXMLDocument(domain).getTextValue();
    save(key, xml);
  }

  public void save(int key, String value) throws Throwable {
    if(isClose) return;
    if(map.containsKey(key)) return;
    map.put(key, value);
  }
  
  public Domain search(int key) throws Exception {
    if (isClose) return null;
    String value = map.get(key);
    XML2Bean xml2Bean = XML2Bean.getInstance();
    return xml2Bean.toBean(Domain.class, value);
  }
  
  public void remove(int key) throws Throwable {
    if (isClose) return;
    map.remove(key);
  }
  
  public void commit() throws Throwable {
    db.sync();
  }

  public void close() {
    isClose = true;
    internalClose();
  }

  public boolean isClose() { return isClose; }

  private void internalClose()  {
    if (db != null) {
      try {
        db.close();
      } catch (Throwable e) {
        //        e.printStackTrace();
        LogService.getInstance().setMessage("URLDATABASE" , null, e.toString());
      }
      db = null;
    }

    if (env != null) {
      try {
        env.close();
      } catch (Throwable e) {
        LogService.getInstance().setMessage("URLDATABASE" , null, e.toString());
      }
      env = null;
    }
  }

}

