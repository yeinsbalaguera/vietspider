/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.headvances.vietspider.meta;

import org.headvances.storage.record.UriID;
import org.headvances.util.html.HttpURL;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 15, 2009  
 */
public class IdMeta {
  
  public static final short INSERT  = 1;
  public static final short REMOVE  = -1;
  
  private long id;
  private UriID uriId;
  
  private String folder;
  
  private short type  = INSERT;

  public IdMeta(){
  }
  
  public IdMeta(long id, String url){
    this.id = id;
    this.uriId = new UriID(new HttpURL(url));
  }
  
  public IdMeta(long id, String url, short t){
    this(id, url);
    type = t;
  }
  
  public short getType() { return type; }
  public void setType(short type) { this.type = type; }

  public long getId() { return id; }
  public void setUrl(long _id) { this.id = _id; }
  
  public UriID getUriId() { return uriId; }
  public void setUriId(UriID id) { this.uriId = id; }
  
  public String getFolder() { return folder;  }
  public void setFolder(String folder) { this.folder = folder; }
}
