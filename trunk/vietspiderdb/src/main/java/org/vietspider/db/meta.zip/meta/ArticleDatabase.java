/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.headvances.vietspider.meta;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.headvances.storage.record.UriID;
import org.vietspider.bean.Article;
import org.vietspider.common.io.UtilFile;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 28, 2009  
 */
public class ArticleDatabase {
  
  private String date;
  
  private ContentRepository repository;
  private DomainDatabase domainDb;
  private IdMetaDatabase idDb;
  
  private int counter = 0;
  protected volatile long lastAccess = System.currentTimeMillis();
  
  public ArticleDatabase(String _date) throws Exception {
    this.date = _date;
    File folder = UtilFile.getFolder("content/contentdb/data/" + date);
    repository  = new ContentRepository(folder.getAbsolutePath());
    
    folder = UtilFile.getFolder("content/contentdb/domain/" + date);
    domainDb = new DomainDatabase(folder);
    
    folder = UtilFile.getFolder("content/contentdb/metaid/" + date);
    idDb = new IdMetaDatabase(folder);
  }
  
  public void save(Article article)  throws Throwable {
    lastAccess = System.currentTimeMillis();
    
    domainDb.save(article.getDomain());
    repository.save(article);
    idDb.save(article.getMeta());
    
    counter++;
    if(counter < 50) return;
    domainDb.commit();
    repository.commit();
    idDb.commit();
    counter = 0;
  }
  
  public Article load(long id)  throws Throwable {
    lastAccess = System.currentTimeMillis();
    
    UriID uriId = idDb.search(id);
    if(uriId == null) return null;
    Article article = repository.load(uriId);
    if(article == null) return null;
    int domainId = Integer.parseInt(article.getMeta().getId());
    article.setDomain(domainDb.search(domainId));
    
    String metaId = String.valueOf(id);
    article.getContent().setMeta(metaId);
    article.getMeta().setId(metaId);
    article.getMeta().setDomain(article.getDomain().getId());
    
    return article;
  }
  
  public List<Article> loadArticles(int[] metaIds)  throws Throwable  {
    lastAccess = System.currentTimeMillis();
    
    List<Article> articles = new ArrayList<Article>();
    for(int i = 0; i < metaIds.length; i++) {
      Article article = load(metaIds[i]);
      if(article != null) articles.add(article);
    }
    return articles;
  }
  
  public void close() throws Throwable {
    domainDb.close();
    repository.close();
    idDb.close();
  }
  
  public String getDate() { return date; }
  
  public long getLastAccess() { return lastAccess; }
  
}
