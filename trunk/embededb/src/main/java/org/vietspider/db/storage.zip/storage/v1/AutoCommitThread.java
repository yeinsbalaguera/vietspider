package org.headvances.vietspider.storage.v1;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.vietspider.common.Application;

@SuppressWarnings("unchecked")
public  class AutoCommitThread extends Thread {
  
  protected volatile static AutoCommitThread SINGLETON  ;
  
  protected Map<String, AutoCommitDB> holder ;
  
  protected volatile long sleep = 1000;
  
  protected AutoCommitThread() {
    holder = new ConcurrentHashMap<String, AutoCommitDB>() ;
    Application.addShutdown(new Application.IShutdown() {
      public void execute() {
        commit();
        
        Iterator<AutoCommitDB> i = holder.values().iterator() ;
        while(i.hasNext()) {
          AutoCommitDB db = i.next() ;
          try {
            db.commit();
            db.close();
          } catch (Exception e) {
            Error error = new Error(db.getName() + ": " + e.getMessage());
            throw error;
          }
        }
      }
    });
  }
  
  public void add(AutoCommitDB db) {
    if(db == null) return;
    holder.put(db.getLocation(), db) ;
  }
  
  public void remove(AutoCommitDB db)  {
    if(db == null) return;
    db.setStatus(AutoCommitDB.REMOVE);
  }
  
  public void run() {
    while(true) {
      commit();
      try {
        Thread.sleep(sleep) ;
      } catch(Exception ex) {
      }
    }
  }
  
  public void commit()  {
    Iterator<AutoCommitDB> i = holder.values().iterator() ;
    while(i.hasNext()) {
      long time = System.currentTimeMillis() ;
      AutoCommitDB db = i.next() ;
      if(db.getCommitPeriod() > 0) {
        if(time - db.getLastCommitTime() >= db.getCommitPeriod()) {
          try {
            db.commit() ;
          } catch (Exception e) {
            Error error = new Error(db.getName() + ": " + e.getMessage());
            error.setStackTrace(e.getStackTrace());
            throw error;
          }
        }
      }
      
      if(time - db.getLastAccessTime() > db.getAccessExpire()) {
        if(db.isRepair()) {
          db.setLastAccessTime(System.currentTimeMillis());
        } else {
          db.setStatus(AutoCommitDB.REMOVE);
        }
      }
      
      if(db.getStatus() == AutoCommitDB.REMOVE) {
        i.remove();
        try {
          db.commit();
          db.close();
        } catch (Exception e) {
          Error error = new Error(db.getName() + ": " + e.getMessage());
          error.setStackTrace(e.getStackTrace());
          throw error;
        }
      }
    }
  }
  
  synchronized final static public AutoCommitThread getInstance() {
    if(SINGLETON == null) {
      SINGLETON = new AutoCommitThread() ;
      SINGLETON.start() ;
    }
    return SINGLETON ;
  }
  
  public void setAutoCommit(AutoCommitDB db, int size, long period) {
    db.setCommitSize(size);
    db.setCommitPeriod(period);
//    long time =  System.currentTimeMillis();
    add(db) ;
  }
}