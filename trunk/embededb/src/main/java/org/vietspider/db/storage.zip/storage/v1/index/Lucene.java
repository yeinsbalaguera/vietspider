package org.headvances.vietspider.storage.v1.index;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.NIOFSDirectory;
import org.apache.lucene.store.RAMDirectory;
/**
 * Author : Tuan Nguyen
 */
public class Lucene {
  final static public int RAM_DIRECTORY = 0 ;
  final static public int FS_DIRECTORY = 1 ;
  final static public int MMAP_DIRECTORY = 2 ;
  
  private Directory directory ;
  private String indexDBLocation ;
  private IndexWriter indexWriter ;
  private IndexSearcher indexSearcher ;
  private int directoryType ;
  private Analyzer analyzer  = new LuceneRecordAnalyzer() ;
  
  public Lucene(String indexDbLocation) throws Exception {
    init(indexDbLocation, FS_DIRECTORY, false) ;
  }
  
  public Lucene(String indexDbLocation, int directoryType) throws Exception {
    init(indexDbLocation, directoryType, false) ;
  }
  
  private void init(String indexDbLocation, int directoryType, boolean forceRecreate) throws Exception {
    this.indexDBLocation = indexDbLocation ;
    this.directoryType = directoryType ;
    File file = new File(indexDbLocation) ;
    boolean autocreate = forceRecreate || !file.exists() ;
    if(directoryType == RAM_DIRECTORY) {
      this.directory = new RAMDirectory(file) ;
    } else {
      System.setProperty("org.apache.lucene.FSDirectory.class", NIOFSDirectory.class.getName());
      this.directory =  FSDirectory.getDirectory(file) ;
    }
    
    if(IndexWriter.isLocked(directory)) IndexWriter.unlock(directory) ;
    indexWriter = new IndexWriter(directory, analyzer, autocreate);
    indexWriter.setRAMBufferSizeMB(50) ;
    indexSearcher = new IndexSearcher(directory) ;
  }
  
  public String getIndexDBLocation() { return indexDBLocation ; }
  
  public void updateSearcher() throws Exception {
    indexSearcher.close() ;
    indexSearcher = new IndexSearcher(directory) ;
  }
  
  synchronized public void optimize() throws Exception {
    indexWriter.optimize() ;
  }

  public void dropIndex() throws Exception {
    close() ;
    init(indexDBLocation, directoryType, true) ;
  }
  
  public void close() throws Exception {
    if(indexWriter != null) indexWriter.close() ;
    indexSearcher.close()  ;
    directory.close() ;
  }
  
  public void commit() throws Exception {
    indexWriter.commit() ;
  }
  
  public void index(Document doc) throws Exception {
    indexWriter.addDocument(doc) ;
  }
  
  public void update(Term term, Document doc) throws Exception {
    indexWriter.updateDocument(term, doc) ;
  }
  
  public void delete(Term term) throws Exception {
    indexWriter.deleteDocuments(term) ;
  }
  
  final public IndexReader getIndexReader() { return indexSearcher.getIndexReader() ; }
  
  public HitDocs search(String query, int maxReturn, int pageSize) throws Exception {
    HitDocCollector collector = new HitDocCollector(maxReturn) ;
    QueryParser parser = new QueryParser("description", analyzer) ;
    Query lquery = parser.parse(query) ;
    indexSearcher.search(lquery, null, collector) ;
    HitDoc[] hitDocs =  collector.getHitDoc(); 
    return new HitDocs(hitDocs, collector.getTotalHit(), pageSize) ;
  }
  
  public HitDocs search(Query query, int maxReturn, int pageSize) throws Exception {
    HitDocCollector collector = new HitDocCollector(maxReturn) ;
    indexSearcher.search(query, null, collector) ;
    HitDoc[] hitDocs =  collector.getHitDoc(); 
    return new HitDocs(hitDocs, collector.getTotalHit(), pageSize) ;
  }
  
  public final static SimpleDateFormat DATE_FORMATER = new SimpleDateFormat("yyyyMMddHHmm") ;
  final static public String format(Date date) { return DATE_FORMATER.format(date) ;}
}