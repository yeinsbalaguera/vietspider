package org.headvances.vietspider.storage.v1.shell;

import java.io.Console;
import java.io.OutputStreamWriter;
import java.util.LinkedHashMap;

import org.headvances.io.Log;
import org.headvances.vietspider.storage.v1.site.SiteDB;
import org.headvances.vietspider.storage.v1.url.URLTrackerDBManager;

public class Shell {
  private Log log ;
  private SiteDB siteDB ;
//  private HomePageDBManager hpdbManager ;
  private URLTrackerDBManager urldbManager ;
  private Commands commands ;
  
  public Shell() throws Exception {
    this.log = new Log(new OutputStreamWriter(System.out, "UTF-8"), true) ;
    this.commands = new Commands() ;
    commands.add(new SiteDBInfoCommand()) ;
    commands.add(new SiteDBTestCommand()) ;
    commands.add(new SiteDBSetCommand()) ;
    commands.add(new SiteDBCommand()) ;
    
//    commands.add(new HomePageDBCommand()) ;
//    commands.add(new HomePageDBSetCommand()) ;
//    commands.add(new HomePageDBInfoCommand()) ;
//    commands.add(new HomePageDBTestCommand()) ;
//    commands.add(new HomePageDBImportCommand()) ;
    
    commands.add(new URLDBCommand()) ;
    commands.add(new URLDBSetCommand()) ;
    commands.add(new URLDBInfoCommand()) ;
    commands.add(new URLDBTestCommand()) ;
    
    commands.add(new ExitCommand()) ;
  }

  public Log getLog() { return this.log ; }
  
//  public HomePageDBManager getHomePageDBManager() { return hpdbManager ;}
//  public void setHomePageDBManager(String loc) throws Exception { 
//    if(hpdbManager != null) hpdbManager.close() ;
//    this.hpdbManager = new HomePageDBManager(loc) ;
//  }
  
  public URLTrackerDBManager getURLTrackerDBManager() { return urldbManager ;}
  public void setURLTrackerDBManager(String loc) throws Exception { 
    if(urldbManager != null) urldbManager.close() ;
    this.urldbManager = new URLTrackerDBManager(loc) ;
  }
  
  public SiteDB getSiteDB() { return siteDB ; }
  public void   setSiteDB(String dbdir) throws Exception { 
    if(siteDB != null) siteDB.close() ;
    this.siteDB = new SiteDB(dbdir) ; 
  }
  
  public void console() throws Exception {
    Console console = System.console() ;
    while(true) {
      console.printf("\nshell>: ") ;
      String input = console.readLine() ;
      byte[] buf = input.getBytes() ;
      input = new String(buf, "UTF-8") ;
      CommandParser parser = new CommandParser(input) ;
      Command command = commands.get(parser.getCommand()) ;
      if(command != null) {
        try {
          command.execute(parser, this) ;
        } catch(Exception ex) {
          ex.printStackTrace() ;
        }
      } else {
        console.printf("Command not found: " + input) ;
      }
    }
  }
  
  static public class Commands extends LinkedHashMap<String, Command> {
    public void add(Command command) {
      super.put(command.getCommand(), command) ;
    }
  }
  
  static public void main(String[] args) throws Exception {
    System.setOut(new java.io.PrintStream(System.out, true, "UTF-8")) ;
    Shell shell = new Shell() ;
    boolean noconsole = false ;
    if(args.length > 0) {
      for(int i = 0; i < args.length; i++) {
        if(args[i].startsWith("--batch=")) {
        } else if("--noconsole".equals(args[i])) {
          noconsole = true ;
        }
      }
    }
    if(!noconsole) shell.console() ;
  }
}