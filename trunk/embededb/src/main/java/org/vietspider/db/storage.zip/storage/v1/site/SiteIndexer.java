package org.headvances.vietspider.storage.v1.site;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Query;
import org.headvances.storage.v3.MD5Hash;
import org.headvances.util.cache.Cache;
import org.headvances.util.cache.InmemoryCache;
import org.headvances.vietspider.storage.v1.index.HitDoc;
import org.headvances.vietspider.storage.v1.index.HitDocs;
import org.headvances.vietspider.storage.v1.index.Lucene;
import org.headvances.vietspider.storage.v1.index.WordTokenStream;

public class SiteIndexer {
  private String indexDBDir ;
  private Lucene lucene ;
  private Cache<String, HitDocs> cache ;
  
  public SiteIndexer(String dir) throws Exception {
    this.indexDBDir = dir ;
    lucene = new Lucene(dir + "/indexes") ;
    cache = new InmemoryCache<String, HitDocs>("SiteIndexer", 3000) ;
  }
  
  public String getIndexDBDir() { return indexDBDir ; }
  
  public HitDocs search(String query, int maxReturn, int pageSize) throws Exception {
    HitDocs hitDocs = cache.getCachedObject(query) ;
    if(hitDocs == null) {
      hitDocs = lucene.search(query, maxReturn, pageSize) ;
      cache.putCachedObject(query, hitDocs) ;
    }
    return hitDocs ;
  }
  
  public HitDocs search(Query query, int maxReturn, int pageSize) throws Exception {
    HitDocs hitDocs = cache.getCachedObject(query.toString()) ;
    if(hitDocs == null) {
      hitDocs = lucene.search(query, maxReturn, pageSize) ;
      cache.putCachedObject(query.toString(), hitDocs) ;
    }
    return hitDocs ;
  }
  
  final public MD5Hash getSiteId(HitDoc hdoc) throws Exception {
    return hdoc.getId(lucene.getIndexReader()) ;
  }
  
  public void index(Site record, boolean isNew) throws Exception {
    Document idoc = new Document();
    String md5hash = record.getId().toString() ;
    idoc.add(new Field("id", md5hash, Field.Store.YES, Field.Index.NOT_ANALYZED));
    idoc.add(new Field("modifiedTime", getModifiedDate(record), Field.Store.YES, Field.Index.NOT_ANALYZED));
    
    Field domain = new Field("domain", getDomain(record)) ;
    domain.setOmitTf(true) ;
    idoc.add(domain);
    
    Field ip = new Field("ip", getIp(record), Field.Store.NO, Field.Index.ANALYZED) ;
    ip.setOmitTf(true) ;
    idoc.add(ip);
    
    Field language = new Field("language", record.getLanguage(), Field.Store.NO, Field.Index.ANALYZED) ;
    language.setOmitTf(true);
    idoc.add(language);
    
    Field text = new Field("description", record.getDescription(), Field.Store.NO, Field.Index.ANALYZED) ;
    idoc.add(text);

    if(!isNew) lucene.update(new Term("md5hash", md5hash), idoc) ;
    else lucene.index(idoc) ;
  }
  
  public void delete(MD5Hash id) throws Exception {
    String md5hash = id.toString() ;
    lucene.delete(new Term("md5hash", md5hash)) ;
  }
  
  public void commit() throws Exception { lucene.commit() ; }
  
  public void optimize() throws Exception { lucene.optimize() ; }
  
  public void dropIndex() throws Exception { lucene.dropIndex()  ; }
  
  public void update() throws Exception {
    lucene.updateSearcher() ;
  }
  
  public void close() throws Exception {
    lucene.close() ;
  }
  
  private String getIp(Site record) {
    String ip = record.getIP() ;
    if(ip == null) return "" ;
    return ip ;
  }
  
  private WordTokenStream getDomain(Site record) {
    WordTokenStream stream = new WordTokenStream() ;
    String source = record.getDomain();
    stream.add(source, true) ;
    int idx = source.indexOf('.') ;
    while(idx >= 0) {
      source = source.substring(idx + 1) ;
      if(source.indexOf('.') < 0) break ;
      stream.add(source, true) ;
      idx = source.indexOf('.') ;
    }
    return stream ;
  }
  
  private String getModifiedDate(Site record) { return Lucene.format(record.getModifiedTime()) ; }
}