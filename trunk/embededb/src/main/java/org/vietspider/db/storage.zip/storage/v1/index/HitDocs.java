package org.headvances.vietspider.storage.v1.index;

import java.util.ArrayList;
import java.util.List;

import org.headvances.util.PageList;

public class HitDocs extends PageList<HitDoc>{
  private HitDoc[]  hitDocs ;
  private int totalHit = 0;
  
  public HitDocs(int pageSize) {
    super(pageSize) ;
  }
  
  public HitDocs(HitDoc[]  hitDocs, int totalHit, int pageSize) {
    super(pageSize);
    init(hitDocs, totalHit) ;
  }
  
  protected void init(HitDoc[]  hitDocs, int totalHit) {
    this.hitDocs = hitDocs ;
    this.totalHit = totalHit;
    setAvailablePage(hitDocs.length) ;
  }

  public int getTotalHit() { return totalHit ; }
  
  public HitDoc[] getAll() { return this.hitDocs ; }

  protected void populateCurrentPage(int page) throws Exception {
    int from = getFrom() ;
    int to = getTo() ;
    List<HitDoc> list = new ArrayList<HitDoc>() ;
    for(int i = from ; i < to ; i++) {
      list.add(hitDocs[i]) ;
    }
    setCurrentPage(page, list) ;
  }  
}