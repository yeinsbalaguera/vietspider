/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.headvances.vietspider.storage;

import org.headvances.storage.v3.SerializableObject;
import org.headvances.storage.v3.db.Database;
import org.headvances.storage.v3.db.DatabaseDefragmenter;
import org.headvances.storage.v3.db.Record;
import org.vietspider.common.Application;
import org.vietspider.common.io.LogService;
import org.vietspider.common.text.NameConverter;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 24, 2009  
 */
abstract public class CommitDB<T extends Record<K>, K extends SerializableObject> {
  
  private String location ;
  private String name ;
  
  protected Database<T, K> database ;
  
  protected volatile boolean repair = false; 
  
  protected long lastAccessTime = System.currentTimeMillis();
  protected long accessTimeout = 10*60*1000 ;
 
  protected CommitDB(String name, String dbdir) throws Exception {
    this.name = name ;
    this.location = dbdir ;
    this.database = createDatabase(this.location) ;
  }
  
  abstract protected Database<T, K> createDatabase(String location_) throws Exception ;
  
  public String getName() { return name ; }
  
  public String getLocation() { return location ; }
  
  public Database<T, K> getDatabase() { return database ; }
  
  public T find(K id) throws Exception {
    if(database.isClose() 
        || database.hasError()) return null;
    lastAccessTime = System.currentTimeMillis();
    return database.get(id) ; 
  }
  
  
  synchronized public void close() throws Exception {
    database.close() ;
  }
  
  public synchronized void repair(boolean error) {
    if(repair) return;
    repair = true;
//    File file  = new File(location + "/database.working");
//    if(file.exists()) return;
    if(error) Application.addError(this);
    new Thread(new AutoDatabaseDefragmenter()).start();
  }
  
  public synchronized boolean isRepair() { return repair; }
  
  public synchronized boolean isClose() { return database.isClose(); }
  
  protected final class AutoDatabaseDefragmenter implements Runnable {
    
    AutoDatabaseDefragmenter() {
    }
    
    public void run() {
      repair(0);
    }
    
    public void repair(int time) {
//      System.out.println(" == >"+ CommitDB.this 
//          + " : "+ Thread.currentThread().hashCode() 
//          + " == > " + repair + " database "+ database.hasError());
//      if(repair) return;
      String label = name;
      LogService.getInstance().setMessage("APPLICATION", null, "Start repair  " + Thread.currentThread().hashCode() + " : "+ label +" database !");
      try {
        DatabaseDefragmenter<T, K> optimizer = new DatabaseDefragmenter<T, K>(database) ;
        optimizer.setPageSize(10000);
        optimizer.setIgnoreCorruptedRecord(true);
        label = this.getClass().getSimpleName() + "/" + new NameConverter().decode(name);
        optimizer.run() ;
//        System.out.println(" == ket qua sau do >"+ CommitDB.this 
//            + " : "+ Thread.currentThread().hashCode() 
//            + " == > " + repair + " database "+ tempDB.hasError());
        LogService.getInstance().setMessage("APPLICATION", null, "Repair "+ label +" database successful!");
      } catch (Exception e) {
        LogService.getInstance().setMessage("APPLICATION", null, "Finished repair  "+ label +" database !");
        LogService.getInstance().setThrowable( e);
        if(time > 2) return;
        try {
          database.close();
          database = createDatabase(location);
          repair(time+1);
        } catch (Exception e1) {
          LogService.getInstance().setThrowable(e1);
        }
        return;
      } 
      LogService.getInstance().setMessage("APPLICATION", null, "Finished repair  "+ label +" database !");
      Application.removeError(CommitDB.this);
      repair = false;
    }
  }
  
  public boolean isExpire() { 
    if(isRepair()) return false;
    if(isClose()) return true;
    return (System.currentTimeMillis() - lastAccessTime) >= accessTimeout;
  }

}
