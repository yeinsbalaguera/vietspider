package org.headvances.vietspider.storage.v1;

import org.headvances.storage.v3.SerializableObject;
import org.headvances.storage.v3.db.Database;
import org.headvances.storage.v3.db.DatabaseDefragmenter;
import org.headvances.storage.v3.db.Record;
import org.vietspider.common.Application;
import org.vietspider.common.io.LogService;
import org.vietspider.common.text.NameConverter;

abstract public class AutoCommitDB<T extends Record<K>, K extends SerializableObject> {
  
  public final static int DONE = 1;
  public final static int REMOVE = 0;
  
  private String location ;
  private String name ;
  
  private int commitSize = 10 ;
  private int commitCounter = -1 ;
  private long commitPeriod ;
  
  private long lastCommitTime = System.currentTimeMillis();
  
  private int status = DONE;
  
  private long lastAccessTime = System.currentTimeMillis();
  private long accessExpire = 5*60*1000;
  
  protected Database<T, K> database ;
  
  protected volatile boolean repair = false; 
 
  protected AutoCommitDB(String name, String dbdir) throws Exception {
    this.name = name ;
    this.location = dbdir ;
    this.database = createDatabase(this.location) ;
  }
  
  abstract protected Database<T, K> createDatabase(String location_) throws Exception ;
  
  public String getName() { return name ; }
  
  public String getLocation() { return location ; }
  
  public void setAutoCommit(int size, long period) {
    AutoCommitThread.getInstance().setAutoCommit(this, size, period) ;
//    this.commitSize = size ;
//    this.commitPeriod = period ;
//    this.lastCommitTime = System.currentTimeMillis() ;
    if(period > 0) {
      AutoCommitThread.getInstance().setAutoCommit(this, size, period) ;
//    AutoCommitThread.getInstance().add(this) ;
    } else {
      AutoCommitThread.getInstance().remove(this) ;
    }
  }
  
  public Database<T, K> getDatabase() { return database ; }
  
  public T find(K id) throws Exception {
    if(database.isClose() 
        || database.hasError()) return null;
    return database.get(id) ; 
  }
  
  public long getLastCommitTime() {return lastCommitTime ;}
  
  public int insert(T record) throws Exception {
    if(database.isClose() 
        || database.hasError()) return 0;
    int ret = database.insert(record) ;
    doAutoCommit() ;
    return ret ;
  }
  
  public int remove(K id) throws Exception {
    if(database.isClose()
        || database.hasError()) return 0;
    int ret = database.remove(id) ;
    doAutoCommit() ;
    return ret ;
  }
  
  
  public void commit() throws Exception {
    if(commitCounter < 1){
      if(commitPeriod > 0) lastCommitTime = System.currentTimeMillis() ;
      return ;
    }
    
    if(database.isClose() 
        || database.hasError()) return;
    database.commit() ;
    if(commitPeriod > 0) lastCommitTime = System.currentTimeMillis() ;
    commitCounter = 0;
  }
  
  synchronized public void close() throws Exception {
    if(database.isClose()) return;
    database.close() ;
  }
  
  private void doAutoCommit() throws Exception {
    commitCounter++ ;
    if(commitSize < 1) return; 
    if(commitCounter > commitSize) commit() ;
  }

  public long getLastAccessTime() { return lastAccessTime; }
  public void setLastAccessTime(long lastAccessTime) {
    this.lastAccessTime = lastAccessTime;
  }

  public int getStatus() { return status; }
  public void setStatus(int status) { this.status = status; }

  public long getAccessExpire() { return accessExpire; }
  public void setAccessExpire(long accessExpire) { this.accessExpire = accessExpire; }

  public int getCommitSize() { return commitSize; }
  public void setCommitSize(int commitSize) { this.commitSize = commitSize; }

  public int getCommitCounter() { return commitCounter; }
  public void setCommitCounter(int commitCounter) { this.commitCounter = commitCounter; }

  public long getCommitPeriod() { return commitPeriod ; }
  public void setCommitPeriod(long commitPeriod) { this.commitPeriod = commitPeriod; }
  
  public synchronized void repair(boolean error) {
    if(repair) return;
    repair = true;
//    File file  = new File(location + "/database.working");
//    if(file.exists()) return;
    if(error) Application.addError(AutoCommitDB.this);
    new Thread(new AutoDatabaseDefragmenter()).start();
  }
  
  public synchronized boolean isRepair() { return repair; }
  
  protected final class AutoDatabaseDefragmenter implements Runnable {
    
    AutoDatabaseDefragmenter() {
    }
    
    public void run() {
//      System.out.println(" == >"+ AutoCommitDB.this + " : "+ Thread.currentThread().hashCode()+ " == > " + repair);
//      if(repair) return;
     
      DatabaseDefragmenter<T, K> optimizer = new DatabaseDefragmenter<T, K>(database) ;
      optimizer.setPageSize(10000);
      optimizer.setIgnoreCorruptedRecord(true);
      String label = AutoCommitDB.this.getClass().getSimpleName() + "/" + new NameConverter().decode(name);
      LogService.getInstance().setMessage("APPLICATION", null, "Start repair  " + Thread.currentThread().hashCode() + " : "+ label +" database !");
      try {
        optimizer.run() ;
        LogService.getInstance().setMessage("APPLICATION", null, "Repair "+ label +" database successful!");
      } catch (Exception e) {
        LogService.getInstance().setThrowable( e);
      }
      LogService.getInstance().setMessage("APPLICATION", null, "Finished repair  "+ label +" database !");
      Application.removeError(AutoCommitDB.this);
      repair = false;
    }
  }

}