/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.db.sync;

import org.vietspider.index.ITextIndex;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Oct 22, 2009  
 */
public class SyncContentIndex extends SyncHandler<ITextIndex> {
  
  public SyncContentIndex() {
    super("content_index", "sync.content.index.server", "add.content.index");
  }

}
