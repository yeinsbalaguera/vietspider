package org.headvances.vietspider.storage.v1.shell;

import java.util.ArrayList;
import java.util.List;

import org.headvances.io.Log;
import org.headvances.vietspider.storage.v1.url.URLInfo;
import org.headvances.vietspider.storage.v1.url.URLTrackerDB;
import org.headvances.vietspider.storage.v1.url.URLTrackerDBManager;

public class URLDBTestCommand implements Command {

  public void execute(CommandParser parser, Shell shell) throws Exception {
    int insert = parser.getOptionAsInt("insert", 5000) ;
    test(shell, Integer.toString((int)(Math.random() * insert)), insert) ;
    test(shell, Integer.toString((int)(Math.random() * insert)), insert) ;
    test(shell, Integer.toString((int)(Math.random() * insert)), insert) ;
    URLTrackerDBManager manager = shell.getURLTrackerDBManager() ;
    manager.commit() ;
  }
  
  public void test(Shell shell, String dbName, int insert) throws Exception {
    URLTrackerDBManager manager = shell.getURLTrackerDBManager() ;
    URLTrackerDB db = manager.getURLTrackerDB(dbName) ;
    Updater updater = new Updater(shell, db) ;
    Searcher searcher = new Searcher(shell, db) ;
    Thread inserter = new Inserter(shell, db, insert, updater, searcher) ;
    inserter.start() ;
    updater.start() ;
    searcher.start() ;
    while(true) {
      if(inserter.isAlive()) Thread.sleep(500) ;
      else break;
    }
    Thread.sleep(3000) ;
    updater.interrupt() ;
    searcher.interrupt() ;
  }

  public String getCommand() { return "urldb:test" ; }

  public String getDetailHelp() { return "urldb:test"; }

  public String getShortHelp() { return "urldb:test"; }

  static public class Inserter extends Thread {
    private Shell shell ;
    private URLTrackerDB db ;
    private int number ;
    private Updater updater ;
    private Searcher searcher ;
    
    public Inserter(Shell shell, URLTrackerDB db, int number, Updater updater, Searcher searcher) { 
      this.shell = shell ;
      this.db = db ; 
      this.number = number ;
      this.updater = updater ;
      this.searcher = searcher ;
    }
    
    public void run() {
      Log log = shell.getLog() ;
      try {
        long start = System.currentTimeMillis() ;
        int counter = 0 ;
        while(counter < number) {
          String host = "www.host" + (int)(Math.random() * number) + ".com" ;
          for(int i = 0; i < 250; i++) {
            int value = (int)(Math.random() * (number * 100)) ;
            String url = host + "/request?param1=" + value  ;
            URLInfo urlInfo = new URLInfo(url) ;
            db.insert(urlInfo) ;
            if(i > 0 && i % 500 == 0) {
              //db.commit() ;
              long end = System.currentTimeMillis() ;
              long time = end - start ;
              log.println("Insert 500/" + i + " in " + time + "ms") ;
              start = end ;
            }
            if(Math.random() > 0.75) updater.add(url) ;

            double random = Math.random() ;
            if(random > 0.35 && random < 0.50) searcher.add(url) ;
            counter++ ;
            if(counter == number) break ;
          }
          //db.commit() ;
          long time = System.currentTimeMillis() - start ;
          log.println("Insert 500/" + number + " in " + time + "ms") ;
        }
      } catch(Exception ex) {
        ex.printStackTrace() ;
      }
    }
  }
  
  static public class Updater extends Thread {
    private Shell shell ;
    private URLTrackerDB db ;
    private List<String> urls = new ArrayList<String>(500) ;
    
    public Updater(Shell shell, URLTrackerDB db) { 
      this.shell = shell ; 
      this.db = db ;
    }
    
    synchronized void add(String domain) { urls.add(domain) ; }
    
    synchronized String[] getUrls() {
      String[] holder = new String[urls.size()] ;
      urls.toArray(holder) ;
      urls.clear() ;
      return holder ;
    }

    public void run() {
      try {
        Thread.sleep(3000) ;
        while(true) {
          Thread.sleep(2000) ;
          update(getUrls()) ;
        }
      } catch(InterruptedException ex) {
        update(getUrls()) ;
      }
    }
    
    private void update(String[] urls) {
      Log log = shell.getLog() ;
      try {
        long start = System.currentTimeMillis() ;
        for(int i = 0; i < urls.length; i++) {
          URLInfo urlInfo = db.find(urls[i]) ;
          if(urlInfo == null) {
            log.error("ERROR" , "expect to find the domain " + urls[i] + " in the database");
            return ;
          }
          urlInfo.setLastAccessTime(System.currentTimeMillis());
          db.insert(urlInfo) ;
        }
        //db.commit() ;
        long time = System.currentTimeMillis() - start ;
        log.println("Update " + urls.length + " in " + time + "ms") ;
      } catch(Exception ex) {
        ex.printStackTrace() ;
        System.exit(1) ;
      }
    }
  }
  
  static public class Searcher extends Thread {
    private Shell shell ;
    private URLTrackerDB db ;
    
    private List<String> urls = new ArrayList<String>(500) ;
    
    public Searcher(Shell shell, URLTrackerDB db) { 
      this.shell = shell ; 
      this.db = db ;
    }
    
    synchronized void add(String url) { urls.add(url) ; }
    
    synchronized String[] getUrls() {
      String[] holder = new String[urls.size()] ;
      urls.toArray(holder) ;
      urls.clear() ;
      return holder ;
    }

    public void run() {
      try {
        Thread.sleep(3000) ;
        while(true) {
          Thread.sleep(500) ;
          search(shell, getUrls()) ;
        }
      } catch(InterruptedException ex) {
        search(shell, getUrls()) ;
      }
    }
    
    private void search(Shell shell, String[] url) {
      Log log = shell.getLog() ;
      try {
        long start = System.currentTimeMillis() ;
        int foundCounter  = 0 ;
        for(int i = 0; i < url.length; i++) {
          URLInfo urlInfo = db.find(url[i]) ;
          if(urlInfo != null) foundCounter++ ;
        }
        long time = System.currentTimeMillis() - start ;
        log.println("Search Found " + foundCounter + "/" + url.length + " in " + time + "ms") ;
      } catch(Exception ex) {
        ex.printStackTrace() ;
        System.exit(1) ;
      }
    }
  }
}