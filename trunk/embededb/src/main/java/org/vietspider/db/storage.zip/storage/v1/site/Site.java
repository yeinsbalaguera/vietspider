package org.headvances.vietspider.storage.v1.site;

import java.nio.ByteBuffer;
import java.util.Date;

import org.headvances.storage.v3.ByteBufferUtil;
import org.headvances.storage.v3.MD5Hash;
import org.headvances.storage.v3.StoragePlugin;
import org.headvances.storage.v3.UTF8String;
import org.headvances.storage.v3.db.Record;

public class Site extends Record<MD5Hash> {
  final static byte WAIT_STATUS = 0, CONFIG_STATUS = 1, IGNORE_STATUS = 2 ;
  final static UTF8String EMPTY_DESC = new UTF8String(new byte[0]) ; 
  
  private MD5Hash id ;
  private String  domain ;
  private String  ip ;
  private String  language  ;
  private byte    status = WAIT_STATUS ;
  private UTF8String  description = EMPTY_DESC;
  private Date    modifiedTime ;

  public Site() {
    
  }
  
  public Site(String domain) {
    this.id = MD5Hash.digest(domain) ;
    this.domain = domain ;
    this.modifiedTime = new Date() ;
    this.language = "unknown" ;
    this.ip = "" ;
  }
  
  public MD5Hash getId() { return id ; }
  public void    setId(MD5Hash id) { this.id = id ; }
  
  public String getDomain() { return domain ; }
  public void   setDomain(String s) { this.domain = s  ; }
  
  public String getIP() { return ip ; }
  public void   setIP(String s) { this.ip = s ; }
  
  public String getLanguage() { return language ; }
  public void   setLanguage(String lang) { this.language = lang ; }
  
  public byte  getStatus() { return status ; }
  public void  setStatus(byte status) { this.status = status ; }

  public UTF8String getDescriptionAsUTF8String() {  return description ; }
  
  public String getDescription() { 
    if(description == null) return "" ;
    return description.toString() ; 
  }

  public void   setDescription(String desc) { 
    this.description = new UTF8String(desc) ; 
  }

  public Date   getModifiedTime() { return modifiedTime ; }
  public void   setModifiedTime(Date date) { this.modifiedTime = date ; }
  
  public void update(Record<MD5Hash> other) {
    Site site = (Site) other ;
    this.ip = site.getIP() ;
    this.language = site.getLanguage() ;
    this.status = site.getStatus() ;
    this.description = site.getDescriptionAsUTF8String();
    this.modifiedTime = site.getModifiedTime() ;
  }

  @SuppressWarnings("all")
  public void read(StoragePlugin plugin, ByteBuffer buffer, String version) throws Exception {
    version = ByteBufferUtil.getFieldAsString(buffer, "version") ;
    id = ByteBufferUtil.getField(buffer, "id", new MD5Hash(), version) ;
    domain = ByteBufferUtil.getFieldAsString(buffer, "domain") ;
    ip = ByteBufferUtil.getFieldAsString(buffer, "ip") ;
    language = ByteBufferUtil.getFieldAsString(buffer, "language") ;
    status = ByteBufferUtil.getFieldAsByte(buffer, "status") ;
    description = ByteBufferUtil.getFieldAsUTF8String(buffer, "description") ;
    if(description.getBytes().length == 0) this.description = EMPTY_DESC ;
    modifiedTime = new Date(ByteBufferUtil.getFieldAsLong(buffer, "modifiedTime")) ;
  }

  @SuppressWarnings("all")
  public void write(StoragePlugin plugin, ByteBuffer buffer) throws Exception {
    ByteBufferUtil.putField(buffer, "version", "1.0") ;
    ByteBufferUtil.putField(buffer, "id", id) ;
    ByteBufferUtil.putField(buffer, "domain", domain) ;
    ByteBufferUtil.putField(buffer, "ip", ip) ;
    ByteBufferUtil.putField(buffer, "language", language) ;
    ByteBufferUtil.putField(buffer, "status", status) ;
    ByteBufferUtil.putField(buffer, "description", description) ;
    ByteBufferUtil.putField(buffer, "modifiedTime", modifiedTime.getTime()) ;
  }
}