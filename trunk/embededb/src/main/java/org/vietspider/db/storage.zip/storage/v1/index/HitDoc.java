package org.headvances.vietspider.storage.v1.index;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.FieldSelector;
import org.apache.lucene.document.FieldSelectorResult;
import org.apache.lucene.index.IndexReader;
import org.headvances.storage.v3.MD5Hash;

public class HitDoc {
  private static IdFieldSelector ID_SELECTOR = new IdFieldSelector() ;
  
  int docId ;
  float score ;
  
  public HitDoc(int docId, float score) {
    this.docId = docId ;
    this.score = score ;
  }
  
  public void init(int docId, float score) {
    this.docId = docId ;
    this.score = score ;
  }

  public int getDocId() { return docId ; }
  
  public float getScore() { return score ; }
  
  public MD5Hash getId(IndexReader reader) throws Exception {
    Document doc = reader.document(docId, ID_SELECTOR) ;
    return new MD5Hash(doc.getField("id").stringValue()) ;
  }
  
  static public class IdFieldSelector implements FieldSelector {
    public FieldSelectorResult accept(String fieldName) {
      if("id".equals(fieldName)) return FieldSelectorResult.LOAD_AND_BREAK;
      return FieldSelectorResult.NO_LOAD ;
    }
  }
}
