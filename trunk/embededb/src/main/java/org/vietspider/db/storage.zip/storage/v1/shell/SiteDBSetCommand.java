package org.headvances.vietspider.storage.v1.shell;

import org.headvances.io.Log;

public class SiteDBSetCommand implements Command {

  public void execute(CommandParser parser, Shell shell) throws Exception {
    Log log = shell.getLog() ;
    String dbdir = parser.getOption("dbdir", null) ;
    if(dbdir == null) {
      log.println(getDetailHelp()) ;
    }
    shell.setSiteDB(dbdir) ;
  }

  public String getCommand() { return "sitedb:set" ; }

  public String getShortHelp() {
    return "Set the directory for the site db";
  }
  
  public String getDetailHelp() {
    return "sitedb:set --dbdir=path" ;
  }
}
