/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.db.sync;

import org.vietspider.bean.Article;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Sep 10, 2009  
 */
public class SyncArticleData extends SyncHandler<Article> {
  
  SyncArticleData() {
    super("article", "sync.article.server", "add.article");
  }
  
}
