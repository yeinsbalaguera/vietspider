package org.headvances.vietspider.storage.v1.index;

import java.util.Comparator;

import org.apache.lucene.search.HitCollector;
import org.headvances.util.HeapTree;

public class HitDocCollector extends HitCollector {
  final static public HitDocScoreComparator COMPARATOR = new HitDocScoreComparator() ;  
  
  HeapTree<HitDoc> holder ;
  int totalHit = 0 ;
  HitDoc freeHitDoc ;
  
  public HitDocCollector(int maxSize) {
    holder = new HeapTree<HitDoc>(maxSize, COMPARATOR) ;
  }

  public void collect(int doc, float score) {
    HitDoc hitDoc = null ;
    if(freeHitDoc != null) {
      hitDoc = freeHitDoc ;
      hitDoc.init(doc, score) ;
    } else {
      hitDoc = new HitDoc(doc, score) ;
    }
    freeHitDoc = holder.insert(hitDoc) ;
    totalHit++ ;
  }

  public int getTotalHit() { return totalHit ; }
  public void setTotalHit(int number) { totalHit = number ; }

  public int getCollectCounter() { return holder.size() ; }
  
  public HitDoc[] getHitDoc() {
    HitDoc[] hitDoc = 
      holder.toArray(new HitDoc[holder.size()], HeapTree.DESC_ORDER) ;
    return hitDoc ;
  }

  static public class HitDocScoreComparator implements Comparator<HitDoc> {
    public int compare(HitDoc hd1, HitDoc hd2) {
      if(hd1.score < hd2.score) return -1 ;
      else if(hd1.score > hd2.score) return 1 ;
      else return 0;
    }
  }

}