package org.headvances.vietspider.storage.v1.shell;

import org.headvances.io.Log;
import org.headvances.storage.v3.MD5Hash;
import org.headvances.storage.v3.db.DatabaseDefragmenter;
import org.headvances.vietspider.storage.v1.site.Site;
import org.headvances.vietspider.storage.v1.site.SiteDB;

public class SiteDBCommand implements Command {

  public void execute(CommandParser parser, Shell shell) throws Exception {
    Log log = shell.getLog() ;
    String opindex = parser.getOption("optimizeindex", null) ;
    String repair = parser.getOption("repair", null) ;
    int pagesize = parser.getOptionAsInt("pagesize", 1000) ;
    if(repair != null) {
      DatabaseDefragmenter<Site, MD5Hash> optimizer = 
        new DatabaseDefragmenter<Site, MD5Hash>(shell.getSiteDB().getDatabase()) ;
      optimizer.setPageSize(pagesize) ;
      optimizer.run() ;
    }
    
    if(opindex != null) {
      shell.getSiteDB().getSiteIndexer().optimize() ;
    }
    SiteDB db = shell.getSiteDB() ;
    log.println("Site DB Location : " + db.getLocation());
  }
  
  public String getCommand() { return "sitedb:db" ; }

  public String getDetailHelp() {
    return "sitedb:db --repair --optimizeindex";
  }

  public String getShortHelp() {
    return "repair, optimize the database" ;
  }

}
