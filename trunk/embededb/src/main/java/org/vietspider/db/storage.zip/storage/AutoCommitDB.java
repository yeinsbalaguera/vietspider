package org.headvances.vietspider.storage;

import org.headvances.storage.v3.SerializableObject;
import org.headvances.storage.v3.db.Record;

abstract public class AutoCommitDB<T extends Record<K>, K extends SerializableObject> extends CommitDB<T,K> {
  
  private long commitTime = 0;
  protected long commitExpire = 15*1000 ;
  
  private int commitCounter = 0;
  protected int commitSize = 10 ;
  
  protected AutoCommitDB(String name, String dbdir) throws Exception {
    super(name, dbdir);
  }
  
  public int insert(T record) throws Exception {
    if(database.isClose() 
        || database.hasError()) return 0;
    int ret = database.insert(record) ;
    commitCounter++;
    lastAccessTime = System.currentTimeMillis();
    return ret ;
  }
  
  public int remove(K id) throws Exception {
    if(database.isClose()
        || database.hasError()) return 0;
    int ret = database.remove(id) ;
    commitCounter++;
    lastAccessTime = System.currentTimeMillis();
    return ret ;
  }
  
  public void commit() throws Exception {
    commitTime = System.currentTimeMillis();
    
    if(commitCounter < 1) return ;
    
    if(isClose() || isRepair() || database.hasError()) return;
    
    database.commit() ;
    commitCounter = 0;
  }
  
  public boolean isCommit() { 
    if(commitCounter < 1) return false;
    return commitCounter >= commitSize 
          || (System.currentTimeMillis() - commitTime) >= commitExpire;
  }
  
}