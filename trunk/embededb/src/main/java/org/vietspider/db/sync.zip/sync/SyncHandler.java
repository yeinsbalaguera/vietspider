/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.db.sync;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileFilter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.vietspider.common.io.DataReader;
import org.vietspider.common.io.DataWriter;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.db.SystemProperties;
import org.vietspider.net.client.DataClientService;
import org.vietspider.net.server.URLPath;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Oct 22, 2009  
 */
public class SyncHandler<T extends Serializable> {

  protected volatile long sizeOfWorking = 100;

  protected volatile CopyOnWriteArrayList<T> temp = new CopyOnWriteArrayList<T>();

  protected File folder;

  protected String server_action;
  protected String server_address;

  protected DataClientService client;  

  protected volatile boolean execute = true;
  protected volatile boolean connected = true;
  
  protected volatile long lastSync = -1;
  protected volatile int maxSync = 100;

  SyncHandler(File folder, String server, String action) {
    this.server_address = server;
    this.server_action = action;
    this.folder = folder;

    String remote = SystemProperties.getInstance().getValue(server_address);
    if(remote == null || remote.trim().isEmpty()) return;
    LogService.getInstance().setMessage(null, "search engine sync " + folder.getName() + " to "+ remote);
    client = new DataClientService(remote);
  }
  
  public DataClientService getClient() { return client;  }

  public SyncHandler(String name, String server, String action) {
    this(UtilFile.getFolder("content/sync/" + name), server, action);
  }

  public void add(T value) {
    if(client == null) return;
    client.closeTimeout();
    if(temp.size() >= sizeOfWorking) store1(temp);
    save(value);
  }

  protected boolean sync()  {
    if(client == null) return false;
    
    if(!connected) testConnection();
    if(!connected) return false;
    
    ArrayList<T> indexs = new ArrayList<T>();
    try {
      load(indexs);
    } catch (Throwable e) {
      LogService.getInstance().setThrowable(e);
    }
    if(indexs.size() < 1) return false;
    
    lastSync = System.currentTimeMillis();
    
//    System.out.println("chuan bi sync toi "+ client.getUrl());
    
    try {
      ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
      ObjectOutputStream out = new ObjectOutputStream(byteOutputStream);
      out.writeObject(indexs);
      out.flush();

      Header header = new BasicHeader("action", server_action);

      byte [] bytes = byteOutputStream.toByteArray();
      client.postResponse(URLPath.SEARCH_HANDLER, bytes, header);
//    } catch (ConnectionPoolTimeoutException e1) {
//      connected = false;      
//      String remote = SystemProperties.getInstance().getValue(server_address);
//      if(remote == null || remote.trim().isEmpty()) return;
//      LogService.getInstance().setMessage(null, "search engine sync " + folder.getName() + " to "+ remote);
//      client = new DataClientService(remote);
    } catch (Throwable e) {
      connected = false;      
      LogService.getInstance().setThrowable(client.getUrl(), e);
      CopyOnWriteArrayList<T> list = new CopyOnWriteArrayList<T>();
      list.addAll(indexs);
      store1(list);
      return false;
    }
    return true;
  }

  public void setSizeOfWorking(long sizeOfWorking) {
    this.sizeOfWorking = sizeOfWorking;
  }

  protected void save(T data) {
    //    System.out.println("luc save "+ data.getContentIndex());
    temp.add(data);
  }

  public void load(java.util.Collection<T> working) throws Throwable {
    File [] files = UtilFile.listModifiedFiles(folder, new FileFilter() {
      public boolean accept(File f) {
        return f.isFile();
      }
    });

    if(files == null || files.length < 1) {
      if(temp.size() >= maxSync || System.currentTimeMillis() - lastSync >= 5*60*1000l) {
        int idx = 0;
        Iterator<T> iterator = temp.iterator();
        //      if(temp.size() > 0) System.out.println(" luc truoc "+ temp.size());
        while(iterator.hasNext()) {
          T data  = iterator.next();
          working.add(data);
          temp.remove(data);
          idx++;
          if(idx >= sizeOfWorking) break;
        }
      }
//      if(working.size() > 0) System.out.println(" luc sau "+ temp.size());
      return;
    }

    int idx = 0;
    int fileIndex  = files.length-1;
    while(idx < sizeOfWorking) {
      if(fileIndex < 0) break;
      File file  = files[fileIndex];
      byte []  bytes = new DataReader().load(file);
      file.delete();

      ByteArrayInputStream byteInput = new ByteArrayInputStream(bytes);
      DataInputStream buffered = new DataInputStream(byteInput);
      try {
        while(true) { 
          try {
            int length = buffered.readInt();
            bytes = new byte[length];
            buffered.read(bytes, 0, length); 
            T data = toData(bytes);
            //          System.out.println(" === > "+ data.getContentIndex().getId());
            working.add(data);
            idx++;
          } catch (EOFException e) {
            break;
          }
        }
      } finally {
        buffered.close();
      }
      fileIndex--;
      //      System.out.println(" doc xong duoc "+ idx);
    }
  }

  @SuppressWarnings("unchecked")
  private T toData(byte[] bytes) throws Throwable {
    ByteArrayInputStream byteInputStream = new ByteArrayInputStream(bytes);
    ObjectInputStream objectInputStream = null;
    try {
      objectInputStream = new ObjectInputStream(byteInputStream);
      return (T)objectInputStream.readObject();
    } catch (StackOverflowError e) {
      LogService.getInstance().setMessage("TPDATABASE - LOAD", new Exception(e), e.toString() );
      return null;
    } catch (Throwable e) {
      LogService.getInstance().setThrowable(e);
      return null;
    } finally {
      try {
        if(byteInputStream != null) byteInputStream.close();
      } catch (Exception e) {
      }
      try {
        if(objectInputStream != null)  objectInputStream.close();
      } catch (Exception e) {
      }
    } 
  }
  
  public void storeTemp() {
    store1(temp);
  }

  public synchronized void store1(List<T> list) {
    ByteArrayOutputStream bytesOutput =  new ByteArrayOutputStream(10*1024*1024);
    DataOutputStream buffered = new DataOutputStream(bytesOutput);
    Iterator<T> iterator = list.iterator();
    while(iterator.hasNext()) {
      T data = iterator.next();
      writeBuffer(buffered, data);
      list.remove(data);
    }

    byte [] bytes = bytesOutput.toByteArray();
    if(bytes.length < 10) return;

    File file = searchNewFile();
    try {
      new DataWriter().save(file, bytes);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }

  private void writeBuffer(DataOutputStream buffered, T data) {
    //  System.out.println("luc save "+ data.getContentIndex());
    ByteArrayOutputStream bytesObject = new ByteArrayOutputStream();
    ObjectOutputStream out = null;
    try {
      out = new ObjectOutputStream(bytesObject);
      out.writeObject(data);
      out.flush();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      return;
    } finally {
      try {
        if(bytesObject != null) bytesObject.close();
      } catch (Exception e) {
      }
      try {
        if(out != null) out.close();
      } catch (Exception e) {
      }
    }

    byte [] bytes = bytesObject.toByteArray();
    try {
      buffered.writeInt(bytes.length);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      return;
    }

    try {
      buffered.write(bytes, 0, bytes.length);
      buffered.flush();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }

  private File searchNewFile() {
    //    File folder = UtilFile.getFolder("content/tp/temp/docs2/");
    int name = 0;
    File file = new File(folder, String.valueOf(name));
    while(file.exists()) {
      name++;
      file = new File(folder, String.valueOf(name));
    }
    return file;
  }

  
  protected void testConnection() {
    try {
      Header  header = new BasicHeader("action", "test.connection");
      byte [] bytes = client.post(URLPath.SEARCH_HANDLER, "hi".getBytes(), header);
      if(bytes.length > 0) connected = true;
    } catch (Throwable e) {
      LogService.getInstance().setMessage(null, e.toString());
      connected = false;      
    }
  }

}
