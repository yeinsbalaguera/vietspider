package org.headvances.vietspider.storage.v1.shell;

import org.headvances.io.Log;
import org.headvances.storage.v3.MD5Hash;
import org.headvances.storage.v3.db.Database;
import org.headvances.vietspider.storage.v1.site.Site;
import org.headvances.vietspider.storage.v1.site.SiteDB;

public class SiteDBInfoCommand implements Command {

  public void execute(CommandParser parser, Shell shell) throws Exception {
    Log log = shell.getLog() ;
    SiteDB db = shell.getSiteDB() ;
    if(db == null) {
      log.println("The SiteDB is not set") ;
      return ;
    }
    Database<Site, MD5Hash> database = db.getDatabase() ;
    log.println("Site DB Location : " + db.getLocation());
    log.println("Site DB Data Size: " + database.getStorage().getDataSize()) ;
    log.println("Site DB Records  : " + database.getStorage().getNumberOfRecord()) ;
  }
  
  public String getCommand() { return "sitedb:info" ; }

  public String getDetailHelp() {
    return null;
  }

  public String getShortHelp() {
    return null;
  }

}
