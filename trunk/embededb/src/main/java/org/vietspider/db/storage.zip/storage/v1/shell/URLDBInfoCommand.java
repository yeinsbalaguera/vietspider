package org.headvances.vietspider.storage.v1.shell;

import org.headvances.io.Log;
import org.headvances.vietspider.storage.v1.url.URLTrackerDB;
import org.headvances.vietspider.storage.v1.url.URLTrackerDBManager;

public class URLDBInfoCommand implements Command {
  public void execute(CommandParser parser, Shell shell) throws Exception {
    Log log = shell.getLog() ;
    URLTrackerDBManager manager = shell.getURLTrackerDBManager() ;
    if(manager == null) {
      log.println("The URLTrackerDBManager is not set") ;
      return ;
    }
    log.println("URL DB Location  : " + manager.getLocation()) ;
    int[] columnWidth = {40, 20, 20} ;
    String[] columnHeader = {"Name", "Size", "# Records"} ;
    log.printTable("  ", columnHeader, columnWidth) ;
    URLTrackerDB[] dbs = manager.getURLTrackerDB() ; 
    for(URLTrackerDB db : dbs) {
      log.println("  ----------------------------------------------------------------------------") ;
      String[] row = {
          db.getName(),
          Long.toString(db.getDatabase().getStorage().getDataSize()) ,
          Long.toString(db.getDatabase().getStorage().getNumberOfRecord()) 
      } ;
      log.printTable("  ", row, columnWidth) ;
    }
  }
  
  public String getCommand() { return "urldb:info" ; }

  public String getDetailHelp() {
    return null;
  }

  public String getShortHelp() {
    return null;
  }
}