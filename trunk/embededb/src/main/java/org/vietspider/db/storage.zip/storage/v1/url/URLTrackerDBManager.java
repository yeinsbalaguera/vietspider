package org.headvances.vietspider.storage.v1.url;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class URLTrackerDBManager {
  private String location ;
  private Map<String, URLTrackerDB> map ;
  
  public URLTrackerDBManager(String location) throws Exception {
    this.location = location ;
    this.map = new HashMap<String, URLTrackerDB>() ;
    File locDir = new File(this.location) ;
    if(!locDir.exists()) {
      locDir.mkdirs() ;
    } else {
      String[] dbname = locDir.list() ;
      for(int i = 0; i < dbname.length; i++) {
        this.getURLTrackerDB(dbname[i]) ;
      }
    }
  }
  
  public String getLocation() { return this.location ; }
  
  synchronized public URLTrackerDB getURLTrackerDB(String name) throws Exception {
    String dblocation = location + "/" + name ;
    URLTrackerDB db = map.get(dblocation) ;
    if(db == null) {
      db = new URLTrackerDB(name, dblocation) ;
      //auto commit for 500 actions or every 10 seconds
      db.setAutoCommit(500, 1000 * 10) ;
      map.put(dblocation, db) ;
    }
    return db ;
  }
  
  synchronized public void closeURLTRackerDB(String name) throws Exception {
    URLTrackerDB found = map.remove(name) ;
    if(found == null) {
      throw new Exception("Cannot find the " + name + " in the database manager") ;
    }
    found.close() ;
  }
  
  synchronized public void closeURLTrackerDB(URLTrackerDB db) throws Exception {
    URLTrackerDB found = map.remove(db.getName()) ;
    if(found == null) {
      throw new Exception("Cannot find the " + db.getName() + " in the database manager") ;
    }
    if(found !=  db) {
      throw new Exception("the db " + db.getName() + " is not the same db in the db manager") ;
    }
    db.close() ;
  }
  
  synchronized public void commit() throws Exception {
    Iterator<URLTrackerDB> i = map.values().iterator() ;
    while(i.hasNext())  i.next().commit() ;
  }
  
  synchronized public void close() throws Exception {
    Iterator<URLTrackerDB> i = map.values().iterator() ;
    while(i.hasNext())  i.next().close() ;
    map.clear() ;
  }
  
  synchronized public URLTrackerDB[] getURLTrackerDB() {
    URLTrackerDB[] all = new URLTrackerDB[map.size()] ;
    Iterator<URLTrackerDB> i = map.values().iterator() ;
    int idx = 0 ;
    while(i.hasNext()) all[idx++] = i.next() ;
    return all ;
  }
}