package org.headvances.vietspider.storage.v1.shell;

public interface Command {
  public String getCommand() ;
  public String getShortHelp() ;
  public String getDetailHelp() ;
  public void execute(CommandParser parser, Shell shell) throws Exception ;
}
