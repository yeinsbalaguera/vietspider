package org.headvances.vietspider.storage.v1.url;

import java.io.File;
import java.util.Comparator;

import org.headvances.storage.v3.db.Database;
import org.headvances.storage.v3.db.DatabaseConfig;
import org.headvances.storage.v3.db.DatabasePlugin;
import org.headvances.util.html.URL;
import org.headvances.vietspider.storage.v1.AutoCommitDB;

public class URLTrackerDB extends AutoCommitDB<URLInfo, URLID>{
 
  public URLTrackerDB(String name, String dbdir) throws Exception {
    super(name, dbdir) ;
  }
  
  protected Database<URLInfo, URLID> createDatabase(String dbdir) throws Exception {
    DatabaseConfig dbconfig = new DatabaseConfig(dbdir + "/database") ;
    File dbdirFile = new File(dbconfig.getDatabaseDir()) ;
    if(!dbdirFile.exists()) dbdirFile.mkdirs() ;
    dbconfig.setAllocatedExtra(64) ;
    dbconfig.setCompress(true) ;

    DatabasePlugin<URLInfo, URLID> dbplugin = new DatabasePlugin<URLInfo, URLID>() {
      public URLInfo createStorable() { return new URLInfo() ; }
      public URLInfo[] createStorable(int size) { return new URLInfo[size] ; }
      public URLID createKey() { return new URLID(); }
      public Comparator<URLID> createKeyComparator() { return URLID.COMPARATOR ; }
      public int getKeySize() { return URLID.DATA_LENGTH; }
    } ;
    return new Database<URLInfo, URLID>(dbconfig, dbplugin) ;
  }
  
  public URLInfo find(String url) throws Exception { 
    URLID urlId = new URLID(new URL(url)) ;
    return getDatabase().get(urlId) ; 
  }
}