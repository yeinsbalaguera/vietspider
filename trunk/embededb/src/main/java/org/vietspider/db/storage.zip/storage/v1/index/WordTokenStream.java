package org.headvances.vietspider.storage.v1.index ;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Token;
import org.apache.lucene.analysis.TokenStream;
/**
 * Emits the entire input as a single token.
 */
public class WordTokenStream extends TokenStream {
  private List<Token> tokens_ ;
  private int currentIndex_ ;
  
  public WordTokenStream() {
    this.tokens_ = new ArrayList<Token>() ;
  }
  
  public WordTokenStream(List<Token> tokens) {
    this.tokens_ = tokens ;
  }

  public void add(String token, boolean normalize) {
    if(currentIndex_ > 0) {
      throw new RuntimeException("Toknenizer is iterating..........") ;
    }
    if(normalize) token = token.trim().toLowerCase() ;
    tokens_.add(new Token(token, 0, token.length()));
  }
  
  public Token next() throws IOException {
    if(currentIndex_ < tokens_.size()) {
      return tokens_.get(currentIndex_++) ;
    }
    return null ;
  }
  
  public void reset() throws IOException {
    currentIndex_ =  0 ;
  }
  
  public void close() throws IOException { }
}