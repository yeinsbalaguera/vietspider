package org.headvances.vietspider.storage.v1.url;

import java.nio.ByteBuffer;

import org.headvances.storage.v3.ByteBufferUtil;
import org.headvances.storage.v3.StoragePlugin;
import org.headvances.storage.v3.UTF8String;
import org.headvances.storage.v3.db.Record;
import org.headvances.util.html.URL;

public class URLInfo extends Record<URLID> {
  private URLID urlId ;
  private UTF8String url ;
  private long vietspiderId = 1111 ;
  private long lastAccessTime = -1;
  
  public URLInfo() {
  }
  
  public URLInfo(String url) {
    URL urlParser = new URL(url) ;
    this.urlId = new URLID(urlParser) ;
    this.url = new UTF8String(urlParser.getNormalizeURL()) ;
  }
  
  public URLID getId() { return urlId ; }
  
  public URLID getURLId() { return urlId ; }
  
  public String getURL() { 
    if(url == null) return null ;
    return url.toString() ;
  }
  
  public UTF8String getURLAsUTF8String() { return url ; }
  
  public long getVietspiderId() { return vietspiderId ; }
  public void setVietspiderId(long id) { this.vietspiderId = id ; }
  
  public long getLastAccessTime() { return this.lastAccessTime ; }
  public void setLastAccessTime(long time) { this.lastAccessTime = time ; }
  
  public void update(Record<URLID> record) {
    URLInfo other = (URLInfo) record ;
    this.url = other.getURLAsUTF8String();
    this.lastAccessTime = other.getLastAccessTime();
  }

  @SuppressWarnings("all")
  public void read(StoragePlugin plugin, ByteBuffer buffer, String version) throws Exception {
    version = ByteBufferUtil.getFieldAsString(buffer, "version") ;
    urlId = ByteBufferUtil.getField(buffer, "urlId", new URLID(), version) ;
    url = ByteBufferUtil.getFieldAsUTF8String(buffer, "url") ;
    vietspiderId = ByteBufferUtil.getFieldAsLong(buffer, "vietspiderId") ;
    lastAccessTime = ByteBufferUtil.getFieldAsLong(buffer, "lastAccess") ;
  }

  @SuppressWarnings("all")
  public void write(StoragePlugin plugin, ByteBuffer buffer) throws Exception {
    ByteBufferUtil.putField(buffer, "version", "1.0") ;
    ByteBufferUtil.putField(buffer, "urlId", urlId) ;
    ByteBufferUtil.putField(buffer, "url", url) ;
    ByteBufferUtil.putField(buffer, "vietspiderId", vietspiderId) ;
    ByteBufferUtil.putField(buffer, "lastAccessTime", lastAccessTime) ;
  }
}