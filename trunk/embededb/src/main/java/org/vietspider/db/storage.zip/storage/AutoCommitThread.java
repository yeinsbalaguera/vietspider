package org.headvances.vietspider.storage;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.vietspider.common.Application;
import org.vietspider.common.io.LogService;

@SuppressWarnings("unchecked")
public abstract class AutoCommitThread<T extends AutoCommitDB> extends Thread {
  
  private Map<String, T> holder ;
  
  protected AutoCommitThread() {
    holder = new ConcurrentHashMap<String, T>() ;
    Application.addShutdown(new Application.IShutdown() {
      public void execute() {
        commit();
        
        Iterator<T> i = holder.values().iterator() ;
        while(i.hasNext()) {
          AutoCommitDB db = i.next() ;
          try {
            db.commit();
            db.close();
//            System.err.println(" close when exit "+ db.getName());
          } catch (Exception e) {
            LogService.getInstance().setThrowable(db.getName(), e);
          }
        }
      }
    });
    
    this.start();
  }
  
  public void run() {
    while(true) {
      commit();
      try {
        Thread.sleep(5*1000) ;
      } catch(Exception ex) {
      }
    }
  }
  
  public void commit()  {
    Iterator<T> iterator = holder.values().iterator() ;
    while(iterator.hasNext()) {
      AutoCommitDB db = iterator.next() ;
      if(db.isCommit()) {
        try {
//          System.out.println(" chuan bi commit "+ db.getName());
          db.commit() ;
        } catch (Throwable e) {
          LogService.getInstance().setThrowable(db.getName(), e);
        }
      } else if(db.isExpire()) {
        try {
//          System.out.println(" bi expire "+ db.getName());
          db.close();
        } catch (Throwable e) {
          LogService.getInstance().setThrowable(db.getName(), e);
        }
        iterator.remove();
      }
    }
  }
  
  protected T getAutoCommitDB(String name, String dbdir) {
    if(dbdir == null || name == null) return null;
    T db = holder.get(dbdir);
   
    if(db != null && db.isRepair()) return null;
    
    try {
      if(db == null || db.isClose()) {
        db = createAutoCommitDB(name, dbdir);
        if(db != null) holder.put(dbdir, db);
      } else if(db.getDatabase().hasError()) {
        db.repair(true);
        return null;
      } 
    } catch (Exception e) {
      LogService.getInstance().setThrowable(name, e);
    }
    return db;
  }
  
  public abstract T createAutoCommitDB(String name, String dbdir);
  
 
}