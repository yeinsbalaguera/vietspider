package org.headvances.vietspider.storage.v1.shell;

import java.util.ArrayList;
import java.util.List;

import org.headvances.io.Log;
import org.headvances.storage.v3.MD5Hash;
import org.headvances.vietspider.storage.v1.site.Site;
import org.headvances.vietspider.storage.v1.site.SiteDB;

public class SiteDBTestCommand implements Command {

  public void execute(CommandParser parser, Shell shell) throws Exception {
    int insert = parser.getOptionAsInt("insert", 5000) ;
    Updater updater = new Updater(shell) ;
    Searcher searcher = new Searcher(shell) ;
    Thread inserter = new Inserter(shell, insert, updater, searcher) ;
    inserter.start() ;
    updater.start() ;
    searcher.start() ;
    wait(inserter) ;
    updater.interrupt() ;
    searcher.interrupt() ;
    Thread.sleep(1000) ;
  }

  public String getCommand() { return "sitedb:test" ; }

  public String getDetailHelp() { return "sitedb:test"; }

  public String getShortHelp() { return "sitedb:test"; }

  private void wait(Thread thread) throws Exception {
    while(true) {
      if(thread.isAlive()) Thread.sleep(500) ;
      else return;
    }
  }
  
  static public class Inserter extends Thread {
    private Shell shell ;
    private int number ;
    private Updater updater ;
    private Searcher searcher ;
    
    public Inserter(Shell shell, int number, Updater updater, Searcher searcher) { 
      this.shell = shell ; 
      this.number = number ;
      this.updater = updater ;
      this.searcher = searcher ;
    }
    
    public void run() {
      SiteDB db = shell.getSiteDB() ;
      Log log = shell.getLog() ;
      try {
        long start = System.currentTimeMillis() ;
        for(int i = 0; i < number; i++) {
          int hostName = (int)(Math.random() * (number * 3)) ;
          String domain = "www.host-" + hostName + ".com" ;
          Site site = new Site(domain) ;
          db.insert(site) ;
          if(i > 0 && i % 500 == 0) {
            db.commit() ;
            long end = System.currentTimeMillis() ;
            long time = end - start ;
            log.println("Insert 500/" + i + " in " + time + "ms") ;
            start = end ;
          }
          if(Math.random() > 0.75) updater.add(domain) ;
          
          double random = Math.random() ;
          if(random > 0.35 && random < 0.50) searcher.add(domain) ;
        }
        db.commit() ;
        long time = System.currentTimeMillis() - start ;
        log.println("Insert 500/" + number + " in " + time + "ms") ;
      } catch(Exception ex) {
        ex.printStackTrace() ;
      }
    }
  }
  
  static public class Updater extends Thread {
    private Shell shell ;
    private List<String> domains = new ArrayList<String>(500) ;
    
    public Updater(Shell shell) { 
      this.shell = shell ; 
    }
    
    synchronized void add(String domain) { domains.add(domain) ; }
    
    synchronized String[] getDomains() {
      String[] holder = new String[domains.size()] ;
      domains.toArray(holder) ;
      domains.clear() ;
      return holder ;
    }

    public void run() {
      try {
        Thread.sleep(3000) ;
        while(true) {
          Thread.sleep(2000) ;
          update(shell, getDomains()) ;
        }
      } catch(InterruptedException ex) {
        update(shell, getDomains()) ;
      }
    }
    
    private void update(Shell shell, String[] domain) {
      SiteDB db = shell.getSiteDB() ;
      Log log = shell.getLog() ;
      try {
        long start = System.currentTimeMillis() ;
        for(int i = 0; i < domain.length; i++) {
          Site site = db.find(MD5Hash.digest(domain[i])) ;
          if(site == null) {
            log.error("ERROR" , "expect to find the domain " + domain[i] + " in the database");
            return ;
          }
          site.setDescription("test update") ;
          db.insert(site) ;
        }
        db.commit() ;
        long time = System.currentTimeMillis() - start ;
        log.println("Update " + domain.length + " in " + time + "ms") ;
      } catch(Exception ex) {
        ex.printStackTrace() ;
        System.exit(1) ;
      }
    }
  }
  
  static public class Searcher extends Thread {
    private Shell shell ;
    private List<String> domains = new ArrayList<String>(500) ;
    
    public Searcher(Shell shell) { 
      this.shell = shell ; 
    }
    
    synchronized void add(String domain) { domains.add(domain) ; }
    
    synchronized String[] getUpdateDomains() {
      String[] holder = new String[domains.size()] ;
      domains.toArray(holder) ;
      domains.clear() ;
      return holder ;
    }

    public void run() {
      try {
        while(true) {
          Thread.sleep(500) ;
          search(shell, getUpdateDomains()) ;
        }
      } catch(InterruptedException ex) {
        search(shell, getUpdateDomains()) ;
      }
    }
    
    private void search(Shell shell, String[] domain) {
      SiteDB db = shell.getSiteDB() ;
      Log log = shell.getLog() ;
      try {
        long start = System.currentTimeMillis() ;
        int foundCounter  = 0 ;
        for(int i = 0; i < domain.length; i++) {
          Site[] sites = db.findByDomain(domain[i], 100) ;
          if(sites.length > 0) foundCounter++ ;
        }
        long time = System.currentTimeMillis() - start ;
        log.println("Search Found " + foundCounter + "/" + domain.length + " in " + time + "ms") ;
      } catch(Exception ex) {
        ex.printStackTrace() ;
        System.exit(1) ;
      }
    }
  }
}
