package org.headvances.vietspider.storage.v1.shell;

import org.headvances.storage.v3.db.DatabaseDefragmenter;
import org.headvances.vietspider.storage.v1.url.URLID;
import org.headvances.vietspider.storage.v1.url.URLInfo;
import org.headvances.vietspider.storage.v1.url.URLTrackerDB;
import org.headvances.vietspider.storage.v1.url.URLTrackerDBManager;

public class URLDBCommand implements Command {

  public void execute(CommandParser parser, Shell shell) throws Exception {
    String dbname = parser.getOption("dbname", null) ;
    String repair = parser.getOption("repair", null) ;
    int pagesize = parser.getOptionAsInt("pagesize", 1000) ;
    URLTrackerDBManager manager = shell.getURLTrackerDBManager() ;
    URLTrackerDB[] dbs = manager.getURLTrackerDB() ;
    if(dbname != null) {
      URLTrackerDB db = manager.getURLTrackerDB(dbname) ;
      if(db == null) {
        throw new Exception("Cannot find the db " + dbname) ;
      }
      dbs = new URLTrackerDB[] {db} ;
    }
    if(repair != null) {
      for(int i = 0; i < dbs.length; i++) {
        DatabaseDefragmenter<URLInfo, URLID> optimizer = 
          new DatabaseDefragmenter<URLInfo, URLID>(dbs[i].getDatabase()) ;
        optimizer.setPageSize(pagesize) ;
        optimizer.run() ;
      }
    }
  }
  
  public String getCommand() { return "urldb:db" ; }

  public String getDetailHelp() {
    return "urldb:db --db=name --repair --pagesize=1000";
  }

  public String getShortHelp() {
    return "repair the database" ;
  }

}
