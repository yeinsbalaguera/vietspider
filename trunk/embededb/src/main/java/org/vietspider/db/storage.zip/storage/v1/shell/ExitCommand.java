package org.headvances.vietspider.storage.v1.shell;


public class ExitCommand implements Command {

  public void execute(CommandParser parser, Shell shell) throws Exception {
    System.exit(0) ;
  }
  
  public String getCommand() { return "exit" ; }

  public String getDetailHelp() {
    return "exit";
  }

  public String getShortHelp() {
    return "Exit the program" ;
  }

}
