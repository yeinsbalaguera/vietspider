package org.headvances.vietspider.storage.v1.site;

import java.io.File;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.headvances.storage.v3.MD5Hash;
import org.headvances.storage.v3.db.Database;
import org.headvances.storage.v3.db.DatabaseConfig;
import org.headvances.storage.v3.db.DatabasePlugin;
import org.headvances.vietspider.storage.v1.index.HitDoc;
import org.headvances.vietspider.storage.v1.index.HitDocs;
import org.headvances.vietspider.storage.v1.index.Lucene;

public class SiteDB {
  private String location ;
  private Database<Site, MD5Hash> database ;
  private SiteIndexer siteIndexer ;
 
  public SiteDB(String dbdir) throws Exception {
    this.location = dbdir ;
    DatabaseConfig dbconfig = new DatabaseConfig(dbdir + "/database") ;
    File dbdirFile = new File(dbconfig.getDatabaseDir()) ;
    if(!dbdirFile.exists()) dbdirFile.mkdirs() ;
    dbconfig.setAllocatedExtra(256) ;
    dbconfig.setCompress(true) ;

    DatabasePlugin<Site, MD5Hash> dbplugin = new DatabasePlugin<Site, MD5Hash>() {
      public Site createStorable() { return new Site() ; }
      public Site[] createStorable(int size) { return new Site[size] ; }
      public MD5Hash createKey() { return new MD5Hash(); }
      public Comparator<MD5Hash> createKeyComparator() { return MD5Hash.COMPARATOR ; }
      public int getKeySize() { return MD5Hash.DATA_LENGTH; }
    } ;
    database = new Database<Site, MD5Hash>(dbconfig, dbplugin) ;
    siteIndexer = new SiteIndexer(dbdir + "/indexes") ;
  }
  
  public String getLocation() { return location ; }
  
  public Database<Site, MD5Hash> getDatabase() { return database ; }
  
  public SiteIndexer getSiteIndexer() { return siteIndexer ; }
  
  synchronized public Site find(MD5Hash id) throws Exception { return database.get(id) ; }
  
  synchronized public Site[] findByIP(String ip, int maxReturn) throws Exception {
    return find("ip:" + ip, maxReturn, maxReturn + 1) ;
  }
  
  synchronized public Site[] findByDate(Date fromDate, Date toDate, int maxReturn) throws Exception {
    if(fromDate == null) fromDate = new Date(System.currentTimeMillis() - (1000 * 3600 * 24 * 365 * 15)); 
    if(toDate == null) toDate = new Date() ;
    String query = "modifiedTime:[" + Lucene.format(fromDate) + "-" + Lucene.format(toDate) + "]" ;
    return find(query, maxReturn, maxReturn + 1) ;
  }
  
  synchronized public Site[] findByDomain(String domain, int maxReturn) throws Exception {
    return find("domain:\"" + domain + "\"", maxReturn, maxReturn + 1) ;
  }
  
  synchronized public int insert(Site site) throws Exception {
    int ret = database.insert(site) ;
    if(ret == 1) {
      siteIndexer.index(site, true) ;
    } else {
      siteIndexer.index(site, false) ;
    }
    return ret ;
  }
  
  synchronized public int remove(MD5Hash id) throws Exception {
    int ret =  database.remove(id) ;
    if(ret > 0) siteIndexer.delete(id) ;
    return ret ;
  }
  
  synchronized public void optimize() throws Exception {
    
  }
  
  synchronized public void commit() throws Exception {
    database.commit() ;
    siteIndexer.commit() ;
    siteIndexer.update() ;
  }
  
  synchronized public void close() throws Exception {
    database.close() ;
    siteIndexer.close() ;
  }
  
  private Site[]  find(String query, int maxReturn, int pageSize) throws Exception {
    HitDocs hdocs = siteIndexer.search(query, maxReturn, pageSize) ;
    List<HitDoc> list = hdocs.getPage(1) ;
    MD5Hash[] id = new MD5Hash[list.size()] ;
    for(int i = 0; i < list.size(); i++) {
      HitDoc hdoc = list.get(i) ;
      id[i] = siteIndexer.getSiteId(hdoc) ;
    }
    return database.get(id) ;
  }
}