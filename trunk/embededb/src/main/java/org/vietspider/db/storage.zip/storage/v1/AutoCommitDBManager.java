package org.headvances.vietspider.storage.v1;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public abstract class AutoCommitDBManager<E extends AutoCommitDB<?,?>> {
  
  protected String location ;
  protected Map<String, E> map ;
  
  public AutoCommitDBManager(String location) throws Exception {
    this.location = location ;
    this.map = new HashMap<String, E>() ;
    File locDir = new File(this.location) ;
    if(!locDir.exists()) {
      locDir.mkdirs() ;
    } else {
      String[] dbname = locDir.list() ;
      for(int i = 0; i < dbname.length; i++) {
        this.getAutoCommitDB(dbname[i]) ;
      }
    }
  }
  
  public String getLocation() { return this.location ; }
  
  abstract public E getAutoCommitDB(String name) throws Exception ;
  
  synchronized public void closeAutoCommitDB(String name) throws Exception {
    E found = map.remove(name) ;
    if(found == null) {
      throw new Exception("Cannot find the " + name + " in the database manager") ;
    }
    found.close() ;
  }
  
  synchronized public void closeAutoCommitDB(E db) throws Exception {
    E found = map.remove(db.getName()) ;
    if(found == null) {
      throw new Exception("Cannot find the " + db.getName() + " in the database manager") ;
    }
    if(found !=  db) {
      throw new Exception("the db " + db.getName() + " is not the same db in the db manager") ;
    }
    db.close() ;
  }
  
  synchronized public void commit() throws Exception {
    Iterator<E> i = map.values().iterator() ;
    while(i.hasNext())  i.next().commit() ;
  }
  
  synchronized public void close() throws Exception {
    Iterator<E> i = map.values().iterator() ;
    while(i.hasNext())  i.next().close() ;
    map.clear() ;
  }
  
  abstract public E[] getAutoCommitDB() ;
}