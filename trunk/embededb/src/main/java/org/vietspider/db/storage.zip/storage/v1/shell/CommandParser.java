package org.headvances.vietspider.storage.v1.shell;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.headvances.util.text.StringUtil;

public class CommandParser {
  final static Pattern SEPARATOR = Pattern.compile(" |,") ;

  private String command ;
  private HashMap<String, String> options ;
  private String[] args ;
  
  public CommandParser(String string)  {
    this.options = new HashMap<String, String>() ;
    Tokenizer tokenizer = new Tokenizer(string) ;
    this.command = tokenizer.next() ;

    List<String> argsList = new ArrayList<String>() ;
    String token = tokenizer.next() ;
    while(token != null) {
      if(token.startsWith("--")) {
        token = token.substring(2) ;
        int idx = token.indexOf('=') ;
        if(idx > 0) {
          String name  = token.substring(0, idx) ;
          String value = token.substring(idx + 1) ;
          if(value.charAt(0) == '"' && value.charAt(value.length() - 1) == '"') {
            value = value.substring(1, value.length() - 1) ;
          }
          options.put(name, value) ;
        } else {
          options.put(token, token) ;
        }
      } else {
        argsList.add(token) ;
      }
      token = tokenizer.next() ;
    }
    this.args = StringUtil.toArray(argsList) ;
  }
  
  public String getCommand() { return command  ; }
  
  public String getOption(String name, String defaultValue) {
    String value = options.get(name) ;
    if(value !=null) return value ;
    return defaultValue ;
  }
  
  public int getOptionAsInt(String name, int defaultValue) {
    String value = options.get(name) ;
    if(value !=null) return Integer.parseInt(value);
    return defaultValue ;
  }
  
  public Map<String, String> getOptions() { return options ; }
  
  public String[] getArguments() { return args ; }
  
  public int getPageSizeOption(int defaultValue) {
    String value =  options.get("pagesize") ;
    if(value == null) return defaultValue ;
    try {
      return Integer.parseInt(value) ;
    } catch(Throwable t) {} 
    return defaultValue ;
  }
  
  static public class Tokenizer {
    private char[] buf ;
    private int currentPosition ;
    
    public Tokenizer(String string) {
      this.buf = string.toCharArray() ;
    }
    
    public String next() {
      if(currentPosition >=  buf.length) return null ;
      while(currentPosition < buf.length) {
        if(buf[currentPosition] == ' ' || buf[currentPosition] == '\t') currentPosition++ ;
        else break ;
      }
      boolean openQuote = false;
      int start = currentPosition ;
      while(currentPosition < buf.length) {
        if(buf[currentPosition] == '"') openQuote = !openQuote ;
        if(buf[currentPosition] == ' ' || buf[currentPosition] == '\t') {
          if(!openQuote) break ;
        }
        currentPosition++ ;
      }
      String string =  new String(buf, start, currentPosition - start) ;
      return string.trim() ;
    }
  }
}