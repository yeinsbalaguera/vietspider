package org.headvances.vietspider.storage.v1.shell;

import org.headvances.io.Log;

public class URLDBSetCommand implements Command {

  public void execute(CommandParser parser, Shell shell) throws Exception {
    Log log = shell.getLog() ;
    String dbdir = parser.getOption("dbdir", null) ;
    if(dbdir == null) {
      log.println(getDetailHelp()) ;
    }
    shell.setURLTrackerDBManager(dbdir) ;
  }

  public String getCommand() { return "urldb:set" ; }

  public String getShortHelp() {
    return "Set the directory for the url db";
  }
  
  public String getDetailHelp() {
    return "urldb:set --dbdir=path" ;
  }
}
