package org.headvances.vietspider.storage.v1.url;

import java.nio.ByteBuffer;
import java.util.Comparator;

import org.headvances.storage.v3.MD5Hash;
import org.headvances.storage.v3.SerializableObject;
import org.headvances.util.html.URL;

public class URLID implements SerializableObject {
  final static public int DATA_LENGTH = 4 + MD5Hash.DATA_LENGTH ;
  final static public Comparator<URLID> COMPARATOR = new URLIDComparator() ;
  
  private int hostId ;
  private MD5Hash urlId ; 
  
  public URLID() { }
  
  public URLID(String url) { this(new URL(url)) ; }
  
  public URLID(URL url) {
    this.hostId = url.getHost().hashCode() ;
    this.urlId = MD5Hash.digest(url.getNormalizeURL()) ;
  }
  
  public int getHostId() { return hostId ; }
  
  public MD5Hash getURLId() { return urlId ; }

  public void read(ByteBuffer buffer, String version) throws Exception {
    hostId = buffer.getInt() ;
    byte[] digest = new byte[MD5Hash.DATA_LENGTH] ;
    buffer.get(digest) ;
    urlId = new MD5Hash(digest) ;
  }

  public void write(ByteBuffer buffer) throws Exception {
    buffer.putInt(hostId) ;
    buffer.put(urlId.getDigest()) ;
  }

  
  public static class URLIDComparator implements Comparator<URLID> {
    public int compare(URLID arg1, URLID arg2) {
      int host1 = arg1.getHostId() ;
      int host2 = arg2.getHostId() ;
      if(host1 < host2) return -1 ;
      if(host1 > host2) return 1 ;
      
      MD5Hash urlId1 = arg1.getURLId() ;
      MD5Hash urlId2 = arg2.getURLId() ;
      return urlId1.compareTo(urlId2) ;
    }
  }
}