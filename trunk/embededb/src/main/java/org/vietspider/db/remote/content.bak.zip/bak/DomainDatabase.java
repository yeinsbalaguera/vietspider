/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.       *
 **************************************************************************/
package org.headvances.vietspider.content.bak;

/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.       *
 **************************************************************************/

import java.io.File;

import org.headvances.vietspider.BytesDatabase;
/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Mar 30, 2009  
 */
public class DomainDatabase extends BytesDatabase {

  public DomainDatabase(File folder, long cachedSize) throws Exception {
    super(folder, "domain", cachedSize);
  }

  public void save(long id, byte[] bytes) throws Throwable {
    if(isClose) return;
    map.put(id, bytes);
  }
  
  public byte[] load(long id) throws Throwable {
    if(isClose) return null;
    return map.get(id);
  }
}