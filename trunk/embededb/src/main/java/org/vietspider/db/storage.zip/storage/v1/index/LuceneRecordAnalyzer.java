package org.headvances.vietspider.storage.v1.index;

import java.io.Reader;

import org.apache.lucene.analysis.LowerCaseFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.standard.StandardTokenizer;
/**
 * Author : Tuan Nguyen
 */
public class LuceneRecordAnalyzer extends StandardAnalyzer {
  
  public LuceneRecordAnalyzer() {
  }
  
  public TokenStream tokenStream(String fieldName, Reader reader) {
    if("domain".equals(fieldName)) {
      WordTokenStream stream = new WordTokenStream() ;
      String text = getText(reader) ;
      String[] array = text.split(" ") ;
      for(String token : array) {
        stream.add(token, true) ;
      }
      return stream ;
    }
    return new LowerCaseFilter(new StandardTokenizer(reader)); 
  }

  public String getText(Reader reader) {
    try {
      StringBuilder b = new StringBuilder() ;
      char[] buf = new char[4092] ;
      int available = -1;
      while((available = reader.read(buf)) > -1){
        b.append(buf, 0, available);
      }   
      return b.toString() ;
    } catch(Exception ex) {
      ex.printStackTrace() ;
    }
    return "" ;
  }
}
