/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.cliffc.high_scale_lib;

import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.List;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jan 7, 2009  
 */
public class ConcurrentSetIntBak {
  
  private NonBlockingSetInt nSet;
  private NonBlockingSetInt pSet;
  
  public ConcurrentSetIntBak() {
    nSet = new NonBlockingSetInt();
    pSet = new NonBlockingSetInt();
  }
  
  public void add(int value) {
    if(value < 0) {
      nSet.add(Math.abs(value)) ;
      return;
    }
    pSet.add(value);
  }
  
  public boolean contains(int value) {
    if(value < 0) {
      return nSet.contains(Math.abs(value)) ;
    }
    return pSet.contains(value);
  }
  
  public boolean isEmpty() {
    return nSet.size() < 1 && pSet.size() < 1;
  }
  
  public int size() {
    return nSet.size() + pSet.size();
  }
  
  public void clear() {
    nSet.clear();
    pSet.clear();
  }
  
  public void write(FileChannel channel)  throws Exception {
    int size = nSet.size()*4;
    ByteBuffer buff = ByteBuffer.allocateDirect(size);
    
    int i = size-4;
    for(Integer code : nSet){
      if(i >= buff.capacity()) break;
      buff.putInt(i, -1*code);
      i -= 4;
    }

    buff.rewind();
    if(channel.isOpen()) channel.write(buff);
    buff.clear();
    
    size = pSet.size()*4;
    buff = ByteBuffer.allocateDirect(size);
    
    i = 0;
    for(Integer code : pSet){
      if(i >= buff.capacity()) break;
      buff.putInt(i, code);
      i += 4;
    }

    buff.rewind();
    if(channel.isOpen()) channel.write(buff);
    buff.clear();
  }
  
  public void addToList(List<Integer> list){
    for(Integer code : nSet){
      list.add(0, -1*code);
    }
    
    for(Integer code : pSet){
      list.add(code);
    }
  }
  
}
