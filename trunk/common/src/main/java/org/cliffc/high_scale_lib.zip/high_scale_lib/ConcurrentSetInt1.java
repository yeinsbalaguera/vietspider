/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.cliffc.high_scale_lib;

import org.vietspider.common.io.ConcurrentSetInt;
import org.vietspider.common.io.ConcurrentSetIntCacher;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jan 8, 2009  
 */
public class ConcurrentSetInt1 {
  
  private ConcurrentSetInt nguyen;
  private ConcurrentSetInt le;
  private int divide = 1000000;
  
  public ConcurrentSetInt1() {
    nguyen = new ConcurrentSetIntCacher();
    le = new ConcurrentSetIntCacher();
  }
  
  public void add(int value) {
    int a1  = value/divide;
    int a2  = value%divide;
    nguyen.add(a1);
    le.add(a2);
  }
}
