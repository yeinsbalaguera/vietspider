/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index.ram;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.FieldSelector;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Collector;
import org.apache.lucene.search.DocIdSet;
import org.apache.lucene.search.DocIdSetIterator;
import org.apache.lucene.search.Explanation;
import org.apache.lucene.search.FieldDoc;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Scorer;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.TopFieldCollector;
import org.apache.lucene.search.TopFieldDocs;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.search.Weight;
import org.apache.lucene.store.Directory;
import org.apache.lucene.util.ReaderUtil;
import org.vietspider.common.io.LogService;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Sep 19, 2009  
 */
public class RtIndexSearcher extends Searcher {
  
  private IndexReader reader;

  private boolean closeReader;
  private IndexReader[] subReaders;
  private int[] docStarts;

//  /** Creates a searcher searching the index in the named directory.
//   * @throws CorruptIndexException if the index is corrupt
//   * @throws IOException if there is a low-level IO error
//   * @deprecated Use {@link #IndexSearcher(Directory, boolean)} instead
//   */
//  public RtIndexSearcher(String path) throws CorruptIndexException, IOException {
//    this(IndexReader.open(path), true);
//  }
//
//  /** Creates a searcher searching the index in the named
//   *  directory.  You should pass readOnly=true, since it
//   *  gives much better concurrent performance, unless you
//   *  intend to do write operations (delete documents or
//   *  change norms) with the underlying IndexReader.
//   * @param path directory where IndexReader will be opened
//   * @param readOnly if true, the underlying IndexReader
//   * will be opened readOnly
//   * @throws CorruptIndexException if the index is corrupt
//   * @throws IOException if there is a low-level IO error
//   * @deprecated Use {@link #IndexSearcher(Directory, boolean)} instead
//   */
//  public RtIndexSearcher(String path, boolean readOnly) throws CorruptIndexException, IOException {
//    this(IndexReader.open(path, readOnly), true);
//  }

  /** Creates a searcher searching the index in the provided directory.
   * @throws CorruptIndexException if the index is corrupt
   * @throws IOException if there is a low-level IO error
   * @deprecated Use {@link #IndexSearcher(Directory, boolean)} instead
   */
  public RtIndexSearcher(Directory directory) throws CorruptIndexException, IOException {
    this(IndexReader.open(directory), true);
  }

  /** Creates a searcher searching the index in the named
   *  directory.  You should pass readOnly=true, since it
   *  gives much better concurrent performance, unless you
   *  intend to do write operations (delete documents or
   *  change norms) with the underlying IndexReader.
   * @throws CorruptIndexException if the index is corrupt
   * @throws IOException if there is a low-level IO error
   * @param path directory where IndexReader will be opened
   * @param readOnly if true, the underlying IndexReader
   * will be opened readOnly
   */
  public RtIndexSearcher(Directory path, boolean readOnly) throws CorruptIndexException, IOException {
    this(IndexReader.open(path, readOnly), true);
  }

  /** Creates a searcher searching the provided index. */
  public RtIndexSearcher(IndexReader r) {
    this(r, false);
  }
  
  private RtIndexSearcher(IndexReader r, boolean closeReader) {
    reader = r;
    this.closeReader = closeReader;

    List subReadersList = new ArrayList();
    gatherSubReaders(subReadersList, reader);
    subReaders = (IndexReader[]) subReadersList.toArray(new IndexReader[subReadersList.size()]);
    docStarts = new int[subReaders.length];
    int maxDoc = 0;
    for (int i = 0; i < subReaders.length; i++) {
      docStarts[i] = maxDoc;
      maxDoc += subReaders[i].maxDoc();
    }
  }

  protected void gatherSubReaders(List allSubReaders, IndexReader r) {
    ReaderUtil.gatherSubReaders(allSubReaders, r);
  }

  /** Return the {@link IndexReader} this searches. */
  public IndexReader getIndexReader() {
    return reader;
  }

  /**
   * Note that the underlying IndexReader is not closed, if
   * IndexSearcher was constructed with IndexSearcher(IndexReader r).
   * If the IndexReader was supplied implicitly by specifying a directory, then
   * the IndexReader gets closed.
   */
  public void close() throws IOException {
    if(subReaders != null) {
      for(int i = 0; i < subReaders.length; i++) {
        try {
          subReaders[i].close();
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }
      }
    }
    if(closeReader) reader.close();
  }

  // inherit javadoc
  public int docFreq(Term term) throws IOException {
    return reader.docFreq(term);
  }

  // inherit javadoc
  public Document doc(int i) throws CorruptIndexException, IOException {
    return getIndexReader().document(i);
  }
  
  // inherit javadoc
  public Document doc(int i, FieldSelector fieldSelector) throws CorruptIndexException, IOException {
      return reader.document(i, fieldSelector);
  }
  
  // inherit javadoc
  public int maxDoc() throws IOException {
    return reader.maxDoc();
  }

  // inherit javadoc
  public TopDocs search(Weight weight, Filter filter, final int nDocs) throws IOException {

    if (nDocs <= 0) {
      throw new IllegalArgumentException("nDocs must be > 0");
    }

    TopScoreDocCollector collector = TopScoreDocCollector.create(nDocs, !weight.scoresDocsOutOfOrder());
    search(weight, filter, collector);
    return collector.topDocs();
  }

  public TopFieldDocs search(Weight weight, Filter filter,
      final int nDocs, Sort sort) throws IOException {
    return search(weight, filter, nDocs, sort, true);
  }

  /**
   * Just like {@link #search(Weight, Filter, int, Sort)}, but you choose
   * whether or not the fields in the returned {@link FieldDoc} instances should
   * be set by specifying fillFields.<br>
   * <b>NOTE:</b> currently, this method tracks document scores and sets them in
   * the returned {@link FieldDoc}, however in 3.0 it will move to not track
   * document scores. If document scores tracking is still needed, you can use
   * {@link #search(Weight, Filter, Collector)} and pass in a
   * {@link TopFieldCollector} instance.
   */
  public TopFieldDocs search(Weight weight, Filter filter, final int nDocs,
                             Sort sort, boolean fillFields) throws IOException {
    throw new UnsupportedOperationException();
    
   /* SortField[] fields = sort.fields;
    boolean legacy = false;
    for(int i = 0; i < fields.length; i++) {
      SortField field = fields[i];
      String fieldname = field.getField();
      int type = field.getType();
      // Resolve AUTO into its true type
      if (type == SortField.AUTO) {
        int autotype = SortField.detectFieldType(reader, fieldname);
        if (autotype == SortField.STRING) {
          fields[i] = new SortField (fieldname, field.getLocale(), field.getReverse());
        } else {
          fields[i] = new SortField (fieldname, autotype, field.getReverse());
        }
      }

      if (field.getUseLegacySearch()) {
        legacy = true;
      }
    }
    
    if (legacy) {
      // Search the single top-level reader
      TopDocCollector collector = new TopFieldDocCollector(reader, sort, nDocs);
      HitCollectorWrapper hcw = new HitCollectorWrapper(collector);
      hcw.setNextReader(reader, 0);
      if (filter == null) {
        Scorer scorer = weight.scorer(reader, true, true);
        if (scorer != null) {
          scorer.score(hcw);
        }
      } else {
        searchWithFilter(reader, weight, filter, hcw);
      }
      return (TopFieldDocs) collector.topDocs();
    }
    
    TopFieldCollector collector = TopFieldCollector.create(sort, nDocs,
        fillFields, fieldSortDoTrackScores, fieldSortDoMaxScore, !weight.scoresDocsOutOfOrder());
    search(weight, filter, collector);
    return (TopFieldDocs) collector.topDocs();*/
  }

  public void search(Weight weight, Filter filter, Collector collector)
      throws IOException {
    
    if (filter == null) {
      for (int i = 0; i < subReaders.length; i++) { // search each subreader
        collector.setNextReader(subReaders[i], docStarts[i]);
        if(subReaders[i].getRefCount() < 1) continue;
        Scorer scorer = weight.scorer(subReaders[i], !collector.acceptsDocsOutOfOrder(), true);
        if (scorer != null) scorer.score(collector);
      }
    } else {
      for (int i = 0; i < subReaders.length; i++) { // search each subreader
        collector.setNextReader(subReaders[i], docStarts[i]);
        searchWithFilter(subReaders[i], weight, filter, collector);
      }
    }
  }

  private void searchWithFilter(IndexReader reader, Weight weight,
      final Filter filter, final Collector collector) throws IOException {

    assert filter != null;
    
    Scorer scorer = weight.scorer(reader, true, false);
    if (scorer == null) {
      return;
    }

    int docID = scorer.docID();
    assert docID == -1 || docID == DocIdSetIterator.NO_MORE_DOCS;

    // CHECKME: use ConjunctionScorer here?
    DocIdSet filterDocIdSet = filter.getDocIdSet(reader);
    if (filterDocIdSet == null) {
      // this means the filter does not accept any documents.
      return;
    }
    
    DocIdSetIterator filterIter = filterDocIdSet.iterator();
    if (filterIter == null) {
      // this means the filter does not accept any documents.
      return;
    }
    int filterDoc = filterIter.nextDoc();
    int scorerDoc = scorer.advance(filterDoc);
    
    collector.setScorer(scorer);
    while (true) {
      if (scorerDoc == filterDoc) {
        // Check if scorer has exhausted, only before collecting.
        if (scorerDoc == DocIdSetIterator.NO_MORE_DOCS) {
          break;
        }
        collector.collect(scorerDoc);
        filterDoc = filterIter.nextDoc();
        scorerDoc = scorer.advance(filterDoc);
      } else if (scorerDoc > filterDoc) {
        filterDoc = filterIter.advance(scorerDoc);
      } else {
        scorerDoc = scorer.advance(filterDoc);
      }
    }
  }

  public Query rewrite(Query original) throws IOException {
    Query query = original;
    for (Query rewrittenQuery = query.rewrite(reader); rewrittenQuery != query;
         rewrittenQuery = query.rewrite(reader)) {
      query = rewrittenQuery;
    }
    return query;
  }

  public Explanation explain(Weight weight, int doc) throws IOException {
    int n = ReaderUtil.subIndex(doc, docStarts);
    int deBasedDoc = doc - docStarts[n];
    
    return weight.explain(subReaders[n], deBasedDoc);
  }

  private boolean fieldSortDoTrackScores;
  private boolean fieldSortDoMaxScore;

  /** @deprecated */
  public void setDefaultFieldSortScoring(boolean doTrackScores, boolean doMaxScore) {
    fieldSortDoTrackScores = doTrackScores;
    fieldSortDoMaxScore = doMaxScore;
  }
  
  public void setReader(IndexReader reader) {
    this.reader = reader;
    
    List subReadersList = new ArrayList();
    gatherSubReaders(subReadersList, reader);
    subReaders = (IndexReader[]) subReadersList.toArray(new IndexReader[subReadersList.size()]);
    docStarts = new int[subReaders.length];
    int maxDoc = 0;
    for (int i = 0; i < subReaders.length; i++) {
      docStarts[i] = maxDoc;
      maxDoc += subReaders[i].maxDoc();
    }
  }
}
