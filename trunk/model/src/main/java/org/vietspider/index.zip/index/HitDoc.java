/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Comparator;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 9, 2009  
 */
public class HitDoc {
  
  final static public HitDocScoreComparator SCORE_COMPARATOR = new HitDocScoreComparator() ;
  final static public int DATA_LENGTH = 10 ;
  
  final static char SEPARATOR = '/' ;
  
  short dbId ;
  int docId ;
  float score ;
  
  public HitDoc() { } 
  
  public HitDoc(short dbId, int docId, float score) {
    this.dbId = dbId ;
    this.docId = docId ;
    this.score = score ;
  }
  
  public void init(int docId_, float score_) {
    this.docId = docId_ ;
    this.score = score_ ;
  }

  public int getDocId() { return docId ; }
  
  public float getScore() { return score ; }
  
  public short getDBId() { return this.dbId ; }

  @SuppressWarnings("unused")
  public void read(ByteBuffer buffer, String version)  {
    this.dbId = buffer.getShort() ;
    this.docId = buffer.getInt() ;
    this.score = buffer.getFloat() ;
  }

  public void write(ByteBuffer buffer)  {
    buffer.putShort(dbId) ;
    buffer.putInt(docId)  ;
    buffer.putFloat(score) ;
  }

  static public byte[]  toByte(HitDoc[] hdoc) throws Exception {
    int len = 4 + (HitDoc.DATA_LENGTH * hdoc.length) ;
    ByteBuffer buffer = createByteBuffer(len) ;
    buffer.putInt(hdoc.length) ;
    for(int i = 0; i < hdoc.length; i++) {
      hdoc[i].write(buffer) ;
    }
    return buffer.array() ;
  }
  
  static public HitDoc[] fromByte(byte[] buf) throws Exception {
    ByteBuffer buffer = createByteBuffer(buf) ;
    int len = buffer.getInt() ;
    HitDoc[] hdoc = new HitDoc[len] ;
    for(int i = 0; i < len; i++) {
      hdoc[i] = new HitDoc() ;
      hdoc[i].read(buffer, "3.0") ;
    }
    return hdoc ;
  }
  
  static public class HitDocScoreComparator implements Comparator<HitDoc> {
    public int compare(HitDoc hd1, HitDoc hd2) {
      if(hd1.score < hd2.score) return -1 ;
      else if(hd1.score > hd2.score) return 1 ;
      else return 0;
    }
  }
  
  static public  ByteBuffer createByteBuffer(byte[] buf) {
    ByteBuffer result = ByteBuffer.allocate(buf.length);
    result.order(ByteOrder.nativeOrder());
    result.put(buf) ;
    result.position(0) ;
    return result;
  }
  
  static public  ByteBuffer createByteBuffer(int size) {
    ByteBuffer result = ByteBuffer.allocate(size);
    result.order(ByteOrder.nativeOrder());
    return result;
  }
}