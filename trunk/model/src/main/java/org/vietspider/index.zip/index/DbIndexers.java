/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index;

import org.vietspider.common.Application;
import org.vietspider.common.io.UtilFile;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Apr 28, 2008  
 */
public class DbIndexers extends CoreDbIndexers implements Runnable {

  private static volatile DbIndexers INSTANCE;

  public  synchronized  static DbIndexers getInstance() {
    if(INSTANCE == null) {
      INSTANCE  = new DbIndexers();
    }
    return INSTANCE;    
  }

  private volatile boolean execute = true;
  protected MergeIndexFile mergeIndex;

  private DbIndexers() {
    super(false);
    Application.addShutdown(new Application.IShutdown() {

      public String getMessage() { return "Close DbIndexers"; }

      public int getPriority() { return 2; }

      public void execute() { 
        execute = false;
        
        commitIndexedContents();
        closeIndexers();
        
        UtilFile.deleteFolder(UtilFile.getFolder("content/search"));
      }
    });

    new Thread(this).start();
  }

  public void run() {
    mergeIndex = new MergeIndexFile();
    
    while(execute) {
      commitIndexedContents();
      closeExpires();
      
      if(mergeIndex.isMerge())  mergeIndex.merge();
      try {
        Thread.sleep(15*1000);
      } catch (Exception e) {
      }
    }
    
    commitIndexedContents();
  }
  

}
