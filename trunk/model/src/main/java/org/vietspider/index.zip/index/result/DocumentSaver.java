/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index.result;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import org.apache.lucene.document.Document;
import org.vietspider.common.io.LogService;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 27, 2009  
 */
public class DocumentSaver {
  
  private File folder;
  
  public DocumentSaver(File folder) {
    this.folder = folder;
  }
  
  public void saveDocument(Document document) {
    ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
    try {
      ObjectOutputStream out = new ObjectOutputStream(byteOutputStream);
      out.writeObject(document);
      out.flush();
      out.close();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      return;
    } finally {
      try {
        if(byteOutputStream != null) byteOutputStream.close();
      } catch (Exception e) {
      }
    }
    
    int score  = (int)(document.getBoost()*1000000);
    String name  = document.getField("id").stringValue() + "."+ String.valueOf(score);
    File file  = new File(folder, name);
    try {
      if(!file.exists()) file.createNewFile();
    } catch (Exception e) {
      LogService.getInstance().setMessage(null, file.getAbsolutePath()+": "+ e.toString());
      return;
    }
    
    FileOutputStream outStream = null;
    FileChannel channel = null;
    try {
      outStream = new FileOutputStream(file);
      channel = outStream.getChannel();
      byte [] bytes = byteOutputStream.toByteArray();
      ByteBuffer buff = ByteBuffer.allocateDirect(bytes.length);
      buff.put(bytes);
      buff.rewind();
      if(channel.isOpen()) channel.write(buff);
      buff.clear();
      channel.close();
    } catch (Exception e) {
      LogService.getInstance().setMessage(null, file.getAbsolutePath()+": "+ e.toString());
    } finally {
      try {
        if(channel != null) channel.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
      
      try {
        if(outStream != null) outStream.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
  }
}
