/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Apr 28, 2008  
 */
public interface DbIndexer {
  
  public void index(IIndexEntry entry) ;
  
  public void optimize() ;
  public void commit() ;
  
  public  void close() ;
  public boolean  isClose();

 
  public long getLastAccess() ;
  public boolean isExpire() ;

}
