/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.Calendar;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.vietspider.common.io.FileNameComparator;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Oct 12, 2009  
 */
public class MergeIndexFile {

  public MergeIndexFile() {
    File folder = UtilFile.getFolder("content/temp/indexed");
    File [] files  = folder.listFiles();
    if(files == null || files.length < 1) merge();
  }

  public boolean isMerge() {
    File folder = UtilFile.getFolder("content/temp/indexed");
    Calendar current = Calendar.getInstance();
    if(current.get(Calendar.HOUR_OF_DAY) > 3)  return false;
    Calendar last = Calendar.getInstance();
    last.setTimeInMillis(folder.lastModified());
    if(current.get(Calendar.DAY_OF_MONTH) == last.get(Calendar.DAY_OF_MONTH)) return false;
    UtilFile.deleteFolder(folder, false);
    return true;
  }

  public void merge() {
    File folder = UtilFile.getFolder("content/cindexed");
    File [] files = UtilFile.listFiles(folder, new FileFilter() {
      public boolean accept(File f) {
        if (!f.isDirectory()) return false;
        return UtilFile.validate(f.getName());
      }
    }, new FileNameComparator());

    /*TpDatabases tpDatabases = TpDatabases.getInstance();
    CoreDbIndexers dbIndexers = null;
    if(tpDatabases != null) {
      dbIndexers = tpDatabases.getDbIndexers();
    } else {
      dbIndexers = DbIndexers.getInstance();
    }*/

    File output = UtilFile.getFolder("content/temp/indexed");
    WhitespaceAnalyzer analyzer = new WhitespaceAnalyzer();
    IndexWriter indexWriter = createIndexModifier(output, analyzer, true);
    LogService.getInstance().setMessage(null, "Start merge index file...");
    for(int i = 3; i < files.length; i++) {
      LogService.getInstance().setMessage(null, "Merge index file "+ files[i].getName()+"...");
      try {
        Directory directory  = FSDirectory.open(files[i]);
        IndexReader indexToMerge = IndexReader.open(directory, true);
        indexWriter.addIndexes(new IndexReader[] {indexToMerge});
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    LogService.getInstance().setMessage(null, "Finish merge index file...");
    /* try {
      indexWriter.optimize();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }*/
    try {
      indexWriter.close();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }

  protected IndexWriter createIndexModifier (File file, Analyzer analyzer, boolean recursive) {
    //  File file = new File(folder, dateFolder+"/");
    if(!file.exists()) {
      file.mkdir();
    } else if(file.isFile()) {
      file.delete();
      file.mkdir();
    }

    MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
    if(file.exists() && file.listFiles().length > 0) {
      try {
        Directory directory  = FSDirectory.open(file);
        return new IndexWriter(directory, analyzer, false, mfl);
      } catch (IOException e) {
        try {
          Directory directory  = FSDirectory.open(file);
          if(IndexWriter.isLocked(directory)) IndexWriter.unlock(directory) ;
          if(recursive) return createIndexModifier(file, analyzer, false); 
        } catch (Exception e2) {
          LogService.getInstance().setThrowable(e);
        }
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
        return null;
      }   
    } 

    try {
      if(!file.exists()) file.createNewFile();
      Directory directory  = FSDirectory.open(file);
      return new IndexWriter(directory, analyzer, true, mfl);
    } catch (IOException e) {
      try {
        Directory directory  = FSDirectory.open(file);
        if(IndexWriter.isLocked(directory)) IndexWriter.unlock(directory) ;
        if(recursive) return createIndexModifier(file, analyzer, false); 
      } catch (Exception e2) {
        LogService.getInstance().setThrowable(e);
      }
      return null;
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      return null;
    }
  }

  /* public static void main(String[] args) throws Exception {
    File file = new File("D:\\java\\headvances3\\trunk\\vietspider\\startup\\src\\test\\data\\");
    System.setProperty("vietspider.data.path", file.getCanonicalPath());
    MergeIndexFile mergeIndexFile = new MergeIndexFile();
    mergeIndexFile.merge();
  }
   */
}
