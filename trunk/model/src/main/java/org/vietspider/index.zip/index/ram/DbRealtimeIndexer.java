/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index.ram;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.ConcurrentMergeScheduler;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.vietspider.common.io.LogService;
import org.vietspider.index.DbIndexer;
import org.vietspider.index.IIndexEntry;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Sep 12, 2009  
 */
public class DbRealtimeIndexer implements DbIndexer  {

  private final static long MAX_RAM_INDEX = 50*1024*1024l;

  private File indexFolder;
  private Analyzer analyzer;

  private RealtimeIndex rt;
  private volatile boolean isOptimize = false;

  private volatile long lastAccess;
  private volatile long lastOpenSearch  = -1;

  private IndexSearcher searcher;
  private volatile int counter = 0;

  public DbRealtimeIndexer(File file, Analyzer analyzer) throws Exception {
    //    System.out.println(" tao moi 0 "+ this+  " \n / "+ indexFolder.getAbsolutePath());
    this.indexFolder = file;
    this.analyzer = analyzer;
    rt = createIndexModifier(indexFolder, true);
  }

  public DbRealtimeIndexer(File folder, String date, Analyzer analyzer) throws Exception {
    this.indexFolder = new File(folder, date+"/");
    this.analyzer = analyzer;
    rt = createIndexModifier(indexFolder, true);
  }

  public synchronized void index(IIndexEntry entry) {
    if(rt == null || entry == null) return;
    lastAccess = System.currentTimeMillis();
    counter++;

    if(counter >= 5000) {
      try {
        rt.close();
        rt = createIndexModifier(indexFolder, true);
        LogService.getInstance().setMessage(null, indexFolder.getAbsolutePath());
        LogService.getInstance().setMessage(null, "Reopen index searcher! "+ counter+ "/"+ rt.hashCode());
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
      counter = 0;
    }

    //    System.out.println(" danh index trong realtime "+ entry.getId());
    if(entry.getStatus() == IIndexEntry.DELETE) {
      try {
        //        Document doc1 = searcher.doc(searcher.docFreqs(new Term[]{new Term(IIndexEntry.FIELD_ID, entry.getId())})[0]);
        //        System.out.println(" prepare delete document "+ entry.getId());
        rt.deleteDocuments(new Term[]{new Term(IIndexEntry.FIELD_ID, entry.getId())});
        //        Document doc2 = searcher.doc(searcher.docFreqs(new Term[]{new Term(IIndexEntry.FIELD_ID, entry.getId())})[0]);
        //        System.out.println(" thay co "+ doc1+ " / "+ doc2);
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }  
      return;
    } 

    try {
      Document document = entry.toDocument();
      if(document != null) rt.addDocument(document, analyzer);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }

  public synchronized IndexSearcher getSearcher() {
    if(rt == null) return null;

    if(counter%100 == 0 
        || System.currentTimeMillis() - lastOpenSearch > 15*60*1000l) {
      try {
        if(searcher != null) searcher.close();
        searcher = null;
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    if(searcher == null) {
      try {
        searcher = new IndexSearcher(rt.getReader());
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
      lastOpenSearch = System.currentTimeMillis();
    }
    return searcher;
  }

  public void commit() {
    if(rt == null) return;
    if(isOptimize) return;
    lastAccess = System.currentTimeMillis();
    try {
      rt.flush(false, true);
    } catch (Exception exp) {
      LogService.getInstance().setThrowable(exp);
      optimize();
      try {
        rt.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }

      try {
        rt = createIndexModifier(indexFolder, true);        
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
  }

  public void optimize() {
    if(rt == null) return;
    isOptimize = true;
    lastAccess = System.currentTimeMillis();
    try {
      rt.getDiskWriter().optimize();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
    isOptimize = false;
  }

  public  void close() {
    if(rt == null) return;
    try {
      if(searcher != null) searcher.close();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }

    try {
      rt.close();
      rt = null;
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      //      LogService.getInstance().setMessage(e, e.toString());
    }
  }

  public boolean isClose() {
    if(rt == null) return true;
    return false;
  }

  protected RealtimeIndex createIndexModifier (File file, boolean recursive) {
    if(!file.exists()) {
      file.mkdir();
    } else if(file.isFile()) {
      file.delete();
      file.mkdir();
    }

    if(file.exists() && file.listFiles().length > 0) {
      try {
        //        BigDirectory directory = new BigDirectory(file);
        Directory directory  = FSDirectory.open(file);
        ConcurrentMergeScheduler ramMergeScheduler = new ConcurrentMergeScheduler();
        ramMergeScheduler.setMaxThreadCount(2);
        IndexWriter diskWriter = new IndexWriter(directory, analyzer, MaxFieldLength.UNLIMITED);
        diskWriter.setUseCompoundFile(true);
        diskWriter.setMaxBufferedDocs(1000);
        diskWriter.setRAMBufferSizeMB(128);
        return new RealtimeIndex(diskWriter, MAX_RAM_INDEX, ramMergeScheduler);
      } catch (IOException e) {
        try {
          Directory directory  = FSDirectory.open(file);
          if(IndexWriter.isLocked(directory)) IndexWriter.unlock(directory) ;
          if(recursive) return createIndexModifier(file, false); 
        } catch (Exception e2) {
          LogService.getInstance().setThrowable(e);
        }
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
        return null;
      }   
    } 

    try {
      if(!file.exists()) file.createNewFile();
      Directory directory  = FSDirectory.open(file);
      ConcurrentMergeScheduler ramMergeScheduler = new ConcurrentMergeScheduler();
      ramMergeScheduler.setMaxThreadCount(2);
      IndexWriter diskWriter = new IndexWriter(directory, analyzer, MaxFieldLength.UNLIMITED);
      diskWriter.setUseCompoundFile(true);
      diskWriter.setMaxBufferedDocs(1000);
      diskWriter.setRAMBufferSizeMB(128);
      return new RealtimeIndex(diskWriter, MAX_RAM_INDEX, ramMergeScheduler);
    } catch (IOException e) {
      try {
        Directory directory  = FSDirectory.open(file);
        if(IndexWriter.isLocked(directory)) IndexWriter.unlock(directory) ;
        if(recursive) return createIndexModifier(file, false); 
      } catch (Exception e2) {
        LogService.getInstance().setThrowable(e);
      }
      return null;
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      return null;
    }
  }

  public long getLastAccess() { return lastAccess; }

  public boolean isExpire() { 
    return System.currentTimeMillis() - lastAccess > 15*60*1000l; 
  }

}
