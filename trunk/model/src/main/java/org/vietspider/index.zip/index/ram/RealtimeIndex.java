package org.vietspider.index.ram;

import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.MergeScheduler;
import org.apache.lucene.index.MultiReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.Directory;

/**
 * Realtime index gives a rough analogy to the IndexWriter APIs. A single RAM
 * Merge Scheduler is used across instantiations of RAM IndexWriter's to insure
 * too many threads are not being used.
 * 
 */
public class RealtimeIndex {

  private IndexWriter diskWriter;

  private RAMIndex ramIndex;

//  private Analyzer defaultAnalyzer;

//  boolean isClosed = false;

//  MergeScheduler ramMergeScheduler;

//  private List exceptions = new ArrayList();

//  FlushToDiskThread flushToDiskThread = new FlushToDiskThread();

//  private int docsFlushed = 0;

  /**
   * 
   * @param diskWriter
   * @param maxRamSize
   * @param ramMergeScheduler Merge scheduler used for all ram based index
   *        writers
   */
  public RealtimeIndex(IndexWriter diskWriter, long maxRamSize, MergeScheduler ramMergeScheduler) {
    this.diskWriter = diskWriter;
//    this.maxRamSize = maxRamSize;
//    this.ramMergeScheduler = ramMergeScheduler;
//    this.defaultAnalyzer = diskWriter.getAnalyzer();
    ramIndex = new RAMIndex(this.diskWriter, maxRamSize, ramMergeScheduler);
  }
  
  public IndexWriter getDiskWriter() { return diskWriter; }

  private void ensureOpen() throws IOException {
    ramIndex.ensureOpen();
//    if (isClosed)
//      throw new IOException("index is closed");
  }

  public void updateDocument(Term term, Document document, Analyzer analyzer) throws CorruptIndexException, IOException {
    ensureOpen();
    ramIndex.updateDocument(term, document, analyzer);
    diskWriter.deleteDocuments(term);
  }

  public void updateDocument(Term term, Document document) throws CorruptIndexException, IOException {
    ensureOpen();
    ramIndex.updateDocument(term, document, diskWriter.getAnalyzer());
    diskWriter.deleteDocuments(term);
  }

  public void addDocument(Document document, Analyzer analyzer) throws CorruptIndexException, IOException {
    ensureOpen();
    ramIndex.addDocument(document, analyzer);
  }

  /**
   * Seems like there are concurrency issues here?
   * 
   * @param terms
   * @throws CorruptIndexException
   * @throws IOException
   */
  public void deleteDocuments(Term[] terms) throws CorruptIndexException, IOException {
    ensureOpen();
    ramIndex.deleteDocuments(terms);
    diskWriter.deleteDocuments(terms);
  }
  
  public void expungeDeletes() throws CorruptIndexException, IOException{
    diskWriter.expungeDeletes();
  }

  public static long size(Directory directory) throws IOException {
    String[] files = directory.listAll();
    long total = 0;
    for (int x = 0; x < files.length; x++) {
      total += directory.fileLength(files[x]);
    }
    return total;
  }

  public void deleteDocuments(Query[] queries) throws CorruptIndexException, IOException {
    ensureOpen();
    ramIndex.deleteDocuments(queries);
    diskWriter.deleteDocuments(queries);
  }

  /**
   * 
   * @param force If true then the size of the ram directory is ignored
   * @throws CorruptIndexException
   * @throws IOException
   */
  public synchronized void flush(boolean force, boolean doWait)
      throws CorruptIndexException, IOException {
    ensureOpen();
    ramIndex.flush(force, doWait);
  }

  /**
   * The reader returned needs to be closed otherwise references will be left
   * open.
   */
  public synchronized IndexReader getReader() throws Exception {
    ensureOpen();
    IndexReader diskReader = diskWriter.getReader();
    IndexReader ramReader = ramIndex.getReader();
    //System.out.println("diskReader.maxDoc:"+diskReader.maxDoc()+" ramReader.maxDoc:"+ramReader.maxDoc());
    return toReader(ramReader, diskReader);
  }

  /**
   * Represents the ram realtime index
   */
 /* public class RAMIndex {
    IndexWriter currentWriter;

    List writersToDisk = new ArrayList();

    List deleteQueries = new ArrayList();

    List _deleteTerms = new ArrayList();

    public RAMIndex() {
    }

    private IndexWriter takeNextToDiskWriter() {
      synchronized (writersToDisk) {
        if (writersToDisk.size() == 0) return null;
        IndexWriter toDiskIW = (IndexWriter) writersToDisk.get(0);
        writersToDisk.remove(0);
        return toDiskIW;
      }
    }

    public synchronized IndexReader[] getReaders() throws IOException {
      List readers = new ArrayList();
      if (currentWriter != null) {
        readers.add(currentWriter.getReader());
      }
      for (int x = 0; x < writersToDisk.size(); x++) {
        IndexWriter iw = (IndexWriter) writersToDisk.get(x);
        readers.add(iw.getReader());
      }
      return (IndexReader[]) readers.toArray(new IndexReader[0]);
    }

    private void doFlush() throws IOException {
      IndexWriter iw = takeNextToDiskWriter();
      if(iw != null) {
        iw.commit();
        diskWriter.addIndexesNoOptimize(new Directory[] { iw.getDirectory() });
      }
      diskWriter.commit();
    }

    public synchronized void flush(boolean force, boolean doWait) throws IOException {
      boolean doFlush = false;
      applyDeletes();
      if (currentWriter != null && doWait) {
        writersToDisk.add(currentWriter);
        currentWriter = null;
        doFlush();
      } else {
        if (currentWriter != null) {
          if (maxRamSize > currentWriter.ramSizeInBytes()) {
            doFlush = true;
          }
        }
        synchronized (writersToDisk) {
          if (force || doFlush) {
            writersToDisk.add(currentWriter);
            flushToDiskThread.newOne();
            currentWriter = null;
          }
        }
      }
    }
    
    private int count(Term term, IndexReader r) throws IOException {
      int count = 0;
      TermDocs td = r.termDocs(term);
      while (td.next()) {
        count++;
      }
      return count;
    }
    
    private synchronized void applyDeletes() throws IOException {
      if(deleteQueries.size() > 0) {
        Query[] queries = (Query[]) deleteQueries.toArray(new Query[0]);
        for (int i = 0; i < writersToDisk.size(); i++) {
          IndexWriter iw = (IndexWriter) writersToDisk.get(i);
          if(iw != null) iw.deleteDocuments(queries);
        }
        if (currentWriter != null) currentWriter.deleteDocuments(queries);
        deleteQueries.clear();
      }
      
      if(_deleteTerms.size() > 0) {
        System.out.println(" thay co "+ writersToDisk.size()+ " ====  >"+ currentWriter);
        Term[] terms = (Term[]) _deleteTerms.toArray(new Term[_deleteTerms.size()]);
        for (int i = 0; i < writersToDisk.size(); i++) {
          IndexWriter iw = (IndexWriter) writersToDisk.get(i);
          if(iw != null)  iw.deleteDocuments(terms);
        }
        if (currentWriter != null) {      
          currentWriter.deleteDocuments(terms);
        }
        IndexWriter iw = getCurrentWriter();
        iw.deleteDocuments(terms);
        _deleteTerms.clear();
      }
    }

    public void flush(boolean doWait) throws IOException {
      flush(true, doWait);
    }

    public void addDocument(Document document, Analyzer analyzer) throws CorruptIndexException, IOException {
      IndexWriter iw = getCurrentWriter();
      iw.addDocument(document, analyzer);
    }

    public void deleteDocuments(Term[] terms) throws CorruptIndexException, IOException {
      for (int x = 0; x < terms.length; x++) {
        _deleteTerms.add(terms[x]);
      }
    }

    public void deleteDocuments(Query[] queries) throws CorruptIndexException, IOException {
      for (int x = 0; x < queries.length; x++) {
        deleteQueries.add(queries[x]);
      }
    }

    public void updateDocument(Term term, Document document, Analyzer analyzer) throws IOException {
      _deleteTerms.add(term);
      addDocument(document, analyzer);
    }

    public synchronized IndexWriter getCurrentWriter() throws CorruptIndexException, IOException {
      if (currentWriter == null) {
        currentWriter = new IndexWriter(new RAMDirectory(), defaultAnalyzer, true, MaxFieldLength.UNLIMITED);
        currentWriter.setMergeScheduler(ramMergeScheduler);
      }
      return currentWriter;
    }

    public long sizeInBytes() {
      if (currentWriter != null) 
        return ((RAMDirectory) currentWriter.getDirectory()).sizeInBytes();
      return 0;
    }

    public synchronized IndexReader getReader() throws IOException {
      applyDeletes();
      IndexReader[] readers = getReaders();
      if (readers == null) return null;
      if (readers.length == 1) return readers[0];
      return new MultiReader(readers);
    }
  }*/

  /**
   * Single thread used to flush the RAM index to disk.
   */

  private static IndexReader toReader(IndexReader r1, IndexReader r2) {
    if (r1 == null && r2 == null)
      return null;
    if (r1 != null && r2 == null)
      return r1;
    if (r1 == null && r2 != null)
      return r2;
    return new MultiReader(new IndexReader[] { r1, r2 });
  }

  /**
   * Flushed the ram dir to the disk writer and closes it.
   * 
   * @throws IOException
   */
  public synchronized void close() throws IOException {
    ensureOpen();
    flush(true, true);
    ramIndex.close();
    diskWriter.close();
  }
}
