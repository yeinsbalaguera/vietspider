/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.vietspider.common.io.LogService;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Apr 28, 2008  
 */
public class DbFileIndexer implements DbIndexer  {
  
//  private String dateFolder;
  private File indexFolder;
  private Analyzer analyzer;

  private IndexWriter writer;
  private volatile boolean isOptimize = false;
  
  private volatile long lastAccess;
  
  public DbFileIndexer(File file, Analyzer analyzer) {
    this.indexFolder = file;
    this.analyzer = analyzer;
    writer = createIndexModifier(indexFolder, true);
  }
  
  public DbFileIndexer(File folder, String date, Analyzer analyzer) {
    indexFolder = new File(folder, date+"/");
//    this.folder = folder;
//    this.dateFolder = date;
    this.analyzer = analyzer;
    writer = createIndexModifier(indexFolder, true);
  }

  public void index(IIndexEntry entry) {
    if(writer == null || entry == null) return;
    lastAccess = System.currentTimeMillis();
    
    if(entry.getStatus() == IIndexEntry.DELETE) {
      try {
//        System.out.println(" prepare delete document "+ entry.getId());
        writer.deleteDocuments(new Term(IIndexEntry.FIELD_ID, entry.getId()));
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }  
      return;
    } 
    
    try {
      Document document = entry.toDocument();
      if(document != null) writer.addDocument(document);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }
  
  public void optimize() {
    if(writer == null) return;
    isOptimize = true;
    lastAccess = System.currentTimeMillis();
    try {
      writer.optimize();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
    isOptimize = false;
  }
  
  public void commit() {
    if(writer == null) return;
    if(isOptimize) return;
    lastAccess = System.currentTimeMillis();
    try {
      writer.commit();
//    } catch (FileNotFoundException e) {
//      LogService.getInstance().setMessage(e, e.toString());
//      optimize();
    } catch (Exception exp) {
      LogService.getInstance().setThrowable(exp);
      optimize();
      try {
        writer.close();
        writer = createIndexModifier(indexFolder, true);
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
  }
  
  public  void close() {
    if(writer == null) return;
    try {
      writer.close();
      writer = null;
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
//      LogService.getInstance().setMessage(e, e.toString());
    }
  }
  
  public boolean  isClose() {
    if(writer == null) return true;
    return false;
  }

  protected IndexWriter createIndexModifier (File file, boolean recursive) {
//    File file = new File(folder, dateFolder+"/");
    if(!file.exists()) {
      file.mkdir();
    } else if(file.isFile()) {
      file.delete();
      file.mkdir();
    }

    MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
    if(file.exists() && file.listFiles().length > 0) {
      try {
        Directory directory  = FSDirectory.open(file);
        return new IndexWriter(directory, analyzer, false, mfl);
      } catch (IOException e) {
        try {
          Directory directory  = FSDirectory.open(file);
          if(IndexWriter.isLocked(directory)) IndexWriter.unlock(directory) ;
          if(recursive) return createIndexModifier(file, false); 
        } catch (Exception e2) {
          LogService.getInstance().setThrowable(e);
        }
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
        return null;
      }   
    } 

    try {
      if(!file.exists()) file.createNewFile();
      Directory directory  = FSDirectory.open(file);
      return new IndexWriter(directory, analyzer, true, mfl);
    } catch (IOException e) {
      try {
        Directory directory  = FSDirectory.open(file);
        if(IndexWriter.isLocked(directory)) IndexWriter.unlock(directory) ;
        if(recursive) return createIndexModifier(file, false); 
      } catch (Exception e2) {
        LogService.getInstance().setThrowable(e);
      }
      return null;
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      return null;
    }
  }
  
  public long getLastAccess() { return lastAccess; }
  
  public boolean isExpire() { 
    return System.currentTimeMillis() - lastAccess > 15*60*1000l; 
  }

}
