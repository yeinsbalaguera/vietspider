/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.TopDocs;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 4, 2008  
 */
public class DbSearcher {
  
  private CoreDbIndexers dbIndexers;
  
  private File[] indexFiles;
  private String indexFolder;
  
  public DbSearcher(CoreDbIndexers indexers, String _indexFolder) {
    this.dbIndexers = indexers;
    this.indexFolder = _indexFolder;
  }
  
  public List<Document> search(Query query, int max) throws Exception {
    indexFiles = IndexSearchers.getInstance().getFiles(indexFolder);
    
    List<Document> documents = new ArrayList<Document>();
    if(indexFiles.length < 1) return documents;
    
    Map<String, Document> temp = new Hashtable<String, Document>();
    int size = max/indexFiles.length;
    for (int i = 0; i < indexFiles.length; i++) {
      search(indexFiles[i], query, temp, size);
      if(temp.size() >= max) break;
    }
    
    Iterator<Map.Entry<String,Document>> iterator = temp.entrySet().iterator();
    while(iterator.hasNext()) {
      Map.Entry<String,Document> entry = iterator.next();
      documents.add(entry.getValue());
    }
    
    return documents;
  }
  
  public void search(File file, Query query, Map<String, Document> documents, int max) throws Exception {
    Searcher indexSearcher = IndexSearchers.getInstance().getSearcher(dbIndexers, file, false);
//    RAMDirectory ramDir = null;
//    IndexReader reader = null;
//    IndexSearcher indexSearcher = null;
    
//    try {
//      ramDir = new RAMDirectory(file);
//      reader = IndexReader.open(ramDir);
//      indexSearcher = new IndexSearcher(reader);
    
    TopDocs topDocs = indexSearcher.search(query, null, max);
    ScoreDoc [] docs = topDocs.scoreDocs;
      
//      HitDocCollector collector = new HitDocCollector(max) ;
//      indexSearcher.search(query, null, collector) ;
//      HitDoc[] hitDocs = collector.getHitDoc();
    int maxDoc = Math.min(docs.length, max);
      
      for(int i = 0; i < maxDoc; i++) {
        int docId = docs[i].doc;
        Document doc = indexSearcher.doc(docId);
        if(doc == null) continue;
        Field field = doc.getField(IIndexEntry.FIELD_ID);
        if(field == null) continue;
        String id = field.stringValue();
        if(documents.containsKey(id)) continue;
        documents.put(id, doc);
      }
      
    /*}  finally {
      try {
        if(indexSearcher != null) indexSearcher.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }

      try {
        if(reader != null) reader.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }

      try {
        if(ramDir != null) ramDir.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }*/
  }

}
