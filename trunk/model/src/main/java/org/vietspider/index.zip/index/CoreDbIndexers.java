/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index;

import java.io.File;
import java.io.FileFilter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.search.IndexSearcher;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;
import org.vietspider.index.ram.DbRealtimeIndexer;
import org.vietspider.index.ram.RealtimeIndex;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Sep 11, 2009  
 */
public class CoreDbIndexers {

  private Map<String, DbIndexer> holder = new ConcurrentHashMap<String, DbIndexer>();
  protected volatile java.util.Queue<IIndexEntry> waitData = new ConcurrentLinkedQueue<IIndexEntry>();
  protected volatile int currentDate;
  protected volatile String currentDateName;

  protected volatile java.util.Queue<Delete> deletes = new ConcurrentLinkedQueue<Delete>();
  
  protected boolean sync = false;
  
  public CoreDbIndexers(boolean sync) {
    this.sync = sync;
  }

  public void index(IIndexEntry entry) {
    if(entry == null) return;
    waitData.add(entry); 
  }
  
  public boolean isSync() { return sync; }

  public synchronized void commitIndexedContents()  {
    if(waitData.isEmpty()) return;

    List<DbIndexer> indexers = new ArrayList<DbIndexer>();
    //    HashMap<File, Integer> expires = new HashMap<File, Integer>();

    Iterator<IIndexEntry> iterator = waitData.iterator();
    while(iterator.hasNext()) {
      IIndexEntry entry = iterator.next();

      //      System.out.println(" prepare index "+ entry);

      File folder = entry.getFolder();
      String dateValue = entry.getDate();
      Analyzer analyzer = entry.getAnalyzer();
      
//      System.out.println(" thay co cai analyzer "+ analyzer);
      
      iterator.remove();

      if(folder == null 
          || dateValue == null) continue;

      String dateFolder = null;
      try {
        Date date = CalendarUtils.getDateFormat().parse(dateValue);
        dateFolder = CalendarUtils.getFolderFormat().format(date);
      } catch (Throwable e) {
        LogService.getInstance().setThrowable("INDEXER", e);
        continue;
      }
      if(dateFolder == null) continue;

      //      System.out.println("on "+ dateFolder);

      DbIndexer indexer = getDbIndexer(folder, dateFolder, analyzer);
      if(indexer == null) continue;

      indexers.add(indexer);

      indexer.index(entry);

      //      expires.put(entry.getFolder(), entry.getExpireDate());
    }

    for(int i = 0; i < indexers.size(); i++) {
      indexers.get(i).commit();
    }

    //    Iterator<Entry<File,Integer>> expireIterator = expires.entrySet().iterator();
    //    while(expireIterator.hasNext()) {
    //      Entry<File,Integer> entry = expireIterator.next();
    //      File folder = entry.getKey();
    //      Integer expire = entry.getValue();
    //      deleteExpireDate(folder, expire);
    //    }

    //    if(CrawlCon > 0) deleteExpireDate(folder, expire);

    commitIndexedContents();
  }

  public void closeExpires() {
    while(!deletes.isEmpty()) {
      deleteExpireDate1(deletes.poll());
    }

    Iterator<Map.Entry<String, DbIndexer>> iterator = holder.entrySet().iterator();

    while(iterator.hasNext()) {
      Map.Entry<String, DbIndexer>  entry = iterator.next();
      DbIndexer indexer = entry.getValue();
      if(indexer instanceof RealtimeIndex) continue;
      if(indexer.isClose()) {
        iterator.remove();
        continue;
      }
      if(!indexer.isExpire()) continue;
      //      System.out.println(" chuan bi close data " + holder.size());
      //      System.out.println("close  =====> "+ indexer);
      indexer.close();
      iterator.remove();
      //      System.out.println(" ket thuc close data " + holder.size());
    }
  }

  public void closeIndexers() {
    Iterator<String> iterator = holder.keySet().iterator();

    while(iterator.hasNext()) {
      String key = iterator.next();
      DbIndexer indexer = holder.get(key);
      indexer.close();
      iterator.remove();
    }
  }

  private synchronized DbIndexer getDbIndexer(File folder, String dateFolder, Analyzer analyzer) {
    closeRealtimeIndexer();

    String key = new File(folder, dateFolder+"/").getAbsolutePath();
    //    System.out.println(" chuan bi tao db "+ key);
    DbIndexer tracker = holder.get(key);
    if(tracker != null && !tracker.isClose()) return tracker;

    try {
      if(dateFolder.equalsIgnoreCase(currentDateName)) {
        //        System.out.println(" tao data " + folder.getName()+ "  / "+ dateFolder + " / " + currentDateName);
        tracker = new DbRealtimeIndexer(folder, dateFolder, analyzer);
      } else {
        tracker = new DbFileIndexer(folder, dateFolder, analyzer);
      }
    } catch (Exception e) {
      LogService.getInstance().setThrowable(dateFolder, e);
    }
    if(tracker != null) holder.put(key, tracker);
    return tracker;
  }

  public synchronized DbIndexer getDbIndexer(File file, Analyzer analyzer) {
    closeRealtimeIndexer();

    //    System.out.println(" chuan bi tao db "+ key);
    DbIndexer tracker = holder.get(file);
    if(tracker != null && !tracker.isClose()) return tracker;

    try {
      tracker = new DbFileIndexer(file, analyzer);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(file.getName(), e);
    }
    if(tracker != null) holder.put(file.getAbsolutePath(), tracker);
    return tracker;
  }

  public void deleteExpireDate(File folder, int expire) {
    deletes.add(new Delete(folder, expire));
    //    System.out.println(" da tao doi tuong "+ deletes.size());
  }

  private void deleteExpireDate1(Delete delete) {
    if(delete == null) return;
    File folder = delete.folder;
    int expire = delete.expire;
    delete = null;
    if(folder == null || expire < 1) return;
    //    System.out.println(" chuan bi xoa "+ folder.getAbsolutePath());
    File[] files = UtilFile.listFiles(folder, new FileFilter() {
      public boolean accept(File f) {
        if (!f.isDirectory()) return false;
        return UtilFile.validate(f.getName());
      }
    });

    for (int i = expire; i < files.length; i++) {
      DbIndexer indexer = holder.get(files[i].getAbsolutePath());
      if(indexer != null) indexer.close();
      UtilFile.deleteFolder(files[i]);
    }

    files = UtilFile.listFiles(folder, new FileFilter() {
      public boolean accept(File f) {
        if (!f.isDirectory()) return false;
        return UtilFile.validate(f.getName());
      }
    });

    /* Analyzer analyzer = new WhitespaceAnalyzer();
    for (int i = 0; i < files.length; i++) {
//      System.out.println("optimize "+ folder.getAbsolutePath()+ " : "+files[i].getName());
      DbIndexer indexer = getDbIndexer(folder, files[i].getName(), analyzer);
      if(indexer == null || indexer.isClose()) continue;
//      indexer.optimize();
    }*/
  }

  private void closeRealtimeIndexer() {
    Calendar calendar = Calendar.getInstance();
    int date = calendar.get(Calendar.DAY_OF_MONTH);
    if(currentDate == date) return;
    currentDate = date;
    SimpleDateFormat dateFormat = CalendarUtils.getFolderFormat();
    currentDateName = dateFormat.format(calendar.getTime());

    Iterator<Map.Entry<String, DbIndexer>> iterator = holder.entrySet().iterator();
    while(iterator.hasNext()) {
      Map.Entry<String, DbIndexer>  entry = iterator.next();
      DbIndexer indexer = entry.getValue();
      if(!(indexer instanceof DbRealtimeIndexer)) continue;
//      indexer.optimize();
      indexer.close();
      iterator.remove();
    }
  }

  public IndexSearcher getIndexReader(File folder) {
    //    System.out.println(" da call vao day "+ folder.getName());
    //    System.out.println(folder.getAbsolutePath()+ " /// ");
    if(!folder.getName().equalsIgnoreCase(currentDateName))  return null;
    String path = folder.getAbsolutePath();
    DbIndexer dbIndexer = holder.get(path);
    //    System.out.println("==== >"+ currentDateName+ " ===  >"+ dbIndexer);
    if(dbIndexer == null) return null;
    if(!(dbIndexer instanceof DbRealtimeIndexer)) return null;
    return ((DbRealtimeIndexer)dbIndexer).getSearcher();
  }

  public static class Delete {

    private File folder;
    private int expire;

    public Delete(File folder, int expire) {
      this.folder = folder;
      this.expire = expire;
    }

  }
}
