/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index;

import java.io.File;
import java.io.FileFilter;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.NIOFSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.vietspider.cache.InmemoryCache;
import org.vietspider.common.Application;
import org.vietspider.common.io.FileNameComparator;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.index.result.CachedEntry2;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Sep 9, 2009  
 */
public class IndexSearchers extends Thread {

  private static volatile IndexSearchers INSTANCE;

  public static synchronized IndexSearchers getInstance() {
    if(INSTANCE == null) INSTANCE  = new IndexSearchers();
    return INSTANCE;    
  }

  private volatile Map<String, CachedSearcher> cachedSearchers = new ConcurrentHashMap<String, CachedSearcher>();
  private volatile Map<String, File[]> indexFiles = new ConcurrentHashMap<String, File[]>();
  
  private volatile InmemoryCache<Integer, CachedEntry2> cachedSearchResult;

  public IndexSearchers() {
    Application.addShutdown(new Application.IShutdown() {

      public String getMessage() { return "Close Topic Tracking Database";}

      public void execute() {
        Iterator<Map.Entry<String, CachedSearcher>> iterator = cachedSearchers.entrySet().iterator();

        while(iterator.hasNext()) {
          Map.Entry<String, CachedSearcher> entry = iterator.next();
          try {
            entry.getValue().close();
          } catch (Exception e) {
            LogService.getInstance().setThrowable(e);
          }
        }
      }
    });
    
    cachedSearchResult = new InmemoryCache<Integer, CachedEntry2>("page", 1000);
    cachedSearchResult.setLiveTime(5*60);

    start();
  }
  
  public void run() {
    while(true) {
//      Iterator<Map.Entry<String, CachedSearcher>> iterator = cachedSearchers.entrySet().iterator();
//      while(iterator.hasNext()) {
//        Map.Entry<String, CachedSearcher> entry = iterator.next();
//        try {
//          if(entry.getValue().isTimeout()) entry.getValue().close();
//        } catch (Exception e) {
//          LogService.getInstance().setThrowable(e);
//        }
//      }

      autoLoadFiles();

      try {
        Thread.sleep(5*60*1000);
      } catch (Exception e) {
      }
    }
  }
  
  public void putCachedEntry(int code, CachedEntry2 entry) {
    cachedSearchResult.putCachedObject(code, entry);
  }
  
  public CachedEntry2 getCachedEntry(int code) {
    return cachedSearchResult.getCachedObject(code);
  }

  public File[] getFiles(String parent) {
    File [] files = indexFiles.get(parent);
    if(files != null && files.length > 0) return files;
    files = loadFiles(parent);
    if(files == null) files = new File[0];
    indexFiles.put(parent, files);
    return files;
  }

  public IndexSearcher getSearcher(CoreDbIndexers dbIndexers, File folder, boolean ram) throws Exception {
    IndexSearcher searcher = dbIndexers.getIndexReader(folder);
    if(searcher != null) return searcher; 
    //      System.out.println(" ====  > luc get "+ searcher.maxDoc());
    //    }

    String path = folder.getAbsolutePath();
    CachedSearcher cachedSearcher = cachedSearchers.get(path);

    Directory directory = NIOFSDirectory.open(folder);
    if(cachedSearcher != null) {
      if(cachedSearcher.getLastModified() != IndexReader.lastModified(directory)) {
        //        System.out.println(" chuan bi dong cai nay "+ folder.getAbsolutePath());
        try {
          cachedSearcher.close();
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }  
      } 
      if(cachedSearcher.isClose()) cachedSearcher = null;
    }

    try {
      if(cachedSearcher != null) return cachedSearcher.getSearcher();
    } catch (Exception e) {
      LogService.getInstance().setMessage(e, e.toString());
      cachedSearcher.close(); 
      cachedSearcher = null;
    }

    if(ram) directory = new RAMDirectory(directory);
    IndexReader reader = IndexReader.open(directory, true);
    IndexSearcher indexSearcher = new IndexSearcher(reader);
    cachedSearcher = new CachedSearcher(
        IndexReader.lastModified(directory), indexSearcher, reader);
    cachedSearchers.put(path, cachedSearcher);    
    return indexSearcher;
  }

  public void autoLoadFiles() {
    Iterator<String> iterator = indexFiles.keySet().iterator();
    while(iterator.hasNext()) {
      String parent  = iterator.next();
      File [] files = loadFiles(parent);
      if(files == null) files = new File[0];
      indexFiles.put(parent, files);
    }
  }

  //"content/cindexed/"
  private File [] loadFiles(String parent) {
    File folder = UtilFile.getFolder(parent);
    return UtilFile.listFiles(folder, new FileFilter() {
      public boolean accept(File f) {
        if (!f.isDirectory()) return false;
        return UtilFile.validate(f.getName());
      }
    }, new FileNameComparator());
  }

  private class CachedSearcher  {

    private long lastModified = -1;
    private IndexSearcher searcher;
    private IndexReader reader;
    private boolean isClose;
//    private long lastAccess = System.currentTimeMillis();


    private CachedSearcher(long _modified, IndexSearcher _searcher, IndexReader _reader) {
      this.lastModified = _modified;
      this.searcher = _searcher;
      this.reader = _reader;
    }
    
    private void close() throws Exception {
      this.isClose = true;
      reader.close();
      searcher.close();
    }
    
    boolean isClose() { return isClose || reader.getRefCount() < 1; }

    long getLastModified() { return lastModified; }

    IndexSearcher getSearcher() {
//      lastAccess = System.currentTimeMilli/s();
      return searcher; 
    }

//    boolean isTimeout() { return System.currentTimeMillis() - lastAccess > 15*60*1000; }

  }


}
