/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index;

import java.io.File;
import java.util.List;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.TopDocs;
import org.vietspider.index.result.CachedEntry2;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Nov 16, 2009  
 */
public abstract class ACachedSearcher {
  
  protected File[] indexFiles;
  protected String indexFolder;

//  private File resultFile;

  protected CoreDbIndexers dbIndexers;
  
  protected volatile CachedEntry2 cachedEntry;
  protected volatile boolean isRunning = true;
  
  protected File tempIndex;
  
  public CachedEntry2 getCachedEntry() { return cachedEntry;  }

  public abstract void search(final CommonSearchQuery query) throws Exception ;
  
  public void search(File indexFile, boolean ram, 
      Query query, int max, float rate, List<TempEntry> entries) throws Exception {
//    System.out.println("search "+ indexFile.getAbsolutePath() +  " max " + max);
    Searcher indexSearcher = IndexSearchers.getInstance().getSearcher(dbIndexers, indexFile, ram);
//    System.out.println("max doc "+indexSearcher.maxDoc());

    TopDocs topDocs = indexSearcher.search(query, null, Math.max(indexSearcher.maxDoc(), 1000));
    ScoreDoc [] docs = topDocs.scoreDocs;
    
    int maxDoc = Math.min(docs.length, max);
    cachedEntry.increateTotal(docs.length);
    
    for(int i = 0; i < maxDoc; i++) {
      int docId = docs[i].doc;
      Document doc = indexSearcher.doc(docId);
      //        doc.setBoost(hitDocs[i].getScore());
      if(doc == null) continue;
      Field field = doc.getField(IIndexEntry.FIELD_ID);
      if(field == null) continue;
      long id  = Long.parseLong(field.stringValue());
      float score = (docs[i].score*1000);
      
//      System.out.println("thay co " + field.stringValue() + " / " + score);
//      if(score < 50) continue;
//      System.out.println("==============>"+field.stringValue() + " / " + score);

      if(score > 700 && rate != 0) score += score*rate;

      //        System.out.println(field.stringValue() + " / " + hitDocs[i].getScore());
//      DocEntry entry = new DocEntry(id, (int)score);
      if(cachedEntry.collectionSize() >= 1000) break;
      
      if(entries != null) {
        if(score > 200) {
          cachedEntry.addDocEntry(id, score);
        } else {
          entries.add(new TempEntry(id, score));
        }
      } else {
        cachedEntry.addDocEntry(id, score);  
      }
      
//      System.out.println("*****************"+cachedEntry.collectionSize());
      
      if(cachedEntry.collectionSize() > 15) isRunning = false;
    }
    
  }
  
  protected static class TempEntry {
    
    protected long id;
    protected float score;
    
    TempEntry(long id, float score) {
      this.id = id;
      this.score = score;
    }
  }
}
