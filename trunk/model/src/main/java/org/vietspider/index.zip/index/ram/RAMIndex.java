/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index.ram;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.MergeScheduler;
import org.apache.lucene.index.MultiReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.AlreadyClosedException;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Oct 8, 2009  
 */
public final class RAMIndex {

  public long maxRamSize = 1024 * 1024;

  private IndexWriter currentWriter;

  private List<IndexWriter> writersToDisk = new ArrayList<IndexWriter>();

  private ConcurrentLinkedQueue<Query> deleteQueries = new ConcurrentLinkedQueue<Query>();

  private ConcurrentLinkedQueue<Term> _deleteTerms = new ConcurrentLinkedQueue<Term>();

  private MergeScheduler ramMergeScheduler;

  private IndexWriter diskWriter;

  private  FlushToDiskThread flushToDiskThread = new FlushToDiskThread();

  private boolean isClosed = false;

  private List<Exception> exceptions = new ArrayList<Exception>();

  public RAMIndex(IndexWriter diskWriter, long maxRamSize, MergeScheduler ramMergeScheduler) {
    this.diskWriter = diskWriter;
    this.maxRamSize = maxRamSize;
    this.ramMergeScheduler = ramMergeScheduler;
  }

  private IndexWriter takeNextToDiskWriter() {
    synchronized (writersToDisk) {
      if (writersToDisk.size() == 0) return null;
      IndexWriter toDiskIW = writersToDisk.get(0);
      writersToDisk.remove(0);
      return toDiskIW;
    }
  }

  public synchronized IndexReader[] getReaders() throws IOException {
    List<IndexReader> readers = new ArrayList<IndexReader>();
    if (currentWriter != null) {
      readers.add(currentWriter.getReader());
    }
    for (int x = 0; x < writersToDisk.size(); x++) {
      IndexWriter iw = writersToDisk.get(x);
      readers.add(iw.getReader());
    }
    return readers.toArray(new IndexReader[0]);
  }

  void doFlush() throws IOException {
    IndexWriter iw = takeNextToDiskWriter();
    if(iw != null) {
      iw.commit();
      diskWriter.addIndexesNoOptimize(new Directory[] { iw.getDirectory() });
    }
    diskWriter.commit();
  }

  public synchronized void flush(boolean force, boolean doWait) throws IOException {
    boolean doFlush = false;
    applyDeletes();
    if (currentWriter != null && doWait) {
      writersToDisk.add(currentWriter);
      currentWriter = null;
      doFlush();
    } else {
      if (currentWriter != null) {
        if (maxRamSize > currentWriter.ramSizeInBytes()) {
          doFlush = true;
        }
      }
      synchronized (writersToDisk) {
        if (force || doFlush) {
          writersToDisk.add(currentWriter);
          flushToDiskThread.newOne();
          currentWriter = null;
        }
      }
    }
  }

  /* private int count(Term term, IndexReader r) throws IOException {
    int count = 0;
    TermDocs td = r.termDocs(term);
    while (td.next()) {
      count++;
    }
    return count;
  }*/

  private synchronized void applyDeletes() throws IOException {
    if(deleteQueries.size() > 0) {
      Query[] queries =  deleteQueries.toArray(new Query[0]);
      for (int i = 0; i < writersToDisk.size(); i++) {
        IndexWriter iw = writersToDisk.get(i);
        if(iw != null) iw.deleteDocuments(queries);
      }
      if (currentWriter != null) currentWriter.deleteDocuments(queries);
      deleteQueries.clear();
    }

    if(_deleteTerms.size() > 0) {
//      System.out.println(" thay co "+ writersToDisk.size()+ " ====  >"+ currentWriter);
      Term[] terms = _deleteTerms.toArray(new Term[0]);
      for (int i = 0; i < writersToDisk.size(); i++) {
        IndexWriter iw =  writersToDisk.get(i);
        if(iw != null)  iw.deleteDocuments(terms);
      }
      if (currentWriter != null) {      
        currentWriter.deleteDocuments(terms);
      }
      _deleteTerms.clear();
    }
  }

  public void flush(boolean doWait) throws IOException {
    flush(true, doWait);
  }

  public void addDocument(Document document, Analyzer analyzer) throws CorruptIndexException, IOException {
    IndexWriter iw = getCurrentWriter();
    iw.addDocument(document, analyzer);
  }

  public void deleteDocuments(Term[] terms)  {
    Collections.addAll(_deleteTerms, terms);
//    for (int x = 0; x < terms.length; x++) {
//      _deleteTerms.add(terms[x]);
//    }
  }

  public void deleteDocuments(Query[] queries) {
    Collections.addAll(deleteQueries, queries);
//    for (int x = 0; x < queries.length; x++) {
//      deleteQueries.add(queries[x]);
//    }
  }

  @SuppressWarnings("unused")
  public void updateDocument(Term term, Document document, Analyzer analyzer) throws IOException {
    _deleteTerms.add(term);
    addDocument(document, diskWriter.getAnalyzer());
  }

  public synchronized IndexWriter getCurrentWriter() throws CorruptIndexException, IOException {
    Analyzer defaultAnalyzer = diskWriter.getAnalyzer();
    if (currentWriter == null) {
      currentWriter = new IndexWriter(new RAMDirectory(), defaultAnalyzer, true, MaxFieldLength.UNLIMITED);
      currentWriter.setMergeScheduler(ramMergeScheduler);
    }
    return currentWriter;
  }

  public long sizeInBytes() {
    if (currentWriter != null) 
      return ((RAMDirectory) currentWriter.getDirectory()).sizeInBytes();
    return 0;
  }

  public synchronized IndexReader getReader() throws IOException {
    applyDeletes();
    IndexReader[] readers = getReaders();
    if (readers == null) return null;
    if (readers.length == 1) return readers[0];
    return new MultiReader(readers);
  }

  void ensureOpen() throws IOException {
    if (isClosed) throw new IOException("index is closed");
  }

  public synchronized void close() {
    isClosed = true;
  }

  private class FlushToDiskThread extends Thread {

    public FlushToDiskThread() {
      start();
    }

    public void run() {
      while (!isClosed) {
        synchronized (this) {
          try {
            wait();
          } catch (InterruptedException ex) {
          }
          if (isClosed) return;
          try {
            RAMIndex.this.doFlush();
          } catch (AlreadyClosedException e) {
            return;
          } catch (IOException ioe) {
            synchronized (exceptions) {
              exceptions.add(ioe);
            }
          }
        }
      }
    }

    @SuppressWarnings("unused")
    public void close() {
      assert isClosed;
      notifyAll();
    }

    private synchronized void newOne() {
      notifyAll();
    }
  }
}
