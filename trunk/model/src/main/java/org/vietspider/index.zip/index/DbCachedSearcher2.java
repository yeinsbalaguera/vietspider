/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.index;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.search.BooleanQuery;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.index.result.CachedEntry2;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 4, 2008  
 */
public class DbCachedSearcher2 extends ACachedSearcher {

  public DbCachedSearcher2(CoreDbIndexers indexers, String _indexFolder, File _rFile) {
    this.dbIndexers = indexers;
    this.indexFolder = _indexFolder;
    this.tempIndex = UtilFile.getFolder("content/temp/indexed");
    this.cachedEntry = new CachedEntry2(_rFile);
  }

  public void search(final CommonSearchQuery searchQuery) throws Exception {
    indexFiles = IndexSearchers.getInstance().getFiles(indexFolder);
    if(indexFiles.length < 1) return;

    isRunning = true;

    new Thread() {
      public void run() {
        List<TempEntry> entries = new ArrayList<TempEntry>(500);
        
        BooleanQuery query = null;
        try {
          query = searchQuery.createQuery();
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
          return;
        }
        
        float score = 1.2f;
        for(int i = 0; i < Math.min(3, indexFiles.length); i++) {
          try {
            search(indexFiles[i], true, query, 300, score, entries);
          } catch (Exception e) {
            LogService.getInstance().setThrowable(e);
          }  
          score -= 0.2f;
        }
        

       /* if(indexFiles.length > 1) {
          try {
            search(indexFiles[1], true, query, 250, 1.0f, entries);
          } catch (Exception e) {
            LogService.getInstance().setThrowable(e);
          }
        }

        if(indexFiles.length > 2) {
          try {
            search(indexFiles[2], true, query, 250, 0.7f, entries);
          } catch (Exception e) {
            LogService.getInstance().setThrowable(e);
          }
        }*/

        for(int i = 0; i < entries.size(); i++) {
          TempEntry temp = entries.get(i);
          cachedEntry.addDocEntry(temp.id, temp.score);
        }
        
//        System.out.println(" cuoi cung ta co "+ cachedEntry.collectionSize());
        
        /*int i = 3;
        for(; i < Math.min(indexFiles.length, 7); i++) {
          try {
            search(indexFiles[i], true, query, 1000, 0.5f , null);
          } catch (Exception e) {
            LogService.getInstance().setThrowable(e);
          }
        }
        
        for(; i < indexFiles.length; i++) {
          try {
            search(indexFiles[i], false, query, 1000, 0.0f , null);
          } catch (Exception e) {
            LogService.getInstance().setThrowable(e);
          }
        }*/

        try {
          search(tempIndex, false, query, 10000, 0.0f , null);
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }

        cachedEntry.save();
        searchQuery.setTotal(cachedEntry.getTotalData());
        searchQuery.savePattern();
        isRunning = false;
      }
    }.start();

    //    System.out.println(" doi roi ");
    while(isRunning) {
      try {
        Thread.sleep(50); 
      } catch (InterruptedException e) {
        break;
      }
    }
    //    System.out.println(" thoat roi");
  }

}
