package org.vietspider.model.plugin.formua;


import java.util.ArrayList;
import java.util.List;

import org.vietspider.model.plugin.formua.XMLForMuaConfig.Category;
import org.vietspider.model.plugin.formua.XMLForMuaConfig.Option;
import org.vietspider.parser.xml.XMLNode;
import org.vietspider.serialize.Object2XML;
import org.vietspider.serialize.SerializableMapping;
import org.vietspider.serialize.XML2Object;
import org.vietspider.token.attribute.Attributes;


public class Category_MappingImpl implements SerializableMapping<Category> {

	private final static int code=25583618;

	public Category create() {
		return new Category();
	}

	public void toField(Category object, XMLNode node, String name, String value) throws Exception {
		if(name.equals("category-name")) {
			object.setName(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("category-id")) {
			object.setId(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("sub-options")) {
			List<Option> list = null;
			list = object.getSubOptions();
			if(list == null) list = new ArrayList<Option>();
			XML2Object.getInstance().mapCollection(list, Option.class, node);
			object.setSubOptions(list);
			return;
		}
		if(name.equals("purposes")) {
			List<Option> list = null;
			list = object.getPurposes();
			if(list == null) list = new ArrayList<Option>();
			XML2Object.getInstance().mapCollection(list, Option.class, node);
			object.setPurposes(list);
			return;
		}

	}

	public XMLNode toNode(Category object) throws Exception {
		XMLNode node = new XMLNode("option");
		Attributes attrs  = new Attributes(node);
		Object2XML mapper = Object2XML.getInstance();
		mapper.addNode(object.getName(), node, false, "category-name");
		mapper.addNode(object.getId(), node, false, "category-id");
		mapper.addNode(object.getSubOptions(), node, false, "sub-options", "item", "org.vietspider.model.plugin.formua.XMLForMuaConfig$Option");
		mapper.addNode(object.getPurposes(), node, false, "purposes", "item", "org.vietspider.model.plugin.formua.XMLForMuaConfig$Option");
		return node;
	}
}
