package org.vietspider.model.plugin.formua;


import org.vietspider.model.plugin.formua.XMLForMuaConfig.Option;
import org.vietspider.parser.xml.XMLNode;
import org.vietspider.serialize.Object2XML;
import org.vietspider.serialize.SerializableMapping;
import org.vietspider.serialize.XML2Object;
import org.vietspider.token.attribute.Attributes;


public class Option_MappingImpl implements SerializableMapping<Option> {

	private final static int code=11790863;

	public Option create() {
		return new Option();
	}

	public void toField(Option object, XMLNode node, String name, String value) throws Exception {
		if(name.equals("option-name")) {
			object.setName(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("option-id")) {
			object.setId(XML2Object.getInstance().toValue(String.class, value));
			return;
		}

	}

	public XMLNode toNode(Option object) throws Exception {
		XMLNode node = new XMLNode("option");
		Attributes attrs  = new Attributes(node);
		Object2XML mapper = Object2XML.getInstance();
		mapper.addNode(object.getName(), node, false, "option-name");
		mapper.addNode(object.getId(), node, false, "option-id");
		return node;
	}
}
