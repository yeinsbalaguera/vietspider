/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.model.plugin.formua;

import java.util.ArrayList;
import java.util.List;

import org.vietspider.model.plugin.PluginConfig;
import org.vietspider.serialize.GetterMap;
import org.vietspider.serialize.NodeMap;
import org.vietspider.serialize.NodesMap;
import org.vietspider.serialize.SetterMap;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Sep 8, 2008  
 */

@NodeMap("formua-config")
public class XMLForMuaConfig extends PluginConfig {
  
  @NodeMap("homepage")
  private String homepage = "";
  //"http://localhost/joomla/";
  public String getHomepage() { return homepage; }
  public void setHomepage(String homepage) { this.homepage = homepage; }

  @NodeMap("charset")
  private String charset = "utf-8";
  public String getCharset() { return charset; }
  public void setCharset(String charset) { this.charset = charset; }

  @NodeMap("login-address")
  private String loginAddress = "";
  //"http://localhost/joomla/administrator/index.php?option=com_login";
  @GetterMap("login-address")
  public String getLoginAddress() { return loginAddress; }
  @SetterMap("login-address")
  public void setLoginAddress(String urlLogin) { this.loginAddress = urlLogin; }
  
  @NodeMap("auto")
  private boolean auto = false;
  @GetterMap("auto")
  public boolean isAuto() { return auto; }
  @SetterMap("auto")
  public void setAuto(boolean value) { this.auto = value; }
 
  @NodeMap("alert-message")
  private boolean alertMessage = true;
  @GetterMap("alert-message")
  public boolean isAlertMessage() { return alertMessage; }
  @SetterMap("alert-message")
  public void setAlertMessage(boolean value) {alertMessage = value;}
  
  @NodeMap("login-username")
  private String username = "admin";
  @GetterMap("login-username")
  public String getUsername() { return username; }
  @SetterMap("login-username")
  public void setUsername(String username) { this.username = username; }

  @NodeMap("login-password")
  private String password = "1234";
  @GetterMap("login-password")
  public String getPassword() { return password; }
  @SetterMap("login-password")
  public void setPassword(String password) { this.password = password; }

  @NodeMap("post-address")
  private String postAddress = "";
  //"http://localhost/joomla/administrator/index.php?option=com_content&task=add";
  @GetterMap("post-address")
  public String getPostAddress() { return postAddress; }
  @SetterMap("post-address")
  public void setPostAddress(String postURL) { this.postAddress = postURL;  }
  
  @NodesMap(value = "categories", item = "item")
  private Category[] categories;
  @GetterMap("categories")
  public Category[] getCategories(){ return this.categories; }
  @SetterMap("categories")
  public void setCategories(Category[] value){ this.categories = value; }
  
  @NodesMap(value = "regions", item = "item")
  private Option[] regions;
  @GetterMap("regions")
  public Option[] getRegions(){ return this.regions; }
  @SetterMap("regions")
  public void setRegions(Option [] value){ this.regions = value; }
  
  @NodeMap("option")
  public static class Category {
    
    public Category() {
    }
    
    public Category(String id, String name) {
      this.id = id;
      this.name = name;
    }
    
    public Category(Option option) {
     this.id =  option.getId();
     this.name = option.getName();
    }
    
    @NodeMap("category-name")
    private String name;
    @GetterMap("category-name")
    public String getName() { return name; }
    @SetterMap("category-name")
    public void setName(String categoryName) { this.name = categoryName; }
    
    @NodeMap("category-id")
    private String id;
    @GetterMap("category-id")
    public String getId() { return id; }
    @SetterMap("category-id")
    public void setId(String categoryid) { this.id = categoryid; }
    
    @NodesMap(value = "sub-options", item = "item")
    private List<Option> subOptions = new ArrayList<Option>();
    @GetterMap("sub-options")
    public List<Option> getSubOptions() { return subOptions; }
    @SetterMap("sub-options")
    public void setSubOptions(List<Option> subCategories) {
      this.subOptions = subCategories;
    }
    
    @NodesMap(value = "purposes", item = "item")
    private List<Option> purposes;
    @GetterMap("purposes")
    public List<Option> getPurposes(){ return this.purposes; }
    @SetterMap("purposes")
    public void setPurposes(List<Option> value){ this.purposes = value; }
    
  }
  
  @NodeMap("option")
  public static class Option {
    
    public Option() {
      
    }
    
    public Option(String id, String name) {
      this.id = id;
      this.name = name;
    }
    
    @NodeMap("option-name")
    private String name;
    @GetterMap("option-name")
    public String getName() { return name; }
    @SetterMap("option-name")
    public void setName(String categoryName) { this.name = categoryName; }
    
    @NodeMap("option-id")
    private String id;
    @GetterMap("option-id")
    public String getId() { return id; }
    @SetterMap("option-id")
    public void setId(String categoryid) { this.id = categoryid; }
   
  }
  
  
}
