package org.vietspider.model.plugin.formua;


import org.vietspider.parser.xml.XMLNode;
import org.vietspider.serialize.Object2XML;
import org.vietspider.serialize.SerializableMapping;
import org.vietspider.serialize.XML2Object;
import org.vietspider.token.attribute.Attributes;


public class ForMuaSyncData_MappingImpl implements SerializableMapping<ForMuaSyncData> {

	private final static int code=5048333;

	public ForMuaSyncData create() {
		return new ForMuaSyncData();
	}

	public void toField(ForMuaSyncData object, XMLNode node, String name, String value) throws Exception {
		if(name.equals("article-id")) {
			object.setArticleId(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("category-id")) {
			object.setCategoryId(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("sub-category-id")) {
			object.setSubCategoryId(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("purpose")) {
			object.setPurpose(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("region")) {
			object.setRegion(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("content")) {
			object.setContent(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("debug")) {
			object.setDebug(XML2Object.getInstance().toValue(boolean.class, value));
			return;
		}

	}

	public XMLNode toNode(ForMuaSyncData object) throws Exception {
		XMLNode node = new XMLNode("formua-config");
		Attributes attrs  = new Attributes(node);
		Object2XML mapper = Object2XML.getInstance();
		mapper.addNode(object.getArticleId(), node, false, "article-id");
		mapper.addNode(object.getCategoryId(), node, false, "category-id");
		mapper.addNode(object.getSubCategoryId(), node, false, "sub-category-id");
		mapper.addNode(object.getPurpose(), node, false, "purpose");
		mapper.addNode(object.getRegion(), node, false, "region");
		mapper.addNode(object.getContent(), node, false, "content");
		mapper.addPrimitiveNode(object.isDebug(), node, false, "debug");
		return node;
	}
}
