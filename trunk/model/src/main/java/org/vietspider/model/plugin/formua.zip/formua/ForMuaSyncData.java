/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.model.plugin.formua;

import org.vietspider.model.plugin.SyncContent;
import org.vietspider.serialize.NodeMap;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 26, 2009  
 */
@NodeMap("formua-config")
public class ForMuaSyncData extends SyncContent {

  @NodeMap("article-id")
  private String articleId = null;
  @NodeMap("category-id")
  private String categoryId = null;
  @NodeMap("sub-category-id")
  private String subCategoryId = null;
  @NodeMap("purpose")
  private String purpose = null;
  @NodeMap("region")
  private String region = null;
  
  @NodeMap("content")
  private String content = null;
  
  @NodeMap("debug")
  private boolean debug = false;
  public boolean isDebug() { return debug; }
  public void setDebug(boolean debug) { this.debug = debug; }
  
  public ForMuaSyncData() {
    super("4mua.sync.article.plugin");
  }
  
  public String getArticleId() { return articleId; }
  public void setArticleId(String articleId) { this.articleId = articleId; }
  
  
  public String getCategoryId() { return categoryId; }
  public void setCategoryId(String categoryId) { this.categoryId = categoryId; }

  public String getSubCategoryId() { return subCategoryId; }
  public void setSubCategoryId(String subCategoryId) { this.subCategoryId = subCategoryId;  }

  public String getPurpose() { return purpose; }
  public void setPurpose(String purpose) { this.purpose = purpose; }

  public String getRegion() { return region; }
  public void setRegion(String region) { this.region = region; }

  public String getContent() { return content; }
  public void setContent(String content) { this.content = content; }

}
