/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index3;

import java.io.File;

import org.vietspider.content.index3.HighlightBuilder.HighlightData;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 26, 2009  
 */
public class TestHighLightBuilder {

  static {
    File file  = new File("D:\\Temp\\articles\\data");
    try {
      System.setProperty("vietspider.data.path", file.getCanonicalPath());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  //  ,hiệu Hitachi hàng mới 
  //  Bán 2.5 HDD Laptop 80GB & 120 GB ATA Hitachi [26.08.2009] 
  public static void main(String[] args) {
    String pattern = "nước tinh khiết máy lọc nước";
    String title  = "Chủ đề: Lọc nước tinh khiết R/O SAFIA nhà bạn có chưa?";

    pattern = "ram giá rẻ";
    title = "COMPAQ 510. T5870, Ram 2GB, HDD 250Gb. Giá 11. [27.08.2009 ";

    HighlightBuilder higher = new HighlightBuilder(pattern);
    System.out.println(higher.buildTitle(title));

    String desc = "Ngày 26.8, nguồn tin Bộ Công an, BTC cuộc thi nói trên đã gửi văn bản đề nghị "
      +" can thiệp vì trang web của Cty FBN có tên cũng gần giống 100% 2 trang web của BTC "
      +" cuộc thi này. Không những thế, qua điều tra thì Cty FBN trước đây có khá nhiều \"bí ẩn\".";

    String content = "Theo công văn số 171/UBND-BCĐ do Phó Chủ tịch UBND tỉnh "
      +" Bà Rịa -Vũng Tàu - Phó trưởng BTC cuộc thi \"Hoa hậu Quý bà đẹp và thành đạt năm 2009\""
      +"  Võ Thành Kỳ ký ngày 12.8.2009, thì cuộc thi này được phép của Chính phủ và quyết định"
      +"  của Bộ VHTTDL. UBND tỉnh Bà Rịa - Vũng Tàu đã triển khai các hoạt động phục vụ cuộc thi,"
      +"  trong đó có việc lập 2 website chính của cuộc thi là www.mrsvietnam2009.com và "
      +" www.mrsworldvietnam2009.com . ";


    content += "Tuy nhiên, trong quá trình quản lý, cập nhật thông tin cho 2 trang web này,"
      +" BTC cuộc thi đã phát hiện trên mạng Internet còn có trang web www.mrsworldvietnam.com do"
      +" Cty FBN, có địa chỉ là số B59 đường Tô Ký, P.Đông Hưng Thuận, Q.12 - TP.Hồ Chí Minh thực"
      +" hiện, đã đăng tải nhiều thông tin, hình ảnh về cuộc thi \"Hoa hậu Quý bà đẹp và thành đạt "
      +"thế giới 2009\". Theo BTC cuộc thi, việc Cty FBN đăng tải các thông tin về cuộc thi là vi "
      +"phạm quy định pháp luật về bản quyền hình ảnh, về thông tin trên mạng Internet... \n"
      +"Hiện vụ việc được Bộ Công an xác minh xử lý. " ;


    pattern = " Bộ Công an xác minh xử lý";
    higher = new HighlightBuilder(pattern);

    StringBuilder builder2 = new StringBuilder(desc);
    builder2.append('.').append(' ').append(content);
    HighlightData hdesc = higher.buildDesc(builder2.toString(), 500, 0);
    //    System.out.println(hdesc.getValue());

    StringBuilder builder3 = new StringBuilder("Tq -- hàng hiệu giá rẻ");
    builder3.append('.').append(' ').append("Hiện nay,nhu cầu ăn ngon,mặc đẹp là nhu cầu gần như là của mỗi người.Và với mong muốn được góp phần giúp các bạn thực hiện nhu cầu này,mình xin mạo muội mở shop thời trang online ART SHOP.ART SHOP chuyên bán đồ hiệu giá bình dân của các hãng nổi tiếng thế giới,những hãng mà có gia công tại VIỆT NAM(vậy mới có hàng luồn ra ngoài mới bán giá rẻ được chứ .hehe )");
    builder3.append('.').append(' ').append("nhờ mod close giùm ! ");

    pattern = "hàng hiệu mới sành điệu";
    higher = new HighlightBuilder(pattern);
    hdesc = higher.buildDesc(builder3.toString(), 70, 0);
    System.out.println(hdesc.getValue());



  }
}
