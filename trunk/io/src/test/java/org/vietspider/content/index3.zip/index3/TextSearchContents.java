/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index3;

import java.io.File;
import java.util.List;

import org.vietspider.bean.Article;
import org.vietspider.bean.Content;
import org.vietspider.bean.Meta;
import org.vietspider.bean.xml.XArticle;
import org.vietspider.common.io.DataReader;
import org.vietspider.common.io.DataWriter;
import org.vietspider.common.io.UtilFile;
import org.vietspider.db.database.MetaList;
import org.vietspider.serialize.XML2Object;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 25, 2009  
 */
public class TextSearchContents {
  
  static {
    File file  = new File("D:\\Temp\\articles\\data");
    try {
      System.setProperty("vietspider.data.path", file.getCanonicalPath());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  
  public static void main(String[] args) throws Exception {
    UtilFile.deleteFolder(new File("D:\\Temp\\articles\\data\\content\\search\\"));
    ContentSearcher searcher = new ContentSearcher();
    searcher.setArticleLoader(new ArticleLoader() {
      
      public Article load(String id) {
        File file  = new File("D:\\Temp\\articles\\input\\"+id+".article.xml");
        try {
          byte [] bytes = new DataReader().load(file);
          XArticle xArticle = XML2Object.getInstance().toObject(XArticle.class, bytes);
          
          Article article = new Article();
          
          Meta meta = new Meta();
          meta.setId(id);
          meta.setTitle(xArticle.getTitle());
          meta.setDesc(xArticle.getDesc());
          meta.setSource(xArticle.getSource());
          meta.setTime(xArticle.getTime());
          meta.setSourceTime(xArticle.getSourceTime());
          article.setMeta(meta);
          
          Content content = new Content(xArticle.getId(), xArticle.getTime(), xArticle.getContent());
          article.setContent(content);
          
          return article;
        } catch (Exception e) {
          e.printStackTrace();
          return null;
        }
      }
    });
    
    MetaList metaList = new MetaList();
    metaList.setCurrentPage(1);
    searcher.search(metaList, "trách nhiệm");
    
    File folder  = new File("D:\\Temp\\articles\\temp\\");
    UtilFile.deleteFolder(folder, false);
    DataWriter writer = new DataWriter();
    
    List<Article> articles = metaList.getData();
    for(int i = 0; i < articles.size(); i++) {
      Meta meta = articles.get(i).getMeta();
      String text = meta.getTitle();
      text += "\n\n\n" + meta.getDesc();
      System.out.println(text);
      File file  = new File(folder, meta.getId()+".txt");
      writer.save(file, text.getBytes("utf-8"));
    }
  }
}
