/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index3;

import java.util.StringTokenizer;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 27, 2009  
 */
public class TestStringTokenizer {
  public static void main(String[] args) {
    StringTokenizer tokenizer = new StringTokenizer("hhihi");
    
  }
}
