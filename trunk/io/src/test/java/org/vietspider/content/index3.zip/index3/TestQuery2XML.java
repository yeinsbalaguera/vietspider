/***************************************************************************
 * Copyright 2001-2010 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index3;

import org.vietspider.index.ClassifiedSearchQuery;
import org.vietspider.serialize.Object2XML;
import org.vietspider.serialize.XML2Object;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Sep 26, 2010  
 */
public class TestQuery2XML {
  
 /* public static void main(String[] args) throws Exception {
    ClassifiedSearchQuery query = new ClassifiedSearchQuery();
    query.setPattern("tHuan");
    query.setActions(new String[]{"ba"});
    query.setDate(2);
    
    ClassifiedSearchQuery subQuery = new ClassifiedSearchQuery();
    subQuery.setPattern(" kehe ");
    query.setSubQuery(subQuery);
    
    
    String xml = Object2XML.getInstance().toXMLDocument(query).getTextValue();
    System.out.println("====================================================");
    System.out.println(xml);
    
    ClassifiedSearchQuery query2 = XML2Object.getInstance().toObject(ClassifiedSearchQuery.class, xml);
    System.out.println(query2.getDate());
    System.out.println(query2.getLPattern());
    
    System.out.println(query2.getSubQuery());
    System.out.println(query2.getSubQuery().getPattern());
    
  }*/
  
}
