/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index3;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 26, 2009  
 */
public class TestTextSearchUtils {
  public static void main(String[] args) {
    TextSearchUtils textSearchUtils = new TextSearchUtils();
    
    String text = "đã quan sát ngôi mộ Choi Jin Sil từ ngày 1, 2 tháng 8, trước khi thực hiện vào ngày 4, 5 tháng 8. Cảnh sát đã phá được vụ án khi phân tích- phân tích và kiểm tra những cuộc gọi điện thoại x";
    String pattern = "phân tích";
    
    System.out.println(textSearchUtils.searchSequence(text, pattern, 0));
  }
}
