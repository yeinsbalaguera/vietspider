/***************************************************************************
 * Copyright 2003-2007 by VietSpider - All rights reserved.                *    
 **************************************************************************/
package org.vietspider.content.index2;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.headvances.vietspider.database.DatabaseService;
import org.headvances.vietspider.database.MetaList;
import org.vietspider.bean.Article;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Meta;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.content.index3.ContentIndex;
import org.vietspider.index.DbCachedSearcher;

class ContentSearcher {

  private Comparator<File> comparator;

  public ContentSearcher() {
    comparator = new Comparator<File>(){

      public int compare(File o1, File o2) {
        try {
          int boost1 = getIntValue(o1.getName());
          int boost2 = getIntValue(o2.getName());
          return boost2 - boost1;
        } catch (Exception e) {
          return 0;
        }
      }
      private int getIntValue(String name) {
        try {
          int idx = name.indexOf('.');
          if(idx > 0) name = name.substring(idx+1);
          return (int)(Float.parseFloat(name)*1000000);
        } catch (Exception e) {
          return 0;
        }
      }
    };
  }

  void searchByQuery(MetaList metas, String queryValue) throws Exception {
    File tempFolder = startSearch(queryValue);
    File [] files = UtilFile.listFiles(tempFolder, null, comparator);
    if(files == null) return;
    loadArticles(metas, files, null);
    
    /*List<ContentIndex> entries = searchByQuery1(queryValue, metas);
    List<Article> articles = new ArrayList<Article>(DatabaseService.PAGE_SIZE);
    for(int i = 0; i < entries.size(); i++) {
      Article article = toArticle(null, entries.get(i));
      articles.add(article);
    }
    metas.setData(articles);*/
  }

  public void searchByDomain(MetaList metas, String [] values) throws Exception {
    File tempFolder = searchByDomain(values);
    File [] files = UtilFile.listFiles(tempFolder, null, comparator);

    if(files == null) return;
    loadArticles(metas, files, null);
  }

  public File searchByDomain(String [] fieldValues) throws Exception {
    BooleanQuery booleanQuery = new BooleanQuery(true);
    for(int i = 0; i < fieldValues.length; i++) {
      TermQuery query = new TermQuery(new Term(ContentIndex.FIELD_DOMAIN, fieldValues[i]));
      booleanQuery.add(new BooleanClause(query, BooleanClause.Occur.SHOULD));
    }

    StringBuilder builder = new StringBuilder();
    for(String ele : fieldValues) {
      if(builder.length() > 0) builder.append('/');
      builder.append(ele);
    }

    String code = String.valueOf(builder.toString().hashCode());
    File tempFolder = UtilFile.getFolder("content/search/" + code +"/");
    File [] files = UtilFile.listFiles(tempFolder);
    if(files != null && files.length > 0 
        && System.currentTimeMillis() - files[0].lastModified() < 5*60*1000l) return tempFolder;

    File folder = UtilFile.getFolder("content/cindexed");
    DbCachedSearcher searcher = new DbCachedSearcher(folder, tempFolder);

    searcher.search(booleanQuery);
    return tempFolder;
  }

  public void search(MetaList metas, String pattern) throws Exception {
    String q_pattern = pattern; 
    if(!checkSyntax(q_pattern)) q_pattern = normalizePattern(q_pattern);
    StringBuilder builder = new StringBuilder();
    builder.append(ContentIndexbak.FIELD_TITLE_INDEX).append(':').append(q_pattern);
    builder.append(" OR ");
    builder.append(ContentIndexbak.FIELD_DESC_INDEX).append(':').append(q_pattern);
    builder.append(" OR ");
    builder.append(ContentIndexbak.FIELD_CONTENT).append(':').append(q_pattern);
    
    File tempFolder = startSearch(builder.toString());
    File [] files = UtilFile.listFiles(tempFolder, null, comparator);
    if(files == null) return;
    MarkWordDescExtractor descExtractor = new MarkWordDescExtractor(pattern);
    loadArticles(metas, files, descExtractor);

 /*   List<Article> articles = new ArrayList<Article>(DatabaseService.PAGE_SIZE);
    for(int i = 0; i < entries.size(); i++) {
      Article article = toArticle(descExtractor, entries.get(i));
      articles.add(article);
    }
    metas.setData(articles);*/
  }

 /* private List<ContentIndex> searchByQuery1(String textQuery, MetaList metas) throws Exception {
    List<ContentIndex> entries = new ArrayList<ContentIndex>();
    File tempFolder = startSearch(textQuery);
    File [] files = UtilFile.listFiles(tempFolder, null, comparator);
    if(files == null) return entries;

    metas.setTotalPage(files.length / DatabaseService.PAGE_SIZE + 1);
    int page = metas.getCurrentPage();
    int start = (page - 1) * DatabaseService.PAGE_SIZE;
    int end = page * DatabaseService.PAGE_SIZE;

    //    DbCleanerService dbCleaner = new DbCleanerService();
    for(int i = start; i < Math.min(files.length, end); i++) {
      FileInputStream inputStream = null;
      try {
        inputStream = new FileInputStream(files[i]);
        ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
        Document doc = (Document)objectInputStream.readObject();

        ContentIndex contentIndex = new ContentIndex();
        contentIndex.fromDocument(doc);
        entries.add(contentIndex);

        objectInputStream.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      } finally {
        try {
          if(inputStream != null) inputStream.close();
        } catch (Exception e) {
        }
      }
    }
    return entries;
  }*/

  private File startSearch(String textQuery) throws Exception {
    File tempFolder = UtilFile.getFolder("content/search/" + String.valueOf(textQuery.hashCode())+"/");
    File [] files = UtilFile.listFiles(tempFolder);
    if(files != null && files.length > 0 
        && System.currentTimeMillis() - files[0].lastModified() < 15*60*1000l) return tempFolder;

    QueryParser parser = new QueryParser(ContentIndexbak.FIELD_CONTENT, new StandardAnalyzer());
    Query query = parser.parse(textQuery);

    File folder = UtilFile.getFolder("content/cindexed");
    DbCachedSearcher searcher = new DbCachedSearcher(folder, tempFolder);

    searcher.search(query);
    return tempFolder;
  }

  protected Article toArticle(MarkWordDescExtractor buildDesc, ContentIndexbak entry)  {
    Article article = new Article();

    Meta meta = new Meta();
    meta.setId(entry.getId());

    String title  = entry.getTitle();
    if(buildDesc != null) {
      try {
        meta.setTitle(buildDesc.buildTitle(title));
      } catch (Exception e) {
        meta.setTitle(title);
      }
    } else {
      meta.setTitle(title);
    }

    meta.setImage(entry.getImage());
    meta.setTime(entry.getDate());

    if(entry.getDomain() != null) {
      Domain domain = new Domain();
      String [] elements = entry.getDomain().split("\\.");
      if(elements.length > 2) {
        domain.setGroup(elements[0]);
        domain.setCategory(elements[1]);
        domain.setName(elements[2]);
        article.setDomain(domain);
      }
    }

    String desc = entry.getDescription();
    String content = entry.getContent();

    if(buildDesc == null) {
      meta.setDesc(desc);
    } else {
      try {
        meta.setDesc(buildDesc.buildDesc(desc, content, 15));
      } catch (Exception e) {
        meta.setDesc(desc);
      }
    }

    article.setMeta(meta);

    return article;
  }

  private boolean checkSyntax(String value) {
    value = value.toLowerCase();
    if(value.indexOf('\"') > -1) return true;
    if(value.indexOf('+') > -1) return true;
    if(value.indexOf('^') > -1) return true;
    if(value.indexOf("OR") > -1) return true;
    if(value.indexOf("AND") > -1) return true;
    return false;
  }

  private String normalizePattern(String pattern) {
    return "\""+pattern+"\" OR "+ pattern ;
  }

  private void loadArticles(MetaList metas, File [] files, MarkWordDescExtractor descExtractor) {
    metas.setTotalPage(files.length / DatabaseService.PAGE_SIZE + 1);
    int page = metas.getCurrentPage();
    int start = (page - 1) * DatabaseService.PAGE_SIZE;
    int end = page * DatabaseService.PAGE_SIZE;

    //    DbCleanerService dbCleaner = new DbCleanerService();
    List<Article> articles = new ArrayList<Article>(DatabaseService.PAGE_SIZE);

    for(int i = start; i < Math.min(files.length, end); i++) {
      FileInputStream inputStream = null;
      try {
        inputStream = new FileInputStream(files[i]);
        ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
        Document doc = (Document)objectInputStream.readObject();

        ContentIndexbak contentIndex = new ContentIndexbak();
        contentIndex.fromDocument(doc);

        Article article = toArticle(descExtractor, contentIndex);
        articles.add(article);

        objectInputStream.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      } finally {
        try {
          if(inputStream != null) inputStream.close();
        } catch (Exception e) {
        }
      }
    }

    metas.setData(articles);
  }
}


