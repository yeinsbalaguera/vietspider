/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 4, 2008  
 */
class MarkWordDescExtractor {
  
  private Pattern wordPattern = Pattern.compile("\\b[\\p{L}\\p{Digit}]");
  
  private List<String> hightWords = new ArrayList<String>();

  private List<String> lowWords = new ArrayList<String>();
  
  public MarkWordDescExtractor(String pattern) {
    splitHight(pattern);
    splitLow();
  }
  
  public List<String> getHightWords() { return hightWords; }

  public List<String> getLowWords() { return lowWords; }
  
  private void splitLow() {
    for(int i = 0; i < hightWords.size(); i++) {
      String [] elements = hightWords.get(i).split(" ");
      if(elements.length < 2) continue;
      for(String element : elements) {
        if(element.trim().isEmpty()) continue;
        lowWords.add(element);
      }
    }
  }
  
  public String buildTitle(String title) {
    String value = buildTitle(hightWords, title);
    if(value != null) return value;
    value = buildTitle(lowWords, title);
    if(value != null) return value;
    return title;
  }
  
  public String buildTitle(List<String> words, String title) {
    List<Position> positions = getPositions(words, title);
    
    StringBuilder builder = new StringBuilder();
    int start = 0;
    for(int i = 0; i < positions.size(); i++) {
      Position position = positions.get(i);
      builder.append(title.substring(start, position.start));
      builder.append("<span class=\"highlight_word\">");
      builder.append(title.substring(position.start, position.end)).append("</span> ");
      start = position.end + 1;
    }
    
    if(start < 1) return null;
    
    if(start < title.length()) {
      builder.append(title.subSequence(start, title.length())); 
    }
    
    return builder.toString();
  }
  
  public String  buildDesc(String desc, String content, int size) {
    content = desc + " " + content;
    String value  = buildDesc(hightWords, content, size);
    if(value != null) return value;
    value  = buildDesc(lowWords, content, size);
    if(value != null) return value;
    return desc;
  }
  
  private String buildDesc(List<String> words, String value, int size) {
    StringBuilder builder = new StringBuilder();
    List<Position> positions = getPositions(words, value);
    for(int i = 0; i < positions.size(); i++) {
      int start = positions.get(i).getStart();
      if(start < 0) continue;
      int preStart = findStart(value, start, size);
      builder.append("...");
      builder.append(value.subSequence(preStart, start));
      builder.append("<span class=\"highlight_word\">");
      int end  = positions.get(i).getEnd();
      builder.append(value.subSequence(start, end)).append("</span>");
      
      int nextEnd = findEnd(value, end, size);
      if(end < nextEnd) {
        builder.append(value.subSequence(end, nextEnd));
        builder.append("...");
      }
      if(count(builder) > 150) return builder.toString();
    }
    if(builder.length() < 1) return null;
    return builder.toString();
  }
  
  public int count(CharSequence charSeq){
    int start = 0;
    int counter = 0;
    Matcher matcher = wordPattern.matcher(charSeq);
    while(matcher.find(start)) {
      start = matcher.start() + 1;
      counter++;
    }
    return counter;
  }
  
  
  private int findStart(String value, int index, int size) {
    int counter = 0;
    while(index > -1) {
      char c = value.charAt(index);
      if(!Character.isLetterOrDigit(c)) counter++;
      if(counter >= size) return index;
      index--;
    }
    return Math.max(0, index);
  }
  
  private int findEnd(String value, int index, int size) {
    int counter = 0;
    while(index < value.length()) {
      char c = value.charAt(index);
      if(!Character.isLetterOrDigit(c)) counter++;
      if(counter >= size) return index;
      index++;
    }
    return Math.min(index, value.length() - 1);
  }
  
  private List<Position> getPositions(List<String> words, String text) {
    List<Position> positions = new ArrayList<Position>();
    text = text.toLowerCase();
    for(int i = 0; i < words.size(); i++) {
      int index = indexOf(text, words.get(i));
      if(index < 0) continue;
      int end  = index + words.get(i).length();
      Position position = new Position(index, end);
      addPosition(positions, position);
    }
    
    Collections.sort(positions, new Comparator<Position>() {
      public int compare(Position o1, Position o2) {
        if(o1.getEnd() < o2.getStart()) return -1;
        if(o2.getStart() < o1.getEnd()) return 1;
        return 0;
      }
    });
    return positions;
  }
  
  private int indexOf(String text, String word) {
    int start = 0; 
    word = word.trim();
    while(start < text.length()) {
      int index = text.indexOf(word, start);
//      System.out.println(" == >"+ word+ " ; "+ start+ " : "+ index);
      if(index < 0) return -1;
//      System.out.println("|"+text.charAt(index-1)+"|"+Character.isLetterOrDigit(text.charAt(index-1)));
      if(index > 0 
          && Character.isLetterOrDigit(text.charAt(index-1))) {
        start = index + word.length();
        continue;
      }
      int end  = index + word.length();
//      System.out.println("|"+text.charAt(end)+"|"+Character.isLetterOrDigit(text.charAt(end)));
      if(end < text.length()
          && Character.isLetterOrDigit(text.charAt(end))) {
        start = index + word.length();
        continue;
      }
      return index;
    }
    return -1;
  }
  
  private void splitHight(String pattern) {
    pattern = pattern.toLowerCase().trim();
    int start = 0;
    int index = 0; 
    while(index < pattern.length()) {
      char c = pattern.charAt(index);
      if(c == '\"') {
        if(index == 0) {
          start = 1;
        } else {
          String element = pattern.substring(start, index);
          if(!element.trim().isEmpty()) hightWords.add(element);
          start = index+1;
        }
      } else  if( c == 'a') {
        if(index > 0 && index < pattern.length() - 4 
            && pattern.charAt(index+1) == 'n' && pattern.charAt(index+2) == 'd'
              && pattern.charAt(index-1) == ' ' && pattern.charAt(index+3) == ' ') {
          String element = pattern.substring(start, index);
          if(!element.trim().isEmpty()) hightWords.add(element);
          start = index+3;
        }
      } else  if (c == 'o') {
        if(index > 0 && index < pattern.length() - 3
            && pattern.charAt(index+1) == 'r' 
              && pattern.charAt(index-1) == ' ' && pattern.charAt(index+2) == ' ') {
          String element = pattern.substring(start, index);
          if(!element.trim().isEmpty()) hightWords.add(element);
          start = index+2;
        }
      }
      index++;
    }
    
    if(start < pattern.length()) {
      String element = pattern.substring(start, pattern.length());
      if(!element.trim().isEmpty()) hightWords.add(element);
    }
  }
  
  private void addPosition(List<Position> list, Position pos) {
    for (int i = 0; i < list.size(); i++) {
      Position ele  = list.get(i);
      if(pos.start >= ele.start && pos.start <= ele.end) return;
      if(pos.end >= ele.start && pos.end <= ele.end) return;
    }
    list.add(pos);
  }
  
  private static class Position {
    
    private int start;
    private int end;
    
    Position(int s, int e) {
      this.start = s;
      this.end = e;
    }
    
    int getStart() { return start; }
    int getEnd() { return end; }
  }
  
  public static void main(String[] args) {
    
  }
  
}
