/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index2;

import java.util.Calendar;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.headvances.vietspider.CrawlerConfig;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;
import org.vietspider.index.ITextIndex;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 13, 2009  
 */
class ContentIndexbak extends ITextIndex {
  
  final public static String FIELD_DESC = "desc";
  final public static String FIELD_DESC_INDEX = "desc_index";
  final public static String FIELD_CONTENT = "content";
  
  final public static String FIELD_DOMAIN   = "domain" ;
  final public static String FIELD_IMAGE   = "image" ;
  
  private String desc;
  private String content;
  
  private String domain;

  private String image;

  public ContentIndexbak() {
    date = CalendarUtils.getDateFormat().format(Calendar.getInstance().getTime());
    expireDate = CrawlerConfig.EXPIRE_DATE;
    folder = UtilFile.getFolder("content/cindexed");
  }

  public String getDescription(){ return desc; }
  public void setDescription(String desc){ this.desc = desc; }
  public String getContent(){return content;}
  public void setContent(String content){ this.content = content; }
  
  public String getDomain() { return domain; }
  public void setDomain(String domain) { this.domain = domain; }

  public String getImage() { return image; }
  public void setImage(String image) { this.image = image;  }

  @Override
  public void fromDocument(Document document) {
    Field field = document.getField(FIELD_ID);
    id = field.stringValue();
    
    field = document.getField(FIELD_DESC);
    desc = field.stringValue();
    
    field = document.getField(FIELD_CONTENT);
    content = field.stringValue();
    
    field = document.getField(FIELD_DOMAIN);
    if(field != null) domain = field.stringValue();
    
    field = document.getField(FIELD_IMAGE);
    if(field != null)  image = field.stringValue();
    
    field = document.getField(FIELD_TITLE);
    if(field != null) title = field.stringValue();
    
    field = document.getField(FIELD_DATE);
    date = field.stringValue();
  }
  
  @Override
  public Document toDocument() {
    Document doc = createDocument(3.0f);
    
    if(domain != null) {
      doc.add(new Field(FIELD_DOMAIN, domain, Field.Store.YES, Field.Index.NOT_ANALYZED));
    } 
    
    if(image != null) {
      doc.add(new Field(FIELD_IMAGE, image, Field.Store.YES, Field.Index.NOT_ANALYZED));
    }
    
    doc.add(new Field(FIELD_DESC, desc, Field.Store.YES, Field.Index.NOT_ANALYZED));
    
    Field descIndexField = new Field(FIELD_DESC, desc.toLowerCase(), Field.Store.YES, Field.Index.ANALYZED) ;
    descIndexField.setBoost(2.0f) ;
    doc.add(descIndexField);
    
    Field contentField = new Field(FIELD_CONTENT, content.toLowerCase(), Field.Store.YES, Field.Index.ANALYZED) ;
    contentField.setBoost(1.0f) ;
    doc.add(contentField);
    return doc;
  }

}
