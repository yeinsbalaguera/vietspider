/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.idm;

import static org.headvances.vietspider.database.DatabaseService.PAGE_SIZE;

import java.io.EOFException;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import org.headvances.vietspider.database.MetaList;
import org.vietspider.bean.Domain;
import org.vietspider.common.io.LogService;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Dec 24, 2008  
 */
class DefaultEntryIDReader implements EntryIDReader {
  
  @SuppressWarnings("unused")
  public int getTotalPage(Domain domain, int filter) {
    File file  = EIDFolder.getFileName(domain);

    int total = (int) (file.length() / 12);
//    System.out.println(" total "+ total);
    int totalPage = total / PAGE_SIZE ;
//    System.out.println(" total page "+ totalPage);
    if (total % PAGE_SIZE > 0) totalPage++ ;
    return totalPage;
  }
  
  @SuppressWarnings("unused")
  public List<EntryID> readData(Domain domain, MetaList metas, int filter) {
    List<EntryID> entries = new ArrayList<EntryID>();
    File file  = EIDFolder.getFileName(domain);

    int total = (int) (file.length() / 12);
//    System.out.println(" total "+ total);
    int totalPage = total / PAGE_SIZE ;
//    System.out.println(" total page "+ totalPage);
    if (total % PAGE_SIZE > 0) totalPage++ ;
    metas.setTotalPage(totalPage);
    
    int page  = metas.getCurrentPage();

    if(file == null || !file.exists()) return entries;
    RandomAccessFile random = null;
    try {
      random = new RandomAccessFile(file, "r");
      long length  = random.length();
      length = length - length%12;
      
      long min = length - page*12*PAGE_SIZE;
      long max = length - (page-1)*12*PAGE_SIZE;
      if(min < 0) min = 0;
      
      random.seek(min);
      
      while(min < max) {
        long id = -1;
        int st = -1;
        try {
          id = random.readLong();
          st = random.readInt();
        } catch (EOFException e) {
          break;
        }
//        if(filter < 0) {
        entries.add(0, new EntryID(domain, id, st));
//        } else if(filter == st) {
//          entries.add(0, new EntryID(domain, id, st));
//        }
        min += 12;
      }
      
      random.close();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    } finally {
      try {
        if(random != null) random.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    
    return entries;
  }
  
 /* @SuppressWarnings("unused")
  public List<EntryID> readData(Domain domain, MetaList metas, int filter) {
    List<EntryID> entries = new ArrayList<EntryID>();
    File file  = EIDFolder.getFileName(domain);

    int total = (int) (file.length() / 12);
//    System.out.println(" total "+ total);
    int totalPage = total / DatabaseService.PAGE_SIZE ;
//    System.out.println(" total page "+ totalPage);
    if (total % DatabaseService.PAGE_SIZE > 0) totalPage++ ;
    metas.setTotalPage(totalPage);
    
    int page  = metas.getCurrentPage();

    if(file == null || !file.exists()) return entries;
    RandomAccessFile random = null;
    try {
      random = new RandomAccessFile(file, "r");
      long length  = random.length();
      long pos = 0;
      long max = 12*10;
      
      if(page == totalPage) {
        pos = 0;
        max = length  - (totalPage-1)*10*12;
      } else {
        pos = length - page*10*12;
        max = pos + 12*10;
      }
//      System.out.println(page + " : " +pos + " : " + length);
      try {
        random.seek(pos);
      } catch (Exception e) {
        LogService.getInstance().setMessage(e, ", current position is "+ pos);
        return entries;
      }
      
      while(pos < max) {
        long id = random.readLong();
        int st = random.readInt();
//        if(filter < 0) {
        entries.add(0, new EntryID(domain, id, st));
//        } else if(filter == st) {
//          entries.add(0, new EntryID(domain, id, st));
//        }
        pos += 12;
      }
      
      random.close();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    } finally {
      try {
        if(random != null) random.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    
    return entries;
  }*/
}
