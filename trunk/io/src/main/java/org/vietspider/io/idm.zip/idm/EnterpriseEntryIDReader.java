/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.idm;

import static org.headvances.vietspider.database.DatabaseService.PAGE_SIZE;

import java.io.EOFException;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import org.headvances.vietspider.database.DatabaseService;
import org.headvances.vietspider.database.MetaList;
import org.vietspider.bean.Domain;
import org.vietspider.common.io.LogService;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Dec 24, 2008  
 */
class EnterpriseEntryIDReader extends DefaultEntryIDReader {
  
  @Override()
  public List<EntryID> readData(Domain domain, MetaList metas, int filter) {
    List<EntryID> entries = new ArrayList<EntryID>();
    File file  = EIDFolder.getFileName(domain);

    int total = (int) (file.length() / 12);
//    System.out.println(" total "+ total);
    int totalPage = total / DatabaseService.PAGE_SIZE ;
//    System.out.println(" total page "+ totalPage);
    if (total % DatabaseService.PAGE_SIZE > 0) totalPage++ ;
    metas.setTotalPage(totalPage);
    
    int page  = metas.getCurrentPage();

    if(file == null || !file.exists()) return entries;
    RandomAccessFile random = null;
    try {
      random = new RandomAccessFile(file, "r");
      long length  = random.length();
      length = length - length%12;
      
      long min = length - page*12*PAGE_SIZE;
      long max = length - (page-1)*12*PAGE_SIZE;
      if(min < 0) min = 0;
      
     
      random.seek(min);
      
      while(min < max) {
        long id = -1;
        int st = -1;
        try {
          id = random.readLong();
          st = random.readInt();
        } catch (EOFException e) {
          break;
        }
//        System.out.println(st +  " : "+ filter);
        if(filter < 0) {
          entries.add(0, new EntryID(domain, id, st));
        } else if(filter == st) {
          entries.add(0, new EntryID(domain, id, st));
        }
        min += 12;
      }
      
      random.close();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    } finally {
      try {
        if(random != null) random.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    
//    System.out.println("============== > "+entries.size());
    
    return entries;
  }
}
