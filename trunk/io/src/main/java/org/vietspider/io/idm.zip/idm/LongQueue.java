/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.idm;

import java.util.Arrays;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 12, 2008  
 */
class LongQueue {

  private long [] values = new long[10];
  private int size = 0;
  
  public LongQueue() {
  }
  
  public void add(long value) {
    if(size >= values.length) {
      values = Arrays.copyOf(values, values.length+10);
    }
    values[size] = value;
    size++;
  }
  
  public long get(int index) { return values[index]; }
  
  public long[] get() { return Arrays.copyOf(values, size); }

  public int size() { return size; }
}
