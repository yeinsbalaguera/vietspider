/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.idm;

import org.vietspider.bean.Article;
import org.vietspider.bean.Domain;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 8, 2008  
 */
class EntryID {
  
  private Domain domain;
  
  private long id;
  private int status = Article.WAIT;
  
//  private int aaa = 1000000000;
//  int a = 999999999;
  
  EntryID() {
  }
  
  EntryID(Domain domain, String value) {
    this.domain = domain;
    id = Long.parseLong(value);
  }
  
  public EntryID(Domain domain, long id, int st) {
    this.domain = domain;
    this.id = id;
    this.status = st;
  }
  
  public EntryID(long id, int st) {
    this.id = id;
    this.status = st;
  }
  
  public Domain getDomain() { return domain; }
  public void setDomain(Domain domain) { this.domain = domain; }
  
  public long getId() { return id; }
  public void setId(long id) { this.id = id; }
  
  public int getStatus() { return status; }
  public void setStatus(int status) { this.status = status; }
  
}
