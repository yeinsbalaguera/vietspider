/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.idm;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;

import org.vietspider.bean.Article;
import org.vietspider.common.Application;
import org.vietspider.common.Install;
import org.vietspider.common.io.DataWriter;
import org.vietspider.common.io.LogService;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 8, 2008  
 */
class IDTracker extends Thread {

  private final static IDTracker tracker = new IDTracker();

  public final static  IDTracker getInstance() { return tracker; } 

  private volatile boolean execute = true;
  
  private volatile int sleep = 30*1000;

  protected CopyOnWriteArrayList<Long> lastUpdates = new CopyOnWriteArrayList<Long>();
  protected ConcurrentLinkedQueue<EntryID> appends = new ConcurrentLinkedQueue<EntryID>();
  protected ConcurrentLinkedQueue<EntryID> updates = new ConcurrentLinkedQueue<EntryID>();
  protected HashMap<String, RandomAccessFile> randomFiles = new HashMap<String, RandomAccessFile>();

  public IDTracker() {
    Application.addShutdown(new Application.IShutdown() {
      public void execute() {
        execute = false;
        try {
          write();
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }
      }
    });
    if(Application.LICENSE == Install.SEARCH_SYSTEM) sleep = 2*60*1000;
    start();
  }

  public void append(EntryID entry) { 
    appends.add(entry);
    while(lastUpdates.size() >= 10) {
      lastUpdates.remove(lastUpdates.size()-1);
    }
    lastUpdates.add(entry.getId());
  }
  
  public void update(String metaId, int status) {
    try {
      updates.add(new EntryID(Long.parseLong(metaId), status));  
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }

  public void delete(String date) {
    try {
      File [] files = EIDFolder.getFileByDates(date);
      for(File file : files) {
        file.delete();
      }
    } catch (Exception e) {
      return;
    }
  }

  public void run() {
    while(execute) {
      try {
        write();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
      try {
        Thread.sleep(sleep);
      } catch (Exception e) {
      }
    }
    try {
      write();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }

  private void write() {
    HashMap<String, RandomAccessFile> randoms = new HashMap<String, RandomAccessFile>();
    
    if(!appends.isEmpty()) append(randoms);

    while(!updates.isEmpty()) {
      EntryID entry = updates.poll();
      if(entry == null) break;
      update(randoms, entry);
    }

    Iterator<String> iterator = randoms.keySet().iterator();
    while(iterator.hasNext()) {
      String file = iterator.next();
      RandomAccessFile random = randoms.get(file);
      try {
        if(random != null) random.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
  }
  
  private void update(HashMap<String, RandomAccessFile> tempFiles, EntryID entry) {
    File [] files = EIDFolder.getFiles(String.valueOf(entry.getId()));

    if(files == null || files.length < 1) return;
    RandomAccessFile [] randoms = new RandomAccessFile[files.length];
    for(int i = 0; i < files.length; i++) {
      randoms[i] = EIDFolder.getRandom(tempFiles, files[i]);;
    }

    for(int i = 0; i < randoms.length; i++) {
      boolean create = update(files[i], randoms[i], entry);
      if(!create) continue;
      try {
        randoms[i].close();
      } catch (Exception e) {
      }
      try {
        randoms[i] =  new RandomAccessFile(files[i], "rws");
        tempFiles.put(files[i].getName(), randoms[i]);
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
  }

  private boolean update(File file, RandomAccessFile random, EntryID entry) {
    if(random == null) return false;
    try {
      random.seek(0);
      long length = random.length(); 
      while(random.getFilePointer() <= length - 8) {
        long value = random.readLong();
        if(value == entry.getId()) {
          if(entry.getStatus() == -1) {
//          System.out.println(" prepare delete "+ value+ " on position " + (random.getFilePointer()-8));
//          System.out.println(" before delete "+ file.getName()+ " : "+ file.length());
            new DataWriter().delete(file, random.getFilePointer() - 8, 12);
//          System.out.println(" after delete "+ file.getName()+ " : "+ file.length());
            return true;
          } 
          long statusPos = random.getFilePointer();
          int status = random.readInt();
          if(status < entry.getStatus() || entry.getStatus() > 1) {
            random.seek(statusPos);
            random.writeInt(entry.getStatus());
          }
          return false;
        } 
        random.readInt();
      }
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
    return false;
  }
  
  private void append(HashMap<String, RandomAccessFile> randoms) {
    int idx = 0;
    EntryID [] entries = new EntryID[appends.size()];
    while(!appends.isEmpty()) {
      if(idx >= entries.length) break;
      entries[idx] = appends.poll();
      idx++;
    }
    
    HashMap<String, LongQueue> queue = new HashMap<String, LongQueue>();
    for(EntryID entry : entries) {
      if(entry == null) continue;
      String [] fileNames = EIDFolder.getFileNames(entry.getDomain());
      if(fileNames == null || fileNames.length < 2) return;
      for(String fileName : fileNames) {
        LongQueue longQueue = queue.get(fileName);
        if(longQueue == null)  {
          longQueue = new LongQueue();
          queue.put(fileName, longQueue);  
        } 
        longQueue.add(entry.getId());
      }
    }
    Iterator<String> iterator = queue.keySet().iterator();
    while(iterator.hasNext()) {
      String fileName = iterator.next();
      append(randoms, fileName, queue.get(fileName));
    }
    //end
  }
  
  private void append(HashMap<String, RandomAccessFile> randoms, String fileName, LongQueue longQueue) {
    RandomAccessFile random = EIDFolder.getRandom(randoms, fileName);
    if(random == null) return;
    long length = 0;
    try {
      length = random.length();
      length = length - length%12;
      random.seek(length);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      return;
    }
    
    long [] values = longQueue.get();
    Arrays.sort(values);
    
//    System.out.println("bat dau ghi "+ fileName +" : "+ values.length);
    
    /*if(values.length < 5) {
      for(long value : values) {
        try {
          random.writeLong(value);
          random.writeInt(Article.WAIT);
          length += 12;
        } catch (Exception e) {
          try {
            random.seek(length);
          } catch (Exception e2) {
            LogService.getInstance().setThrowable(e);
          }
        }

      }
      return;
    }*/

    FileChannel channel = null;
    try {
      channel = random.getChannel();
      ByteBuffer buff = ByteBuffer.allocateDirect(values.length*12);
      for(long value : values){
        buff.putLong(value);
        buff.putInt(Article.WAIT);
      }
      
      buff.rewind();
      if(channel.isOpen()) channel.write(buff);
      buff.clear();
      
      channel.close();
      random.close();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    } finally {
      try {
        if(channel != null) channel.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
  }
  
  public String getLastUpdates() {
    StringBuilder builder = new StringBuilder();
    Iterator<Long> iterator = lastUpdates.iterator();
    while(iterator.hasNext()) {
      if(builder.length() > 0) builder.append(',');
      builder.append(iterator.next());
      iterator.remove();
    }
    if(builder.length() < 1) builder.append(200907011604189l);
    return builder.toString();
  }


}
