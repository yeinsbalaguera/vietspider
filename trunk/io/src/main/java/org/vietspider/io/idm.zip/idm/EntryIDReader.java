/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.idm;

import java.util.List;

import org.headvances.vietspider.database.MetaList;
import org.vietspider.bean.Domain;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Dec 24, 2008  
 */
public interface EntryIDReader {
  
  /*
   * filter dung de loc  noi dung: 
   *  -da doc,
   *  -chua doc, 
   *  -toan bo, 
   *  -da synchronized hay chu
   */
  
  public int getTotalPage(Domain domain, int filter);
  
  public List<EntryID> readData(Domain domain, MetaList metas, int filter);

}
