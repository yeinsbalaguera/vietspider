/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.idm;

import java.io.File;
import java.io.FileFilter;
import java.io.RandomAccessFile;
import java.util.Date;
import java.util.HashMap;

import org.vietspider.bean.Domain;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;
import org.vietspider.common.text.NameConverter;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 12, 2008  
 */
final class EIDFolder {
  
  private final static String EID_FOLDER = "content/summary/eid/"; 
  
  static final File [] getFiles(String metaId) {
    if(metaId.length() < 9) return null;
    String year = metaId.substring(0, 4);
    String month = metaId.substring(4, 6);
    String date = metaId.substring(6, 8);

    String folderName = year + "_" + month + "_" + date;
    final String startWith = folderName + ".";
    File folder = UtilFile.getFolder(EID_FOLDER + folderName+"/");
    return  folder.listFiles(new FileFilter() {
      public boolean accept(File f) {
        return f.getName().startsWith(startWith) && f.isFile();
      }
    });
  }
  
  static final File[] getFileByDates(String date) throws Exception {
    final String startWith = date+".";
    File folder = UtilFile.getFolder(EID_FOLDER + date+"/");
    return folder.listFiles(new FileFilter() {
      public boolean accept(File f) {
        return f.getName().startsWith(startWith) && f.isFile();
      }
    });
  }
  
  static final String [] getFileNames(Domain domain) {
    String date = null;
    try {
      Date dateValue = CalendarUtils.getDateFormat().parse(domain.getDate());
      date = CalendarUtils.getFolderFormat().format(dateValue);
    } catch (Exception e) {
      return null;
    }
    if(date == null) return null;
    String group = domain.getGroup();
    NameConverter nameConverter = new NameConverter();
    String category = nameConverter.encode(domain.getCategory());
    String name = nameConverter.encode(domain.getName());
    return new String[] {
        date + "/" + date + ".eid",
//      date + "." + group + ".eid",
        date + "/" + date + "." + group + "."+ category + ".eid",
        date + "/" + date + "." + group + "."+ category + "." + name + ".eid"
    };
  }
  
  final static File getFileName(Domain domain) {
    if(domain.getDate() == null) return null;
    String date = null;
    try {
      Date dateValue = CalendarUtils.getDateFormat().parse(domain.getDate());
      date = CalendarUtils.getFolderFormat().format(dateValue);
    } catch (Exception e) {
      return null;
    }
    if(date == null) return null;
    File folder = UtilFile.getFolder(EID_FOLDER + date + "/");
//    String group = domain.getGroup();
//    System.out.println(group);
//    if(group == null) return  date + ".eid";
    
    if(domain.getCategory() == null) return new File(folder, date + ".eid");
    NameConverter nameConverter = new NameConverter();
    String category = nameConverter.encode(domain.getCategory());
    
    if(domain.getName() == null) {
      return  new File(folder, date + "."+ category + ".eid");
    }
    String name = nameConverter.encode(domain.getName());
    return new File(folder, date + "." + category + "." + name + ".eid");
  }
  
  final static RandomAccessFile getRandom(HashMap<String, RandomAccessFile> files, String fileName) {
    RandomAccessFile random = files.get(fileName);
    if(random == null) {
      File file  = UtilFile.getFile(EID_FOLDER + "/", fileName);
      try {
        random = new RandomAccessFile(file, "rws");
        files.put(fileName, random);
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    return random;
  }
  
  final static RandomAccessFile getRandom(HashMap<String, RandomAccessFile> files, File file) {
    RandomAccessFile random = files.get(file.getName());
    if(random == null) {
      try {
        random = new RandomAccessFile(file, "rws");
        files.put(file.getName(), random);
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    return random;
  }

}
