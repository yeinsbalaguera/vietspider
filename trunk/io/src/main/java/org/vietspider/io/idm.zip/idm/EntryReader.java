/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.idm;

import java.util.List;

import org.headvances.vietspider.database.DatabaseReader;
import org.headvances.vietspider.database.DatabaseService;
import org.headvances.vietspider.database.MetaList;
import org.vietspider.bean.Article;
import org.vietspider.bean.Domain;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 8, 2008  
 */
class EntryReader {
  
  public EntryReader() {
  }
  
  public void read(Domain domain, MetaList metas, int filter) throws Exception {
    List<EntryID> entries = readData(domain, metas, filter/*page_, metas.getTotalPage()*/);
//    System.out.println(" da co o day roi "+ entries.size());
    
    int size = entries.size();
//    System.out.println(" ===  > "+ size);
    int page_ = metas.getCurrentPage();
    while(size < 10 && page_ < metas.getTotalPage()) {
      metas.setCurrentPage(page_+1);
      entries.addAll(readData(domain, metas, filter));
      size = entries.size();
      page_ = metas.getCurrentPage();
    }
    
    if(entries.size() < 1) return;
    
    String [] metaIds = new String[entries.size()];
    for(int i = 0; i < entries.size(); i++) {
      metaIds[i] = String.valueOf(entries.get(i).getId());
    }
    
    DatabaseReader getter = DatabaseService.getLoader();
    metas.setData(getter.loadArticles(metaIds));
    
    //filter:1
    List<Article> articles = metas.getData();
    
    if(size < 1) return;
    if(size == entries.size()) {
      for(int i = 0; i < Math.min(size, articles.size()); i++) {
        Article article = articles.get(i);
        article.setStatus(entries.get(i).getStatus());
      }
      return;
    } 
    
    for(int i = 0; i < size; i++) {
      Article article = articles.get(i);
      EntryID entryID = searchEntry(article.getMeta().getId(), entries);
      if(entryID == null) continue;
      article.setStatus(entryID.getStatus());
    }
//    System.out.println(" truoc khi thu nghiem "+ metas.getData().size()+ "  trong khi "+ metaIds.length);
  }
  
  private EntryID searchEntry(String metaId, List<EntryID> entries) {
    long value = Long.parseLong(metaId);
    for(int i = 0; i < entries.size(); i++) {
      if(value == entries.get(i).getId()) return entries.get(i);
    }
    return null;
  }
  
  public int getTotalPage(Domain domain, int filter) {
    EntryIDReader idReader  = null;
    if(filter > -1) {
      idReader = new EnterpriseEntryIDReader();
    } else {
      idReader = new DefaultEntryIDReader();
    }
    return idReader.getTotalPage(domain, filter);
  }
  
  public List<EntryID> readData(Domain domain, MetaList metas, int filter) {
    EntryIDReader idReader  = null;
    if(filter > -1) {
      idReader = new EnterpriseEntryIDReader();
    } else {
      idReader = new DefaultEntryIDReader();
    }
    return idReader.readData(domain, metas, filter);
  }
}
