package org.sf.feeling.swt.win32.internal.extension;

public class MIXERLINEW extends MIXERLINE
{

	private static final long serialVersionUID = -7222726553224199410L;

	public char[] szShortName = new char[16];

	public char[] szName = new char[64];

	public static int sizeof = 280;
}
