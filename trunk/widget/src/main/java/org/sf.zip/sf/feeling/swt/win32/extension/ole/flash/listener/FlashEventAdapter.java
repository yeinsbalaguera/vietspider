package org.sf.feeling.swt.win32.extension.ole.flash.listener;

public class FlashEventAdapter implements FlashEventListener {

	public void onFSCommand(String command, String args) {
		// TODO Auto-generated method stub

	}

	public void onProgress(int percentDone) {
		// TODO Auto-generated method stub

	}

	public void onReadyStateChange(int newState) {
		// TODO Auto-generated method stub

	}

}
