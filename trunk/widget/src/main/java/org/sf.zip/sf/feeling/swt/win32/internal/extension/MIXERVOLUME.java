package org.sf.feeling.swt.win32.internal.extension;

public class MIXERVOLUME
{
	public int leftChannelVolume;

	public int rightChannelVolume;

	public boolean isMute = true;
}
