/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.sf.feeling.swt.win32.extension.widgets;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.sf.feeling.swt.win32.extension.widgets.theme.ThemeRender;
import org.vietspider.generic.ColorCache;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jul 6, 2009  
 */
abstract class CAbstractButton extends Canvas {
  
  String text = "";
  protected Image image;
  protected Font font;
//  protected Canvas button;
  protected CMenu menu;
  MenuControl popupMenu;
  
  ThemeRender theme;
  
  protected boolean menuTracked;

  protected boolean visible = true;
  protected boolean enabled = true;
  protected boolean selected = false;
  
  protected int style = SWT.NONE;

  protected  boolean selection = false;
  
  private List<SelectionListener> listeners;
  
  public CAbstractButton(Composite parent, int style) {
    super(parent, style);
  }
  
  public boolean isVisible() { return visible; }

  public boolean isEnabled() { return enabled; }
  public void setEnabled(boolean enabled) { 
    this.enabled = enabled; 
    redraw();
  }
  
  public Font getFont() { return font; }
  public void setFont(Font font) { this.font = font; }
  
  public String getText() { return text; }
  public void setText(String text) {
    if (text == null) text = "";
    this.text = text;
  }
  
  public void setVisible(boolean visible)  {
    this.visible = visible;
  }

  public void setCMenu(CMenu menu) { this.menu = menu; }
  public CMenu getCMenu() { return menu; }
  
  boolean isShowMenu() {
    return popupMenu != null && !popupMenu.getShell().isDisposed();
  }

//  public void refresh() {
//    if (button != null && !button.isDisposed()) button.redraw();
//  }

  public Image getImage() { return image; }
  public void setImage(Image image) { this.image = image; }

  public int getStyle() { return style; }

  public boolean getSelection() { return selection; }
  public void setSelection(boolean selection) { this.selection = selection; }

  public boolean canSelected()  {
    if (getMenu() == null) return true;
    return listeners != null;
  }

  public void addSelectionListener(SelectionListener listener) {
    if (isDisposed()) return;
    if (listener == null) return;
    if (listeners == null) listeners = new ArrayList<SelectionListener>();
    if (!listeners.contains(listener)) listeners.add(listener);
  }

  public void removeSelectionListener(SelectionListener listener) {
    if (isDisposed()) return;
    if (listener == null) return;
    listeners.remove(listener);
    if (listeners != null && listeners.size() == 0) listeners = null;
  }

  void fireSelectionEvent(final Event event) {
    if (isDisposed()) return;
    if (listeners != null) {
      final SelectionEvent selectEvent = new SelectionEvent(event);
      for (int i = 0; i < listeners.size(); i++) {
        final SelectionListener listener = listeners.get(i);
        Display.getDefault().asyncExec(new Runnable() {
          public void run() {
            listener.widgetSelected(selectEvent);
          }
        });
      }
    }
  }
  
//  public Control getControl() { return button; }
//  
//  public void setLocation(Point location) {
//    if (button != null && !button.isDisposed()) button.setLocation(location);
//  }
//
//  public void setSize(Point size) {
//    if (button != null && !button.isDisposed()) button.setSize(size);
//  }
//
//  public void setBounds(Rectangle bound) {
//    if (button != null && !button.isDisposed()) button.setBounds(bound);
//  }
//
//  public Point getLocation() {
//    if (button != null && !button.isDisposed()) return button.getLocation();
//    return null;
//  }
//
//  public Point getSize() {
//    if (button != null && !button.isDisposed()) return button.getSize();
//    return null;
//  }
//
//  public Rectangle getBounds() {
//    if (button != null && !button.isDisposed()) {
//      return button.getBounds();
//    }
//    return null;
//  }

//  public Point computeSize(int wHint, int hHint) {
//    if (button != null && !button.isDisposed()) return button.computeSize(wHint, hHint);
//    return null;
//  }
  
  public void disposed() {
    listeners.clear();
    listeners = null;
    super.dispose();
  }

}
