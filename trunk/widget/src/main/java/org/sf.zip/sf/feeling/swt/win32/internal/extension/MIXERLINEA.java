package org.sf.feeling.swt.win32.internal.extension;

public class MIXERLINEA extends MIXERLINE
{

	private static final long serialVersionUID = -550097789105673070L;

	public byte[] szShortName = new byte[16];

	public byte[] szName = new byte[64];

	public static int sizeof = 168;
}
