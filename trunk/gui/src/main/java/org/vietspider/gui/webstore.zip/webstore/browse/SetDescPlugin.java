/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.webstore.browse;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.vietspider.bean.website.Website;
import org.vietspider.client.ClientPlugin;
import org.vietspider.gui.webstore.WebsiteHandler;
import org.vietspider.ui.XPWidgetTheme;
import org.vietspider.ui.services.ClientRM;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 3, 2009  
 */
public class SetDescPlugin extends ClientPlugin {
  
  private String lbl = "Set Description";
  
  public SetDescPlugin() {
    ClientRM resources = new ClientRM("WebsiteStore");
    lbl = resources.getLabel("set.desc");
  }

  public String getLabel() { return lbl; }

  public void innvoke(Object... objects) {
    if( !(objects[1] instanceof BrowserExplorer)) return;
    final BrowserExplorer browser = (BrowserExplorer) objects[1];
    Shell parent = browser.getShell();
    Shell   shell = new Shell(parent, SWT.CLOSE);
    shell.setImage(parent.getImage());
    
    RowLayout rowLayout = new RowLayout();
    shell.setLayout(rowLayout);
    rowLayout.justify = true;
    rowLayout.spacing  = 5;

    String [] descs = new String []{
        "profile", "lyric", "story", "poetry", "searchtionary",
        "classified",  "job", "blog",
        "article", "forum", "product"
    };

    Button [] butDescs = new Button[descs.length];
    for(int i = 0; i  < descs.length; i++) {
      butDescs[i] = new Button(shell, SWT.PUSH);
      butDescs[i].addSelectionListener(new SelectionAdapter() {
        public void widgetSelected(SelectionEvent e) {
          WebsiteHandler handler = browser.getHandler();
          int currentIndex = browser.getCurrentIndex();
          Table tableWebsite = browser.getTableWebsite();
          
          String text = ((Button)e.widget).getText();
          Website website = handler.createWebsite(currentIndex);
          website.setDesc(text);
          TableItem tableItem = tableWebsite.getItem(currentIndex);
          tableItem.setText(5, text);
          handler.saveWebsite(website);
          browser.next();
        }
      });
      butDescs[i].setText(descs[i]);
    }
    shell.setSize(600, 70);
    int x = parent.getLocation().x + parent.getSize().x - shell.getSize().x;
    int y = parent.getLocation().y + parent.getSize().y - shell.getSize().y;
    shell.setLocation(x, y);
//    XPWidgetTheme.setWin32Theme(shell);
    shell.setVisible(true);

  }

  @SuppressWarnings("unused")
  public boolean isValidType(int type) { return true; }

}
