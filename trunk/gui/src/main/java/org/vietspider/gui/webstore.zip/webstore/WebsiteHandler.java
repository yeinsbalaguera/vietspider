/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.webstore;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.vietspider.bean.website.Website;
import org.vietspider.bean.website.Websites;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.client.common.DataClientHandler;
import org.vietspider.common.util.Worker;
import org.vietspider.gui.workspace.Workspace;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Apr 20, 2009  
 */
public class WebsiteHandler extends DataMonitor {
  
  protected Table tableWebsite;  
  protected List<Website> listWebsites;
  
  protected TableEditor [] ignoreEditors;
  protected TableEditor [] webEditors;
//  protected TableEditor [] langEditors;
  
  WebsiteHandler(Composite parent, Workspace workspace) {
    super(parent, workspace);
  }
  
  public void setBlogSite(TableItem...items) {
    if(items == null || items.length < 1) return;
    for(int i = 0; i < items.length; i++) {
      Website website = createWebsite(items[i]);
      website.setSource("BLOG_SITE");
      website.setStatus(Website.CONFIGURATION);
      saveWebsite(website);
      disableItem(items[i]);
    }
  }
  
  public void setIsWebsite(String charset, final TableItem...items) {
    for(int i = 0; i < items.length; i++) {
      setIsWebsiteItem(items[i], charset);
    }
  }
  
  void setIsWebsiteItem(final TableItem item, final String charset) {
    if(webEditors == null) return;
    TableItem [] items = tableWebsite.getItems(); 
    for(int i = 0; i < items.length; i++) {
      if(items[i]  != item) continue;
      final Button button = (Button)webEditors[i].getEditor();
      if(!button.isEnabled()) continue;
      button.setSelection(!button.getSelection());
      final TableEditor editor = ignoreEditors[i];
      Runnable timer = new Runnable () {
        public void run () {
          setIsWebsite(item, editor, button, charset);
        }
      };
      getDisplay().timerExec (3*1000, timer);
      break;
    }
  }
  
  void setIsWebsite(TableItem item, TableEditor editor, Button button, String charset) {
    if(button.isDisposed() || !button.getSelection()) return;
    Website website = createWebsite(item);
    website.setSource("SITE");
    website.setStatus(Website.CONFIGURATION);
    if(charset != null 
        && !charset.trim().isEmpty()) {
      website.setCharset(charset);
    }
    saveWebsite(website);
    button.setEnabled(false);
    editor.getEditor().setEnabled(false);
    item.setBackground(new Color(item.getDisplay(), 222, 255, 255));
  }
  
  
  public void setIgnoreWebsite(final TableItem...items) {
    for(int i = 0; i < items.length; i++) {
      setIgnoreWebsite(items[i]);
    }
  }
  
  void setIgnoreWebsite(final TableItem item) {
    if(ignoreEditors == null) return;
    TableItem [] items = tableWebsite.getItems(); 
    for(int i = 0; i < items.length; i++) {
      if(items[i]  != item) continue;
      final Button button = (Button)ignoreEditors[i].getEditor();
      if(!button.isEnabled()) continue;
      button.setSelection(!button.getSelection());
      final TableEditor editor = webEditors[i];
      Runnable timer = new Runnable () {
        public void run () {
          setIgnoreWebsite(item, editor, button);
        }
      };
      getDisplay().timerExec (3*1000, timer);
    }
  }
  
  void setIgnoreWebsite(TableItem item, TableEditor editor, Button button) {
    if(button.isDisposed() || !button.getSelection()) return;
    Website website = createWebsite(item);
    website.setStatus(Website.UNAVAILABLE);
    saveWebsite(website);
    button.setEnabled(false);
    editor.getEditor().setEnabled(false);
    item.setBackground(new Color(item.getDisplay(), 255, 222, 222));
  }
  
  void disableItem(TableItem item) {
    TableItem [] items = tableWebsite.getItems(); 
    for(int i = 0; i < items.length; i++) {
      if(items[i]  != item) continue;
      Button button = (Button)webEditors[i].getEditor();
      button.setEnabled(false);
      
      button = (Button)ignoreEditors[i].getEditor();
      button.setEnabled(false);
    }
  }
  
  public void addHomepage(String link, TableItem...items) {
    if(items.length < 1) return;
    for(int i = 0; i < items.length; i++) { 
      Website website = createWebsite(items[i]);
      try {
        URL url = new URL(link);
        
        List<String> list = new ArrayList<String>();
        String [] homepages = website.getHomepages();
        Collections.addAll(list, homepages);
        list.add(url.toString());
        
        website.setHomepages(list.toArray(new String[list.size()]));
        
        saveWebsite(website);
      } catch (Exception e) {
        ClientLog.getInstance().setException(getShell(), e);
      }
    }
  }
  
  public void saveWebsite(Website website) {
    if(website == null) return;
    Websites websites = new Websites();
    websites.getList().add(website);
    saveWebsites(websites);
  }
  
  void saveWebsites(final Websites websites) {
    for(int i = 0; i < websites.getList().size(); i++) {
      Website website = websites.getList().get(i);
      if(website.getAddress() == null 
          || website.getAddress().trim().isEmpty()) {
        ClientLog.getInstance().setMessage(
            tableWebsite.getShell(), new Exception("no address at "+ String.valueOf(i)));
        return;
      }
    }

    Worker excutor = new Worker() {

      private String error;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {}

      public void execute() {
        try {
          new DataClientHandler().saveWebsites(websites);
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(tableWebsite.getShell(), new Exception(error));
          return;
        }

      }
    };
    new ThreadExecutor(excutor, tableWebsite.getShell()).start();
  }
  
  protected Website createWebsite(TableItem item) {
    TableItem [] items = tableWebsite.getItems();
    for(int i = 0;  i < items.length; i++) {
      if(items[i] == item) return createWebsite(i);
    }
    return null;
  }

  public Website createWebsite(int index) {
    if(listWebsites == null) return null;
    if(index < 0 || index >= listWebsites.size()) return null;
    Website website = listWebsites.get(index);
    return website;
  }
  
  Table getTableWebsite() { return tableWebsite;}

  
}
