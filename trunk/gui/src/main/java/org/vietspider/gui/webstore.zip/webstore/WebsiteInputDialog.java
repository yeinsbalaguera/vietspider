/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.webstore;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.prefs.Preferences;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.HTMLTransfer;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.common.Application;
import org.vietspider.common.text.SWProtocol;
import org.vietspider.common.util.Worker;
import org.vietspider.gui.workspace.XPWindowTheme;
import org.vietspider.html.HTMLDocument;
import org.vietspider.html.HTMLNode;
import org.vietspider.html.Name;
import org.vietspider.html.NodeIterator;
import org.vietspider.html.parser.HTMLParser2;
import org.vietspider.net.server.URLPath;
import org.vietspider.token.attribute.Attribute;
import org.vietspider.token.attribute.Attributes;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.waiter.WaitLoading;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 21, 2008  
 */
public class WebsiteInputDialog {
  
  protected Shell shell;
  
  private Text txtDialog;
  
  public WebsiteInputDialog(Shell parent) {
    shell = new Shell(parent, SWT.RESIZE | SWT.MODELESS | SWT.TITLE | SWT.CLOSE);
    shell.setImage(parent.getImage());
    
    shell.setLayout(new GridLayout(1, true));
    shell.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WIDGET_BACKGROUND));
    
    shell.addShellListener(new ShellAdapter(){
      @SuppressWarnings("unused")
      public void shellDeactivated(ShellEvent e) {
        saveShellProperties();
      }
    });
    
    parent.addDisposeListener(new DisposeListener() {
      @SuppressWarnings("unused")
      public void widgetDisposed(DisposeEvent arg0) {
        shell.dispose();
      }
    });
    
    loadShellProperties();
    
    txtDialog = new Text(shell, SWT.MULTI | SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
    GridData gridData = new GridData(GridData.FILL_BOTH);
    txtDialog.setLayoutData(gridData);
    txtDialog.addKeyListener(new KeyAdapter() {
      
      private boolean paste = false;
      
      public void keyReleased(KeyEvent event) {
        if(event.keyCode == SWT.MOD1) paste = false;
      }
      
      public void keyPressed(KeyEvent event) {
        if(event.keyCode == SWT.MOD1) {
          paste = true;
          return;
        }
        if(!paste || event.keyCode != 'v') return ;
        final int time = 1000;
        Runnable timer = new Runnable () {
          public void run () {
            paste();
          }
        };
        txtDialog.getDisplay().timerExec (time, timer);
      }
      
    });
    
    Composite bottom = new Composite(shell, SWT.NONE);
    gridData = new GridData(GridData.HORIZONTAL_ALIGN_END);
    gridData.widthHint = 700;
    bottom.setLayoutData(gridData);
    RowLayout rowLayout = new RowLayout();
    bottom.setLayout(rowLayout);
    rowLayout.justify = true;
    
    Composite composite = new Composite(bottom, SWT.NONE);
    composite.setLayout(new GridLayout(2, false));
    
    Button butDelete  = new Button(bottom, SWT.BORDER);
    butDelete.addSelectionListener(new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        txtDialog.setText("");
      }      
    });
    butDelete.setText("Clear");
    
    Button butFilter  = new Button(bottom, SWT.BORDER);
    butFilter.addSelectionListener(new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        filter(txtDialog.getText());
      }      
    });
    butFilter.setText("Filter"); 
    
    Button butSave  = new Button(bottom, SWT.BORDER);
    butSave.addSelectionListener(new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        filter(txtDialog.getText());
        String text = txtDialog.getText().trim();
        if(text.isEmpty()) return;
        save();
      }      
    });
    butSave.setText("Save"); 
    
    loadWait();
//    XPWindowTheme.setWin32Theme(shell);
    shell.open();
  }
  
  private void paste() {
    Clipboard clipboard = new Clipboard(txtDialog.getDisplay());
    HTMLTransfer transfer = HTMLTransfer.getInstance();
    String text = (String)clipboard.getContents(transfer);
    
    if(text == null || text.trim().isEmpty()) {
      TextTransfer transfer2 = TextTransfer.getInstance();
      text = (String)clipboard.getContents(transfer2);
    }
    
    if(text == null || text.trim().isEmpty()) return;
    
    filter(text);
  }
  
  protected void saveShellProperties() {
    Preferences prefs2 = Preferences.userNodeForPackage(getClass());
    Point point = shell.getLocation();
    Point size = shell.getSize();
    try {
      prefs2.put("URLHomepageDialog_location_x", String.valueOf(point.x));
      prefs2.put("URLHomepageDialog_location_y", String.valueOf(point.y));
      prefs2.put("URLHomepageDialog_size_w", String.valueOf(size.x));
      prefs2.put("URLHomepageDialog_size_h", String.valueOf(size.y));
    } catch (Exception e) {
    }
  }
  
  private void filter(String text) {
    if(text.startsWith("waiting data...")) {
      txtDialog.setText("");
      return;
    }
    
    if(text.indexOf('>') < 0 || text.indexOf('>') < 0) return;
    HTMLDocument document = null;
    try {
      document = new HTMLParser2().createDocument(text);
    } catch (Exception e) {
      ClientLog.getInstance().setException(shell, e);
      return;
    }
    if(document == null) return;
    
    List<String> list  = new ArrayList<String>();
    NodeIterator iterator = document.getRoot().iterator();
    while(iterator.hasNext()) {
      HTMLNode node = iterator.next();
      if(!node.isNode(Name.A)) continue;
      Attributes attributes = node.getAttributes(); 
      Attribute attribute = attributes.get("href");
      if(attribute == null) continue;
      String value = attribute.getValue();
      if(value == null) continue;
      value = value.toLowerCase();
      if(!SWProtocol.isHttp(value)) value = "http://" + value;
      if(value.indexOf('.') < 0) continue;
      try {
        new URL(value);
        list.add(value);
      } catch (Exception e) {
      }
    }
    Collections.sort(list);
    
    StringBuilder builder = new StringBuilder();
    for(String ele : list) {
      builder.append(ele).append('\n');
    }
    txtDialog.setText(builder.toString().trim());
  }
  
  protected void loadShellProperties() {
    Shell parent = shell.getShell();
    Preferences prefs = Preferences.userNodeForPackage(getClass());
    int x,y;
    int width, height;
    try {
      x = Integer.parseInt(prefs.get("URLHomepageDialog_location_x", ""));
    } catch (Exception e) {
      x = parent.getLocation().x + 300;
    }
    
    try {
      width = Integer.parseInt(prefs.get("URLHomepageDialog_size_w", ""));
    } catch (Exception e) {
      width = 600;
    }
    
    try {
      y = Integer.parseInt(prefs.get("URLHomepageDialog_location_y", ""));
    } catch (Exception e) {
      y = parent.getLocation().y + 100;
    }
    
    try {
      height = Integer.parseInt(prefs.get("URLHomepageDialog_size_h", ""));
    } catch (Exception e) {
      height = 450;
    }
    
    shell.setLocation(x, y);
    shell.setSize(width, height);
  }
  
  protected void save() {
    Worker excutor = new Worker() {
      
      private Exception exception;
      private String value;

      public void abort() {}

      public void before() {
        value = txtDialog.getText();
      }

      public void execute() {
        if(value.trim().isEmpty()) return;
        try {
          Header [] headers = new Header[] {
              new BasicHeader("action", "save.website.urls")
          };
          
          ClientConnector2 connector = ClientConnector2.currentInstance();
          byte [] bytes = value.getBytes(Application.CHARSET);
          connector.post(URLPath.DATA_HANDLER, bytes, headers);
        } catch (Exception e) {
          exception = e;
        }
      }

      public void after() {
        if(exception != null) {
          ClientLog.getInstance().setException(shell, exception);
          return;
        }
        txtDialog.setText("");
      }
    };
    new WaitLoading(shell, excutor, SWT.TITLE).open();
  }
  
  protected void loadWait() {
    Worker excutor = new Worker() {
      
      private Exception exception;
      private String value;

      public void abort() {}

      public void before() {
      }

      public void execute() {
        try {
          Header [] headers = new Header[] {
              new BasicHeader("action", "load.wait.website.list")
          };
          
          ClientConnector2 connector = ClientConnector2.currentInstance();
          byte [] bytes = connector.post(URLPath.DATA_HANDLER, new byte[0], headers);
          value = new String(bytes, Application.CHARSET);
        } catch (Exception e) {
          exception = e;
        }
      }

      public void after() {
        if(exception != null) {
          ClientLog.getInstance().setException(shell, exception);
          return;
        }
        txtDialog.setText("waiting data...\n"+value);
      }
    };
    new WaitLoading(shell, excutor, SWT.TITLE).open();
  }
  
  public Text getTxtDialog() { return txtDialog; }

  public Shell getShell() { return shell; }
 
}
