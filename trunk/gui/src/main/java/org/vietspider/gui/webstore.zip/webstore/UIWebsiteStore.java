/***************************************************************************
 * Copyright 2003-2006 by VietSpider - All rights reserved.  *
 *    *
 **************************************************************************/
package org.vietspider.gui.webstore;

import java.net.URL;
import java.util.prefs.Preferences;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.vietspider.bean.website.Website;
import org.vietspider.bean.website.Websites;
import org.vietspider.gui.browser.StatusBar;
import org.vietspider.gui.workspace.Workspace;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.ApplicationFactory;
import org.vietspider.ui.widget.UIDATA;
import org.vietspider.ui.widget.action.HyperlinkAdapter;
import org.vietspider.ui.widget.action.HyperlinkEvent;
import org.vietspider.ui.widget.images.ToolbarResource;

/**
 *  Author : Nhu Dinh Thuan
 *          Email:nhudinhthuan@yahoo.com
 * Nov 2, 2006
 */
abstract class UIWebsiteStore extends WebsiteHandler {
  
  protected StatusBar statusBar;

  protected int lastSort = 0;
  protected Combo cboStatus;
  protected Combo cboLanguage;
  protected String [] types;

  protected Text txtFieldValue;
  protected Text txtFieldPageSize;

  protected MenuItem [] charsetItems;

  UIWebsiteStore(Composite parent, Workspace workspace) {
    super(parent, workspace);
    
    String clazzName = "org.vietspider.gui.webstore.WebsiteStore";
    ApplicationFactory factory = new ApplicationFactory(this, "WebsiteStore", clazzName);

    types = factory.getResources().getLabel("websiteType").split(","); 

    GridLayout gridLayout = new GridLayout(1, false);
    gridLayout.marginHeight = 0;
    gridLayout.horizontalSpacing = 0;
    gridLayout.verticalSpacing = 0;
    gridLayout.marginWidth = 0;
    setLayout(gridLayout);

    Composite topComposite = new Composite(this, SWT.NONE);
    GridData gridData = new GridData(GridData.FILL_HORIZONTAL);
    topComposite.setLayoutData(gridData);
    topComposite.setLayout(new GridLayout(9, false));

    factory.setComposite(topComposite);

    txtFieldValue = factory.createText();
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    gridData.heightHint = 17;
    txtFieldValue.setFont(UIDATA.FONT_10);
    txtFieldValue.setLayoutData(gridData);
    txtFieldValue.addKeyListener(new KeyAdapter() {
      public void keyReleased(KeyEvent e) {
        if(e.keyCode == SWT.CR) {
          String host = txtFieldValue.getText().trim();
          if(host.isEmpty()) return;
          loadWebsiteByHost(host); 
        }
      }
    });

    factory.createButton("butSearch", new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        String host = txtFieldValue.getText().trim();
        if(host.isEmpty()) return;
        loadWebsiteByHost(host); 
      }

    });

    Label lbl = factory.createLabel(SWT.SEPARATOR);
    gridData = new GridData();
    gridData.heightHint = 25;
    lbl.setLayoutData(gridData);

    Composite sizeComposite = new Composite(topComposite, SWT.NONE);
    gridLayout = new GridLayout(2, false);
    gridLayout.marginHeight = 0;
    gridLayout.horizontalSpacing = 2;
    gridLayout.verticalSpacing = 0;
    gridLayout.marginWidth = 0;
    sizeComposite.setLayout(gridLayout);
    factory.setComposite(sizeComposite);

    factory.createLabel("lblWebsitePageSize");
    txtFieldPageSize = factory.createText(SWT.BORDER);
    txtFieldPageSize.setText("50");
    gridData = new GridData();
    gridData.widthHint = 30;
    txtFieldPageSize.setLayoutData(gridData);

    Composite statusComposite = new Composite(topComposite, SWT.NONE);
    factory.setComposite(statusComposite);

    gridLayout = new GridLayout(2, false);
    gridLayout.marginHeight = 0;
    gridLayout.horizontalSpacing = 2;
    gridLayout.verticalSpacing = 0;
    gridLayout.marginWidth = 0;
    statusComposite.setLayout(gridLayout);

    factory.createLabel("lblWebsiteStatus");
    cboStatus = factory.createCombo(SWT.BORDER | SWT.READ_ONLY);
    cboStatus.setItems(types);
    cboStatus.add("  ", 0);
    setPreferencesIndex(cboStatus, "cboStatus");

    Composite langComposite = new Composite(topComposite, SWT.NONE);
    factory.setComposite(langComposite);

    gridLayout = new GridLayout(2, false);
    gridLayout.marginHeight = 0;
    gridLayout.horizontalSpacing = 2;
    gridLayout.verticalSpacing = 0;
    gridLayout.marginWidth = 0;
    langComposite.setLayout(gridLayout);

    factory.createLabel("lblWebsiteLanguage");
    cboLanguage = factory.createCombo(SWT.BORDER | SWT.READ_ONLY);
    cboLanguage.setItems(new String[]{"*", "en", "vn"});
    setPreferencesIndex(cboLanguage, "cboLanguage");

    Composite pageComposite = new Composite(topComposite, SWT.NONE);
    factory.setComposite(pageComposite);

    gridLayout = new GridLayout(2, false);
    gridLayout.marginHeight = 0;
    gridLayout.horizontalSpacing = 2;
    gridLayout.verticalSpacing = 0;
    gridLayout.marginWidth = 0;
    pageComposite.setLayout(gridLayout);

    factory.createLabel("lblPage");

    spinPage = factory.createSpinner(SWT.BORDER);
    spinPage.setCursor(new Cursor(spinPage.getDisplay(), SWT.CURSOR_HAND));
    spinPage.setIncrement(1);
    gridData = new GridData();
    gridData.widthHint = 30;
    gridData.heightHint = 16;
    spinPage.setLayoutData(gridData);
    spinPage.setMinimum(1);
    spinPage.setMaximum(1);
    spinPage.addModifyListener(new ModifyListener() {
      @SuppressWarnings("unused")
      public void modifyText(ModifyEvent event) {
        loadWebsites(spinPage.getSelection());
      }
    });

    factory.setComposite(topComposite);
    
    final ToolbarResource resources = ToolbarResource.getInstance();
    butGo = resources.createIcon(topComposite, 
        resources.getImageGo(), resources.getTextGo(), new HyperlinkAdapter(){ 
      @SuppressWarnings("unused")
      public void linkActivated(HyperlinkEvent e) {
        butGo.setImage(resources.getImageGo());
      }
      @SuppressWarnings("unused")
      public void linkExited(HyperlinkEvent e) {
        butGo.setImage(resources.getImageGo());
      }
      @SuppressWarnings("unused")
      public void linkEntered(HyperlinkEvent e) {
        butGo.setImage(resources.getImageGo());
      }
    }); 
    butGo.addMouseListener(new MouseAdapter() {
      @SuppressWarnings("unused")
      public void mouseUp(MouseEvent e) {
        loadWebsites(1);
      }

      @SuppressWarnings("unused")
      public void mouseDown(MouseEvent e) {
        butGo.setImage(resources.getImageGo1());
        butGo.redraw();
      }
    });

    factory.setComposite(this);
    
    tableWebsite = factory.createTable("tableWebsite", null, 
        SWT.FULL_SELECTION | SWT.MULTI | SWT.BORDER | SWT.VIRTUAL);  
    tableWebsite.setLinesVisible(true);
    tableWebsite.setHeaderVisible(true);
    gridData = new GridData(GridData.FILL_BOTH);
    tableWebsite.setLayoutData(gridData);

    tableWebsite.getColumns()[6].addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        if(cboLanguage.getText().equalsIgnoreCase("vn")) {
          ClientLog.getInstance().setMessage(getShell(), new Exception("Disable function!"));
          return;
        }
        setIgnoreWebsite(tableWebsite.getItems());
      }
    });

    tableWebsite.getColumns()[7].addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        setIsWebsite(null, tableWebsite.getItems());
      }
    });

    Menu menu = new Menu(factory.getComposite().getShell(), SWT.POP_UP);  

    factory.createMenuItem(menu, "menuViewHtml", new SelectionAdapter(){
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        viewHtml();
      }   
    });

    factory.createMenuItem(menu, "menuGoWebsite", new SelectionAdapter(){
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        goWebsite();
      }   
    });


    factory.createMenuItem(menu, "menuCopy", new SelectionAdapter(){
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        copyWebsite();
      }   
    });

    factory.createMenuItem(menu, SWT.SEPARATOR);

   /*factory.createMenuItem(menu, "menuRedetect", new SelectionAdapter(){
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        setRedetect();
      }   
    });*/

    /*MenuItem menuItem = factory.createMenuItem(menu, (String)null, new SelectionAdapter(){
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        setBlogSite(tableWebsite.getSelection());
      }   
    });
    menuItem.setText("WEB BLOG");*/
    
   /* factory.createMenuItem(menu, SWT.SEPARATOR);

    MenuItem charsetMenuItem = factory.createMenuItem(menu, "encoding", (SelectionAdapter)null);
    charsetMenuItem.setText("Encoding");

    charsetItems = new MenuItem[4];
    Menu charsetMenu = new Menu(menu);
    charsetMenu.addMenuListener(new MenuAdapter() {

      @SuppressWarnings("unused")
      public void menuShown(MenuEvent arg0) {
        viewCharset();
      }

    });
    charsetMenuItem.setMenu (charsetMenu);

    createMenuItem(factory, 0, charsetMenu, "UTF-8");
    createMenuItem(factory, 1, charsetMenu, "WINDOWS-1252");
    createMenuItem(factory, 2, charsetMenu, "ISO-8859-1");
    factory.createMenuItem(charsetMenu, SWT.SEPARATOR);
    createMenuItem(factory, charsetItems.length - 1, charsetMenu, "No Encoding");*/
    
//    factory.createMenuItem(menu, SWT.SEPARATOR);
    
   /* menuItem = factory.createMenuItem(menu, (String)null, new SelectionAdapter(){
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        new WebsiteInputDialog(getShell());
      }   
    });
    menuItem.setText("Website Input Dialog");*/
    
    factory.createMenuItem(menu, "generateSources", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        MessageBox msg = new MessageBox (getShell(), SWT.APPLICATION_MODAL | SWT.YES | SWT.NO);
        msg.setMessage("Are you sure generate download list now?");
        if(msg.open() != SWT.YES) return ;  
        generateDownloadList();
      }   
    });
    
   /* menuItem = factory.createMenuItem(menu, (String)null, new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        int index = cboLanguage.getSelectionIndex();
        if(index < 0) return;
        String lang = cboLanguage.getItem(index);
        MessageBox msg = new MessageBox (getShell(), SWT.APPLICATION_MODAL | SWT.YES | SWT.NO);
        msg.setMessage("Are you sure set redetect " + lang + " now?");
        if(msg.open() != SWT.YES) return ;  
        setReDetect(lang);
      }   
    });
    menuItem.setText("Set redetect");*/
    
   /* menuItem = factory.createMenuItem(menu, (String)null, new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        MessageBox msg = new MessageBox (getShell(), SWT.APPLICATION_MODAL | SWT.YES | SWT.NO);
        msg.setMessage("Are you sure repair website database now?");
        if(msg.open() != SWT.YES) return ;  
        repair();
      }   
    });
    menuItem.setText("Repair Website Storage");*/

    tableWebsite.setMenu(menu);

    tableWebsite.addMouseListener(new MouseAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void mouseDoubleClick(MouseEvent e) {
        viewHtml();
      }
    });
    
    statusBar = new MonitorStatusBar(workspace, this);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    statusBar.setLayoutData(gridData);  
  }

  void disposeEditor(TableEditor...editors) {
    if(editors == null) return;
    for(int i = 0; i < editors.length; i++) {
      if(editors[i] == null 
          || editors[i].getEditor() == null 
          || editors[i].getEditor().isDisposed()) continue;
      editors[i].getEditor().dispose();
      editors[i].dispose();
    }
  }

  Button createCheckerButton(TableEditor tableEditor, 
      TableItem item, int index, int column, final CheckerExecutor executor) {
    Button button = new Button(tableWebsite, SWT.CHECK);
    button.pack();

//  button.computeSize(SWT.DEFAULT, tableWebsite.getItemHeight()+ 20);
    tableEditor.horizontalAlignment = SWT.CENTER;
    tableEditor.minimumWidth = button.getSize().x;
    tableEditor.setEditor(button, item, column);

    executor.setItem(item);
    executor.setIndex(index);
    executor.setButton(button);

    button.addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent event) {
        Runnable timer = new Runnable () {
          public void run () {
            executor.execute();
          }
        };
        getDisplay().timerExec (3*1000, timer);
      }
    });     
    return button;
  }

  abstract void loadWebsites(final int page);
  abstract void ignoreWebsite();
  abstract void copyWebsite();
  abstract void goWebsite();
  abstract void viewHtml();
  abstract void generateDownloadList();
  abstract void setReDetect(String lang);
//  abstract void repair();
  abstract void loadWebsiteByHost(String host) ;

  public static abstract class CheckerExecutor {

    Button button;

    TableItem item;

    int index;

    public abstract void execute();

    public void setButton(Button button_) { button = button_; }

    public void setItem(TableItem item) { this.item = item; }

    public void setIndex(int index) {this.index = index; }
  }

  private void setPreferencesIndex(final Combo cbo, final String name) {
    cbo.addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        try {
          Preferences prefs = Preferences.userNodeForPackage(UIWebsiteStore.class);
          prefs.put(name, String.valueOf(cbo.getSelectionIndex()));
        } catch (Exception exp) {
        }
      }
    });

    int selectedIndex = 0;
    try {
      Preferences prefs = Preferences.userNodeForPackage(UIWebsiteStore.class);
      selectedIndex = Integer.parseInt(prefs.get(name, ""));
    } catch (Exception e) {
      selectedIndex = 0;
    }
    cbo.select(selectedIndex);
  }

  protected void setIgnoreWebsite(String endWith) {
    TableItem [] items = tableWebsite.getItems();
    endWith = endWith.replaceAll("\\.", " ");
    for(int i = 0; i < items.length; i++) {
      if(!webEditors[i].getEditor().isEnabled() 
          || !ignoreEditors[i].getEditor().isEnabled()) continue;
      try {
        URL url = new URL(items[i].getText(1));
        String host = url.getHost().replaceAll("\\.", " ");
        if(!host.endsWith(endWith)) continue;
      } catch (Exception e) {
      }
      Button button = (Button) ignoreEditors[i].getEditor();
      button.setSelection(true);
      setIgnoreWebsite(items[i], webEditors[i], button);
      items[i].setBackground(new Color(items[i].getDisplay(), 255, 222, 222));
    }

  }

  protected void setRedetect() {
    TableItem [] items = tableWebsite.getSelection();
    if(items == null || items.length < 1) return;
    Websites websites = new Websites();
    for(int i = 0; i < items.length; i++) {
      setRedetect(websites, items[i]);
    }
    saveWebsites(websites);
  }

  protected void setRedetect(Websites websites, TableItem item) {
    Website website = createWebsite(item);
    website.setStatus(Website.NEW_ADDRESS);
    website.setLanguage("*");
    websites.getList().add(website);
    item.setText(2, "*");
  }

  void setCharset(String charset) {
    Website website = createWebsite(tableWebsite.getSelectionIndex()) ;
    if(website == null) return;
    website.setCharset(charset);
  }

 /* private void viewCharset() {
    Website website = createWebsite(tableWebsite.getSelectionIndex()) ;
    if(website == null) return;
    String charset = website.getCharset();
    for(int i = 0; i < charsetItems.length; i++) {
      if(charsetItems[i].getText().equalsIgnoreCase(charset)) {
        charsetItems[i].setSelection(true);
      } else {
        charsetItems[i].setSelection(false);
      }
    }

    if(charset == null || charset.trim().isEmpty()) {
      charsetItems[charsetItems.length-1].setSelection(true);
    }
  }*/

  /*private void createMenuItem(
      ApplicationFactory factory, int index, Menu charsetMenu, final String charset) {
    charsetItems[index] = factory.createMenuItem(charsetMenu, SWT.CHECK, (String)null, new SelectionAdapter(){
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        setCharset(charset);
      }   
    });
    charsetItems[index].setText(charset);
  }*/
  
  private class MonitorStatusBar extends StatusBar {
    
    public MonitorStatusBar(Workspace workspace, Composite parent) {
      super(workspace, parent);
    }
  }
  
}