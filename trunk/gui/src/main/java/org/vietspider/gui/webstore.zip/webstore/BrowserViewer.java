/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.webstore;

import java.net.URL;

import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.OpenWindowListener;
import org.eclipse.swt.browser.ProgressAdapter;
import org.eclipse.swt.browser.ProgressEvent;
import org.eclipse.swt.browser.TitleEvent;
import org.eclipse.swt.browser.TitleListener;
import org.eclipse.swt.browser.WindowEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.vietspider.common.text.SWProtocol;
import org.vietspider.ui.browser.PageMenu;
import org.vietspider.ui.widget.ApplicationFactory;
import org.vietspider.ui.widget.UIDATA;
import org.vietspider.ui.widget.tabfolder.CTabItem;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Apr 20, 2009  
 */
public class BrowserViewer extends Composite {
  
  private Browser browser;
  
  private TableItem tableItem;
  private HTMLViewer viewer;
  private CTabItem tabItem;
  
  private Text txtAddress;
  private WebsiteHandler handler;
  
  public BrowserViewer(Composite parent, HTMLViewer viewer_, CTabItem tabItem_, TableItem tableItem_) {
    super(parent, SWT.NONE);
    this.viewer = viewer_;
    this.tabItem = tabItem_;
    this.tableItem = tableItem_;
    
    GridLayout gridLayout = new GridLayout(1, false);
    gridLayout.marginHeight = 0;
    gridLayout.horizontalSpacing = 0;
    gridLayout.verticalSpacing = 0;
    gridLayout.marginWidth = 0;
    setLayout(gridLayout);
    
    Composite composite = new Composite(this, SWT.NONE);
    gridLayout = new GridLayout(2, false);
    gridLayout.marginHeight = 0;
    gridLayout.horizontalSpacing = 0;
    gridLayout.verticalSpacing = 0;
    gridLayout.marginWidth = 0;
    composite.setLayout(gridLayout);
    
    GridData gridData = new GridData(GridData.FILL_HORIZONTAL);
    composite.setLayoutData(gridData);
    
    txtAddress = new Text(composite, SWT.BORDER);
    txtAddress.setFont(UIDATA.FONT_9B);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    txtAddress.setLayoutData(gridData);
    
    Button button = new Button(composite, SWT.PUSH);
    button.setText("Go");
    button.setFont(UIDATA.FONT_9B);
    button.addSelectionListener(new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        browser.setUrl(txtAddress.getText());
      }
    });
    
    browser = ApplicationFactory.createBrowser(this, PageMenu.class);
    
    gridData = new GridData(GridData.FILL_BOTH);
    browser.setLayoutData(gridData);

    browser.addOpenWindowListener( new OpenWindowListener(){
      public void open(WindowEvent event){ 
        event.browser = viewer.createBrowser(null).getBrowser();
      }       
    });
    
    browser.addProgressListener(new ProgressAdapter() {
      @SuppressWarnings("unused")
      public void changed(ProgressEvent event){  
        String url = browser.getUrl();
        if(SWProtocol.isHttp(url)) txtAddress.setText(url);
      }
      @SuppressWarnings("unused")
      public void completed(ProgressEvent event) {      
        String url = browser.getUrl();
        if(SWProtocol.isHttp(url)) txtAddress.setText(url);
        
        String value = browser.getText().toLowerCase();
//        System.out.println(value);
        if(value.indexOf("sponsored listings") > -1 
            || value.indexOf("hosting for this domain is not configured") > -1
            || value.indexOf("invalid hostname") > -1
            || (value.indexOf("what you need") > -1 && value.indexOf("when you need it") > -1)
            || value.indexOf("under construction") > -1) {
//          System.out.println(" da thay "+ tableItem.getText(1));
          setIgnore();
        } else if(value.indexOf('<') < 0 && value.indexOf('>') < 0) {
          goHomepage();
        }
      }
    });      

    
    if(tableItem != null) {
      tabItem.setText(tableItem.getText(1));
    } else {
      browser.addTitleListener( new TitleListener(){
        public void changed(TitleEvent event){
          if(tabItem.isDisposed()) return;
          tabItem.setText(event.title);
        }
      });
    }
    
    Composite bottom = new Composite(this, SWT.NONE);
    gridLayout = new GridLayout(6, false);
    gridLayout.marginHeight = 0;
    gridLayout.horizontalSpacing = 15;
    gridLayout.verticalSpacing = 0;
    gridLayout.marginWidth = 0;
    bottom.setLayout(gridLayout);
    
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    bottom.setLayoutData(gridData);
    
    Label lbl = new Label(bottom, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    lbl.setLayoutData(gridData);
    
    button = new Button(bottom, SWT.PUSH);
    button.setText("Set Ignore");
    button.setFont(UIDATA.FONT_9B);
    button.addSelectionListener(new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        setIgnore();
      }
    });
    
    button = new Button(bottom, SWT.PUSH);
    button.setText("Go Host");
    button.setFont(UIDATA.FONT_9B);
    button.addSelectionListener(new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        goHomepage();
      }
    });
    
    button = new Button(bottom, SWT.PUSH);
    button.setText("Add Homepages");
    button.setFont(UIDATA.FONT_9B);
    button.addSelectionListener(new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        handler.addHomepage(txtAddress.getText(), tableItem);
      }
    });
    
    button = new Button(bottom, SWT.PUSH);
    button.setText("Set Blog");
    button.setFont(UIDATA.FONT_9B);
    button.addSelectionListener(new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        handler.setBlogSite(tableItem);
        Runnable timer = new Runnable () {
          public void run () {
            tabItem.dispose();
          }
        };
        getDisplay().timerExec (10*1000, timer);
      }
    });
    
    button = new Button(bottom, SWT.PUSH);
    button.setText("Set Web");
    button.setFont(UIDATA.FONT_9B);
    button.addSelectionListener(new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        handler.setIsWebsite(null, tableItem);
        Runnable timer = new Runnable () {
          public void run () {
            tabItem.dispose();
          }
        };
        getDisplay().timerExec (10*1000, timer);
      }
    });
  }
  
  public void setText(String html) {
    browser.setText(html);
    txtAddress.setText(tableItem.getText(1));
  }
  
  private void setIgnore() {
    handler.setIgnoreWebsite(tableItem);
    Runnable timer = new Runnable () {
      public void run () {
        tabItem.dispose();
      }
    };
    getDisplay().timerExec (10*1000, timer);
  }
  
  private void goHomepage() {
    try {
      URL url  = new URL(tableItem.getText(1));
      browser.setUrl("http://" + url.getHost());
    } catch (Exception exp) {
    }
  }
  
  public void setUrl(String address) {
    browser.setUrl(address);
    txtAddress.setText(address);
  }

  public Browser getBrowser() { return browser; }

  public TableItem getTableItem() { return tableItem; }

  public Text getTextAddress() { return txtAddress; }

  public void setHandler(WebsiteHandler handler) {
    this.handler = handler;
  }
}
