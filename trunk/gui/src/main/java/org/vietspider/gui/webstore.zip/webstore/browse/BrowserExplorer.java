/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.webstore.browse;

import java.net.URL;
import java.nio.charset.Charset;

import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.ProgressAdapter;
import org.eclipse.swt.browser.ProgressEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.vietspider.bean.website.Website;
import org.vietspider.client.ClientPlugin;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.client.common.DataClientHandler;
import org.vietspider.common.util.Worker;
import org.vietspider.gui.browser.BrowserWidget;
import org.vietspider.gui.browser.StatusBar;
import org.vietspider.gui.browser.TabBrowser;
import org.vietspider.gui.webstore.WebsiteHandler;
import org.vietspider.gui.workspace.Workspace;
import org.vietspider.html.HTMLDocument;
import org.vietspider.html.HTMLNode;
import org.vietspider.html.Name;
import org.vietspider.html.NodeIterator;
import org.vietspider.html.parser.HTMLParser2;
import org.vietspider.token.attribute.Attribute;
import org.vietspider.token.attribute.AttributeParser;
import org.vietspider.token.attribute.Attributes;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.ApplicationFactory;
import org.vietspider.ui.widget.tabfolder.CTabItem;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 3, 2009  
 */
public class BrowserExplorer extends BrowserWidget {


  protected Table tableWebsite;
 
  protected int currentIndex;

  private WebsiteHandler handler;

  private Combo cboEncoding;
  private Combo cboLanguage;
  
  public BrowserExplorer(Composite parent, Workspace _workspace) {
    super(parent, _workspace);
  }

  public void setTabItem(CTabItem item) {
    TabBrowser tabBrowser = workspace.getTab();
    init(tabBrowser, item);
    layout();
  }

  @Override()
  protected void createStatusBar() {
    String clazzName = BrowserExplorer.class.getName();
    ApplicationFactory factory = new ApplicationFactory(this, "WebsiteStore", clazzName);
    
    Composite bottom = new Composite(this, SWT.NONE);
    GridLayout gridLayout = new GridLayout(9, false);
    gridLayout.marginHeight = 5;
    gridLayout.horizontalSpacing = 15;
    gridLayout.verticalSpacing = 5;
    gridLayout.marginWidth = 5;
    bottom.setLayout(gridLayout);

    GridData gridData = new GridData(GridData.FILL_HORIZONTAL);
    bottom.setLayoutData(gridData);

    factory.setComposite(bottom);

    Label lbl = new Label(bottom, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    lbl.setLayoutData(gridData);

    Composite compEncoding = new Composite(bottom, SWT.NONE);
    compEncoding.setLayout(new GridLayout(3, false));
    gridData = new GridData();
    //    gridData.widthHint = 140;
    compEncoding.setLayoutData(gridData);
    factory.setComposite(compEncoding);
    
    widget.addProgressListener(new ProgressAdapter() {
      @SuppressWarnings("unused")
      public void completed(ProgressEvent arg0) {
        searchEncoding();
        
        if(toolbar.getText().toLowerCase().indexOf("http") < 0) {
          toolbar.setText(tableWebsite.getItem(currentIndex).getText(1));
        }
      }
    });

    factory.createLabel("lblEncoding");
    cboEncoding = factory.createCombo(SWT.BORDER);
    gridData = new GridData();
    gridData.widthHint = 70;
    cboEncoding.setLayoutData(gridData);
    String [] charsets = {"UTF-8", "windows-1252", 
        "windows-1250", "ISO-8859-1", "US-ASCII", "UTF-16", "UTF-16BE", "UTF-16LE"};
    cboEncoding.setItems(charsets);
    cboEncoding.addKeyListener(new KeyAdapter() {
      public void keyReleased(KeyEvent e) {
        if(e.keyCode == SWT.CR)  saveEncoding();
      }
      
    });
    cboEncoding.addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        saveEncoding();
      }
    });
    factory.createButton("butRedetect", new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        saveEncoding();
        next();
      }
    });

    Composite compLanguage = new Composite(bottom, SWT.NONE | SWT.READ_ONLY);
    compLanguage.setLayout(new GridLayout(2, false));
    gridData = new GridData();
    gridData.widthHint = 120;
    compLanguage.setLayoutData(gridData);
    factory.setComposite(compLanguage);

    factory.createLabel("lblLanguage");
    cboLanguage = factory.createCombo(SWT.BORDER);
    gridData = new GridData();
    gridData.widthHint = 20;
    cboLanguage.setLayoutData(gridData);
    cboLanguage.setItems(new String[]{"*", "vn", "en"});
    
    cboLanguage.addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        int index = cboLanguage.getSelectionIndex();
        String lang = cboLanguage.getItem(index);
        Website website = handler.createWebsite(currentIndex);
        website.setLanguage(lang);
        handler.saveWebsite(website);
      }
    });

    factory.setComposite(bottom);

    factory.createButton("butIgnore", new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        TableItem tableItem = tableWebsite.getItem(currentIndex);
        handler.setIgnoreWebsite(tableItem);
        next();
      }
    });

    factory.createButton("butOnline", new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        TableItem tableItem = tableWebsite.getItem(currentIndex);
        try {
          URL url  = new URL(tableItem.getText(1));
          widget.setUrl("http://" + url.getHost());
        } catch (Exception ex) {
          widget.setUrl(tableItem.getText(1));
        }
      }
    });

    factory.createButton("butAddHomepage", new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        TableItem tableItem = tableWebsite.getItem(currentIndex);
        handler.addHomepage(widget.getUrl(), tableItem);
      }
    });

    factory.createButton("butIsWeb", new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        TableItem tableItem = tableWebsite.getItem(currentIndex);
        handler.setIsWebsite(cboEncoding.getText(), tableItem);
        next();
      }
    });
    
    factory.createButton("butIsBlog", new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        TableItem tableItem = tableWebsite.getItem(currentIndex);
        handler.setBlogSite(tableItem);
        next();
      }
    });

    factory.createButton("butNext", new SelectionAdapter() {
      @Override
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        next();
      }
    });

    statusBar = new StatusBar(workspace, this);

    statusBar.setPlugins(new ClientPlugin[]{new SetDescPlugin()});

    gridData = new GridData(GridData.FILL_HORIZONTAL);
    statusBar.setLayoutData(gridData);  
    //    tab.setStatusBar(statusBar);
    statusBar.setComponent(this);
    
  }

  protected void next() {
    currentIndex++;
    if(currentIndex >= tableWebsite.getItemCount()) {
      dispose();
      return;
    }
    tableWebsite.setSelection(currentIndex);
    TableItem _item = tableWebsite.getItem(currentIndex);
    if("en".equals(_item.getText(2))) {
      Color color = _item.getForeground();
      if(color.getRed() == 255 || "vietnam".equalsIgnoreCase(_item.getText(5))) {
        new LoadWebsite();
        return;
      } 
    } else {
      new LoadWebsite();
      return;
    }
    next();
  }

  public void setTableWebsite(Table _tableWebsite) {
    this.tableWebsite = _tableWebsite;
    currentIndex = tableWebsite.getSelectionIndex();
    if(currentIndex < 0) currentIndex = 0;

    new LoadWebsite();
  }

  private class LoadWebsite  extends Worker {

    private String host;
    protected Website website; 

    public LoadWebsite() {
      new ThreadExecutor(this, BrowserExplorer.this).start();
    }

    public void abort() {
      ClientConnector2.currentInstance().abort();
    }

    public void before() {
      TableItem tableItem = tableWebsite.getItem(currentIndex);
      String url = tableItem.getText(1);
      host = Website.toHost(url);
      toolbar.setText(url);
      widget.setText("<html><body><p>loading "+url +"...</p></body></html>");
    }

    public void execute() {
      try {
        DataClientHandler client = new DataClientHandler();
        website  = client.load(host);
      } catch (Exception e) {
      }
    }

    public void after() {
      if(website == null)  return;
      if(website.getLanguage() != null) {
        cboLanguage.setText(website.getLanguage());
      }
      if(website.getCharset() != null) {
        cboEncoding.setText(website.getCharset());
      }
      
      widget.stop();
      
      final String html = website.getHtml();
      if(html == null || html.trim().isEmpty()) {
        TableItem tableItem = tableWebsite.getItem(currentIndex);
        setUrl(tableItem.getText(1));
        return;
      }
      
      Runnable timer = new Runnable () {
        public void run () {
          try {
            setText(html);
          } catch (Throwable e) {
            ClientLog.getInstance().setMessage(widget.getShell(), new Exception(e.toString()));
            TableItem tableItem = tableWebsite.getItem(currentIndex);
            setUrl(tableItem.getText(1));
          }
        }
      };
      widget.getDisplay().timerExec (1, timer);
    }
  }

  public void setHandler(WebsiteHandler handler) {
    this.handler = handler;
  }

  public void dispose() {
    super.dispose();
    CTabItem [] items = tab.getItems();
    for(int i = 0; i < items.length; i++) {
      if(items[i].getControl() != this) continue;
      items[i].dispose();
      break;
    }
  }
  
  private void searchEncoding() {
    Website website = handler.createWebsite(currentIndex);
    if(website != null 
        && website.getCharset() != null 
        && !website.getCharset().trim().isEmpty()) {
      cboEncoding.setText(website.getCharset().trim());
      return;
    }
    try {
      String html = widget.getText();
      HTMLDocument document = new HTMLParser2 ().createDocument(html);
      NodeIterator iterator = document.getRoot().iterator();
      while(iterator.hasNext()) {
        HTMLNode node = iterator.next();
        if(node.isNode(Name.META)) {
          Attributes attributes = AttributeParser.parse(node);
          Attribute attribute = attributes.get("content");
          if(attribute == null) continue;
          String value  = attribute.getValue();
          int idx = value.indexOf("charset=");
          if(idx < 0) continue;
          value = value.substring(idx + 8).trim();
          cboEncoding.setText(value);
        } else if(node.isNode(Name.BODY)) {
          return;
        }
      }
    } catch (Exception e) {
    }
  }
  
  private void saveEncoding() {
    String charset = cboEncoding.getText();
    if(charset == null || charset.trim().isEmpty()) return;
    try {
      Charset.forName(charset);
    } catch (Exception e1) {
      return;
    }
    Website website = handler.createWebsite(currentIndex);
    website.setCharset(charset.trim());
    website.setLanguage("*");
    website.setHtml("");
    handler.saveWebsite(website);
  }
  
  public int getCurrentIndex() { return currentIndex; }
  public WebsiteHandler getHandler() { return handler; }
  
  public Table getTableWebsite() { return tableWebsite; }

  
}
