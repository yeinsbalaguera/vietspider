/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.webstore;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Spinner;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.client.common.DataClientHandler;
import org.vietspider.common.util.Worker;
import org.vietspider.gui.browser.ControlComponent;
import org.vietspider.gui.workspace.Workspace;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.ImageHyperlink;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jan 25, 2008  
 */
class DataMonitor extends ControlComponent {
  
  protected Spinner spinPage;
  
  protected ImageHyperlink butGo;
  protected ImageHyperlink butShowDetail;
  
  protected List listDate;
  
  DataMonitor(Composite parent, Workspace workspace) {
    super(parent, workspace);
  }
  
  void loadDate(final boolean log) { 
    if(listDate == null) return;
    Worker excutor = new Worker() {

      private String [] data;

      @Override
      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      @Override
      public void before() {
        listDate.removeAll();
      }

      @Override
      public void execute() {
        try {
          if(log) {
            data = new DataClientHandler().getDateLogs(null, null);
          } else {
            data = new DataClientHandler().getDate();
          }
        }catch (Exception e) {
          ClientLog.getInstance().setException(null, e);
          data = new String[]{};
        }
      }

      @Override
      public void after() {   
        if(listDate.isDisposed()) return;
        listDate.setItems(data);   
      }
    };
    
    new ThreadExecutor(excutor, listDate).start();
  }
  
  String getSelectedDate() {
    int idx = listDate.getSelectionIndex();
    return idx < 0 ? null : listDate.getItem(idx);
  }
  
  public String getNameIcon() { return "small.monitor.png"; }
}
