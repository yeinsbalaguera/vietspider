/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.webstore;


import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.vietspider.bean.website.Website;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.client.common.DataClientHandler;
import org.vietspider.common.text.SWProtocol;
import org.vietspider.common.util.Worker;
import org.vietspider.ui.widget.ShellGetter;
import org.vietspider.ui.widget.ShellSetter;
import org.vietspider.ui.widget.tabfolder.CTabFolder;
import org.vietspider.ui.widget.tabfolder.CTabItem;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Mar 28, 2009  
 */
public class HTMLViewer {

  private Shell tip = null;
  
  private CTabFolder tab;
  private WebsiteHandler handler;
  
  public HTMLViewer(WebsiteHandler handler, TableItem item) {
    this.handler = handler;
    
    tip = new Shell(handler.getTableWebsite().getShell(), SWT.CLOSE | SWT.TITLE | SWT.RESIZE | SWT.MIN | SWT.MAX);
    new ShellGetter(getClass(), tip, 550, 450);
    
    tip.setBackground(tip.getDisplay().getSystemColor(SWT.COLOR_INFO_BACKGROUND));
    tip.setLayout(new GridLayout(1, false));
   
    GridLayout gridLayout = new GridLayout(1, false);
    gridLayout.marginHeight = 0;
    gridLayout.horizontalSpacing = 0;
    gridLayout.verticalSpacing = 0;
    gridLayout.marginWidth = 0;
    tip.setLayout(gridLayout);
    
    tab = new CTabFolder(tip, SWT.BORDER | SWT.CLOSE);
    tab.setLayoutData(new GridData(GridData.FILL_BOTH));
    
    tip.addShellListener(new ShellAdapter(){       
      @SuppressWarnings("unused")
      public void shellClosed(ShellEvent e){
        new ShellSetter(HTMLViewer.class, tip);
      }     
    });
    
    view(item);
  }
  
  public void view(TableItem tableItem) {
    if(tableItem == null) return;
    CTabItem [] items = tab.getItems();
    for(int i = 0; i < items.length; i++) {
      if(items[i].getText().equalsIgnoreCase(tableItem.getText(1))) {
        tab.setSelection(i);
        return;
      }
    }
    new LoadHTML(tableItem);
  }
  
  private class LoadHTML  extends Worker {

    private String html;
    private String host;
    private TableItem tableItem;
    
    public LoadHTML(TableItem item) {
      this.tableItem = item;
      new ThreadExecutor(this, tip).start();
    }
    
    public void abort() {
      ClientConnector2.currentInstance().abort();
    }

    public void before() {
      Website website = new Website();
      website.setAddress(tableItem.getText(1));
      host = website.getHost();
      if(tip.isDisposed()) return;
      tip.setText(website.getAddress());
    }

    public void execute() {
      try {
        DataClientHandler client = new DataClientHandler();
//        html  = client.loadWebsiteHTML(host);
      } catch (Exception e) {
      }
    }

    public void after() {
      if(tip.isDisposed()) return;
      if(html == null || html.trim().isEmpty()) {
        viewValue(tableItem, tableItem.getText(1));
        return;
      }
      viewValue(tableItem, html);
    }
  }

  
  private void viewValue(TableItem tableItem, String value) {
    BrowserViewer browser = getSelectedBrowser(tableItem);
    if(browser == null || browser.isDisposed()) return;
    tip.setVisible(true);
    if(SWProtocol.isHttp(value)) {
      browser.setUrl(value);
    } else {
      browser.setText(value);
    }
  }
  
  public boolean isVisible() {
    if(tip == null || tip.isDisposed()) return false;
    return tip.isVisible();
  }
  
  public void setVisible(boolean value) {
    if(tip == null || tip.isDisposed()) return;
    tip.setVisible(value);
  }
  
  BrowserViewer createBrowser(TableItem tableItem) {
    CTabItem tabItem = new CTabItem(tab, SWT.NONE);
    BrowserViewer browser = new BrowserViewer(tab, this, tabItem, tableItem);
    browser.setHandler(handler);

    GridData gridData = new GridData(GridData.FILL_BOTH);
    browser.setLayoutData(gridData);

    tabItem.setControl(browser);
    tab.setSelection(tabItem);

    return browser;
  }
  
  private BrowserViewer getSelectedBrowser(TableItem tableItem) {
    CTabItem [] items = tab.getItems();
    for(int i = 0; i < items.length; i++) {
      BrowserViewer browser = (BrowserViewer) tab.getItem(i).getControl();
      if(browser.getTableItem() == tableItem) {
        tab.setSelection(i);
        return  null;
      }
    }
    return createBrowser(tableItem);
  }
  
  public void closeAll() {
    CTabItem [] items = tab.getItems();
    for(int i = 0; i < items.length; i++) {
      items[i].dispose();
    }
    System.gc();
  }
  
}
