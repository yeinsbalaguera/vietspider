/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.gui.webstore;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.TableItem;
import org.vietspider.bean.website.Website;
import org.vietspider.bean.website.Websites;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.common.Application;
import org.vietspider.common.io.GZipIO;
import org.vietspider.common.text.SWProtocol;
import org.vietspider.common.util.RatioWorker;
import org.vietspider.common.util.Worker;
import org.vietspider.gui.browser.StatusBar;
import org.vietspider.gui.webstore.browse.BrowserExplorer;
import org.vietspider.gui.workspace.Workspace;
import org.vietspider.net.client.AbstClientConnector.HttpData;
import org.vietspider.net.server.URLPath;
import org.vietspider.serialize.Bean2XML;
import org.vietspider.serialize.XML2Bean;
import org.vietspider.ui.BareBonesBrowserLaunch;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.services.ClientRM;
import org.vietspider.ui.widget.UIDATA;
import org.vietspider.ui.widget.waiter.ProgressExecutor;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Jan 11, 2008  
 */
public class WebsiteStore extends UIWebsiteStore {


  protected List<BrowserExplorer> explorers = new ArrayList<BrowserExplorer>(); 

  public WebsiteStore(Composite parent, Workspace _workspace) {
    super(parent, _workspace);
  }

  public Workspace getWorkspace() { return workspace; }

  public StatusBar getStatusBar() { return statusBar; }

  void loadWebsiteByHost(final String pattern) {
    RatioWorker worker = new RatioWorker() {

      private Website website = null;

      @Override
      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      @Override
      public void before() {
        butGo.setEnabled(false);
        clearTable();
      }

      @Override
      public void execute() {
        InputStream inputStream =  null;
        ClientConnector2 connector = ClientConnector2.currentInstance();
        HttpData httpData = null;
        try {
          Header header = new BasicHeader("action", "load.website.by.host");
          byte [] bytes = pattern.getBytes(Application.CHARSET);
          httpData = connector.loadResponse(URLPath.DATA_HANDLER, bytes, header);
          header = httpData.getResponseHeader("Content-Length");
          if(header != null ) {
            setTotal(Integer.parseInt(header.getValue()));
          }
          inputStream = httpData.getStream();
          ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
          byte [] buffer = new byte[16*1024];
          int read = 0;
          while((read = inputStream.read(buffer)) > -1) {
            outputStream.write(buffer, 0, read);
            increaseRatio(read);
          }
          bytes = outputStream.toByteArray();
          if(bytes.length > 1)  {
            website = XML2Bean.getInstance().toBean(Website.class, bytes);
          }
          inputStream.close();
        } catch (Exception e) {
        } finally {
          connector.release(httpData);
          try {
            if(inputStream != null) inputStream.close();
          } catch (Exception e) {
          }
        }
      }

      @Override
      public void after() {
        if(butGo.isDisposed() ) return;
        butGo.setEnabled(true);

        if(website == null) {
          if(!SWProtocol.isHttp(pattern)) return;
          try {
            URL url = new URL(pattern);
            loadWebsiteByHost(url.getHost());
          } catch (Exception e) {
            ClientLog.getInstance().setException(getShell(), e);
          }
          return;
        }
        Websites websites = new Websites();
        websites.getList().add(website);
        //        spinPage.setMaximum(totalPage);
        spinPage.setMinimum(1);
        createUI(websites);
      }
    };
    statusBar.showProgressBar();
    ProgressExecutor loading = new ProgressExecutor(statusBar.getProgressBar(), worker);
    loading.open();
  }

  void loadWebsites(final int page) {
    ClientRM resources = new ClientRM("WebsiteStore");
    String resourceLabel = resources.getLabel("page");
    if(resourceLabel == null) resourceLabel = "page";
    final String labelPage = " "+ resourceLabel;

    RatioWorker worker = new RatioWorker() {

      private Websites websites = null;

      @Override
      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      @Override
      public void before() {
        butGo.setEnabled(false);

        websites = new Websites();
        websites.setPage(page);
        if(cboLanguage.getSelectionIndex() > 0) {
          websites.setLanguage(cboLanguage.getItem(cboLanguage.getSelectionIndex()));
        }
        websites.setStatus(cboStatus.getSelectionIndex()-2);
        try {
          websites.setPageSize(Integer.parseInt(txtFieldPageSize.getText()));
        } catch (Exception e) {
        }
      }

      @Override
      public void execute() {
        InputStream inputStream =  null;
        ClientConnector2 connector = ClientConnector2.currentInstance();
        HttpData httpData = null;
        try {
          Header header = new BasicHeader("action", "load.website.list");
          String xml = Bean2XML.getInstance().toXMLDocument(websites).getTextValue();
          byte [] bytes = xml.getBytes(Application.CHARSET);
          httpData = connector.loadResponse(URLPath.DATA_HANDLER, bytes, header);
          header = httpData.getResponseHeader("Content-Length");
          if(header != null ) {
            setTotal(Integer.parseInt(header.getValue()));
          }
          inputStream = httpData.getStream();
          ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
          byte [] buffer = new byte[16*1024];
          int read = 0;
          while((read = inputStream.read(buffer)) > -1) {
            outputStream.write(buffer, 0, read);
            increaseRatio(read);
          }
          bytes = outputStream.toByteArray();
          bytes = new GZipIO().unzip(bytes); 
          websites = XML2Bean.getInstance().toBean(Websites.class, bytes);
          inputStream.close();
        } catch (Exception e) {
        } finally {
          connector.release(httpData);
          try {
            if(inputStream != null) inputStream.close();
          } catch (Exception e) {
          }
        }
      }

      @Override
      public void after() {
        if(butGo.isDisposed()) return;
        butGo.setEnabled(true);

        if(websites == null) return;
        int totalPage = websites.getTotalPage();
        //        spinPage.setMaximum(totalPage);
        if(totalPage > 1) spinPage.setMinimum(1);
        spinPage.setToolTipText(String.valueOf(totalPage) + labelPage);
        spinPage.setMaximum(totalPage);
        createUI(websites);
      }
    };
    statusBar.showProgressBar();
    ProgressExecutor loading = new ProgressExecutor(statusBar.getProgressBar(), worker);
    loading.open();
  }

  private void clearTable() {
    tableWebsite.removeAll();
    disposeEditor(ignoreEditors);
    disposeEditor(webEditors);
    //    disposeEditor(langEditors);
  }

  private void createUI(Websites websites) {
    clearTable();

    listWebsites = websites.getList();

    ignoreEditors = new TableEditor[listWebsites.size()];
    webEditors = new TableEditor[listWebsites.size()];
    //    langEditors = new TableEditor[listWebsites.size()];

    int start = (websites.getPage() - 1) * websites.getPageSize();
    for(int i = 0; i < listWebsites.size(); i++) {
      TableItem item = new TableItem(tableWebsite, SWT.NONE);
      item.setFont(UIDATA.FONT_8V);
      item.setForeground(new Color(getDisplay(), 0, 0, 0));
      item.setText(0, String.valueOf(i+start));
      Website web = listWebsites.get(i);
      if(web == null) continue;
      item.setText(1, web.getAddress());
      if(cboLanguage.getSelectionIndex() == 1) {
        try {
          //          URL url  = new URL(web.getAddress());
          /*String host = url.getHost();
          if(host.indexOf("vn") > -1 
              || host.indexOf("viet") > -1
              || host.indexOf("saigon") > -1
              || host.indexOf("hanoi") > -1
              || host.indexOf("hcm") > -1
              || host.indexOf("vina") > -1) {*/
          if(web.getScoreHost() > 4) {
            //            System.out.println(" ===  >"+ web.getHost() + " : "+ web.getScoreHost());
            item.setForeground(new Color(getDisplay(), 255, 0, 0));
          }
        } catch (Exception e) {
        }
      }
      item.setText(2, web.getLanguage());
      item.setText(3, types[web.getStatus()+1]);
      item.setText(4, web.getSource());
      item.setText(5, web.getDesc());

      ignoreEditors[i] = new TableEditor(tableWebsite);
      createCheckerButton(ignoreEditors[i], item, i, 6, new CheckerExecutor() {
        public void execute() {
          setIgnoreWebsite(item, ignoreEditors[index], button);
        }
      });

      webEditors[i] = new TableEditor(tableWebsite);
      createCheckerButton(webEditors[i], item, i, 7, new CheckerExecutor() {
        public void execute() {
          setIsWebsite(item, ignoreEditors[index], button, null);
        }
      });
      //      button.setEnabled(web.getStatus() == Website.NEW_ADDRESS);

      if(i%2 == 1) {
        item.setBackground(new Color(getDisplay(), 245, 245, 245)); 
      }
    }
    //    if(viewer == null || !viewer.isVisible()) return;
    //    viewer.closeAll();
  }

  void ignoreWebsite() {
    TableItem [] items = tableWebsite.getSelection();
    Websites websites = new Websites();
    for(TableItem item : items) {
      Website website = createWebsite(item);
      if(website == null) continue;
      website.setStatus(Website.UNAVAILABLE);
      websites.getList().add(website);
    }
    saveWebsites(websites);
  }

  void goWebsite() {
    TableItem [] items = tableWebsite.getSelection();
    for(TableItem item : items) {
      BareBonesBrowserLaunch.openURL(getShell(), item.getText(1));
    }
  }

  void copyWebsite() {
    TableItem [] items = tableWebsite.getSelection();
    if(items == null || items.length < 1) {
      items = tableWebsite.getItems();
    }
    if(items == null || items.length < 1) return;
    StringBuilder builder = new StringBuilder();
    for(TableItem item : items) {
      builder.append(item.getText(1)).append('\n');
    }
    Clipboard clipboard = new Clipboard(tableWebsite.getDisplay());
    TextTransfer transfer = TextTransfer.getInstance();
    clipboard.setContents( new Object[] { builder.toString().trim() }, new Transfer[]{ transfer });
  }

  void viewHtml() {
    Iterator<BrowserExplorer> iterator = explorers.iterator();
    while(iterator.hasNext()) {
      BrowserExplorer explorer = iterator.next();
      if(explorer.isDisposed()) iterator.remove();
    }

    TableItem [] items = tableWebsite.getSelection();
    if(items.length < 1) return;

    for(int i = 0; i < items.length; i++) {
      try {
        BrowserExplorer explorer = (BrowserExplorer)
        workspace.getTab().createTool(BrowserExplorer.class, false,  SWT.CLOSE);
        explorer.setTableWebsite(tableWebsite);
        explorer.setHandler(this);
        explorers.add(explorer);
      } catch (Exception e) {
        ClientLog.getInstance().setMessage(tableWebsite.getShell(), e);
      }
    }
  }



  @Override
  public void dispose() {
    for(int i = 0; i < explorers.size(); i++) {
      explorers.get(i).dispose();
    }
    super.dispose();
  }

  /* private void createComboLanguage(final int index, TableItem item, String lang) {
    lang = lang.trim();
    langEditors[index] = new TableEditor(tableWebsite);
    final Combo cboLangItem  = new Combo(tableWebsite, SWT.NONE);
    String [] data = new String[] {"*", "vn", "en"};
    cboLangItem.setItems(data);
    cboLangItem.addSelectionListener(new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent e) {
        int k = cboLangItem.getSelectionIndex();
        if(k < 0) return;
        Website website = createWebsite(index);
        website.setLanguage(cboLangItem.getItem(k));
        saveWebsite(website);
      }

    });
    data = cboLangItem.getItems();
    for(int k = 0; k < data.length; k++) {
      if(lang.equalsIgnoreCase(cboLangItem.getItem(k))) {
        cboLangItem.select(k);
        break;
      }
    }
    cboLangItem.pack();
//    langEditors[index].horizontalAlignment = SWT.CENTER;
    langEditors[index].minimumWidth = cboLangItem.getSize().x;
    langEditors[index].setEditor(cboLangItem, item, 2);
  }*/

  void generateDownloadList() {
    Worker excutor = new Worker() {

      private String error;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {}

      public void execute() {
        try {
          Header header = new BasicHeader("action", "generate.download.list");
          ClientConnector2 connector = ClientConnector2.currentInstance();
          connector.post(URLPath.DATA_HANDLER, new byte[0], header);
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(tableWebsite.getShell(), new Exception(error));
          return;
        }
      }
    };
    new ThreadExecutor(excutor, tableWebsite).start();
  }

  void setReDetect(final String lang) {
    Worker excutor = new Worker() {

      private String error;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {}

      public void execute() {
        try {
          Header header = new BasicHeader("action", "redetect.websites.list");
          ClientConnector2 connector = ClientConnector2.currentInstance();
          connector.post(URLPath.DATA_HANDLER, lang.getBytes(), header);
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(tableWebsite.getShell(), new Exception(error));
          return;
        }
      }
    };
    new ThreadExecutor(excutor, tableWebsite).start();
  }

  /*void repair() {
     Worker excutor = new Worker() {

       private String error;

       public void abort() {
         ClientConnector.currentInstance().abort();
       }

       public void before() {}

       public void execute() {
         try {
           Header header = new BasicHeader("action", "repair.website.list");
           ClientConnector connector = ClientConnector.currentInstance();
           connector.post(URLPath.DATA_HANDLER, new byte[0], header);
         } catch (Exception e) {
           error = e.toString();
         }
       }

       public void after() {
         if(error != null && !error.isEmpty()) {
           ClientLog.getInstance().setMessage(tableWebsite.getShell(), new Exception(error));
           return;
         }
       }
     };
     new ThreadExecutor(excutor, tableWebsite).start();
  }*/

  public int nextWebsite() {
    int index = tableWebsite.getSelectionIndex();
    index++;
    tableWebsite.setSelection(index);
    return index;
  }

  @Override
  public String getNameIcon() { return  "small.webstore.png"; }

}
