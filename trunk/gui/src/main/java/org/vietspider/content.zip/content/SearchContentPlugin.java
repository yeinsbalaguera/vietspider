/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content;

import java.lang.reflect.Method;

import org.eclipse.swt.browser.Browser;
import org.vietspider.client.ClientPlugin;
import org.vietspider.gui.module.AdvancedSearch;
import org.vietspider.ui.services.ClientRM;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Dec 18, 2008  
 */
public class SearchContentPlugin extends ClientPlugin {

  protected String label;

  public SearchContentPlugin() {
    ClientRM resources = new ClientRM("Plugin");
    Class<?>  clazz = SearchContentPlugin.class;
    label = resources.getLabel(clazz.getName()+".search");
  }
  
  public String getConfirmMessage() { return null; }

  public String getLabel() { return label; }

  @Override
  public boolean isValidType(int type) { 
    return type == APPLICATION || type == DOMAIN || type == CONTENT; 
  }

  public void invoke(Object... objects) {
    Browser browser = null;
    if(objects[1] instanceof Browser) {
      browser = (Browser) objects[1];
    } else {
      try {
        Method method = objects[1].getClass().getDeclaredMethod("invokePlugin");
        browser = (Browser)method.invoke(objects[1], new Object[]{});
      } catch (Exception e) {
      }
    } 
    if(browser == null) return;
    
    new AdvancedSearch(browser);
    
   /* StringBuilder builder = new StringBuilder();
    ClientConnector2 connector = ClientConnector2.currentInstance();
    builder.append("<HTML><title>Search</title><HEAD><body>");
    builder.append("<BODY><table width=\"100%\" height=\"100%\" border=\"0\"><tr>");
    builder.append("<td width=\"100%\" align=\"center\" valign=\"middle\">") ;
    builder.append("<FORM width=\"100%\" action=\"");
    builder.append(connector.getRemoteURL()).append('/');
    builder.append(connector.getApplication()).append("/SEARCH/1/?\" method=\"get\">");
    builder.append("<INPUT size=\"40\" type=\"text\" name=\"text\">");
    builder.append("<INPUT type=\"submit\" value=\"Send\"></form>");
    builder.append("</td> </tr></table></body></html>");
    browser.setText(builder.toString());*/
  }
}
