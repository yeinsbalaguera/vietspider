/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 4, 2008  
 */
class DescriptionExtractor {
  
  private final static String AND = " AND ";
  private final static String OR = " OR ";
  
  private Pattern wordPattern = Pattern.compile("\\b[\\p{L}\\p{Digit}]");
  
  private Pattern [] patterns;

  public DescriptionExtractor(String value) {
    List<String> list = new ArrayList<String>();
    splitPattern(list, value);
    patterns = new Pattern[list.size()];
    for(int i  = 0; i < list.size(); i++) {
      patterns[i] = Pattern.compile(list.get(i), Pattern.UNICODE_CASE | Pattern.CASE_INSENSITIVE);
    }
  }
  
  public String build(String desc, String content) {
    if(patterns == null) return desc;
    StringBuilder builder = new StringBuilder();
    for(Pattern pattern : patterns) {
      if(match(builder, desc, pattern, 15)) continue;
      match(builder, content, pattern, 15);
    }
    if(builder.length() < 1) return desc;
    return builder.toString();
  }
  
  public String build(String title) {
    if(patterns == null) return title;
    List<Integer> list  = new ArrayList<Integer>();
    int index = 0;
    for(Pattern pattern : patterns) {
      Matcher matcher = pattern.matcher(title);
      if(matcher.find(index)) {
        list.add(matcher.start());
        list.add(matcher.end());
        index = matcher.end();
      }
    }
    if(list.size() < 1) return title;
    StringBuilder builder = new StringBuilder();
    index = 0;
    for(int i = 0; i < list.size(); i+= 2) {
      int start = list.get(i);
      int end = list.get(i+1);
      builder.append(title.subSequence(index, start));
      builder.append("<span class=\"highlight_word\">");
      builder.append(title.subSequence(start, end)).append("</span>");
      index = end;
    }
    
    if(index < title.length()) {
      builder.append(title.subSequence(index, title.length())); 
    }
    return builder.toString();
  }
  
  private boolean match(StringBuilder builder, String value, Pattern pattern, int size){
    Matcher matcher = pattern.matcher(value);
    if(matcher.find(0)) {
      int start = matcher.start();
      int end = matcher.end();
      int preStart = findStart(value, start, size);
      builder.append("...");
      builder.append(value.subSequence(preStart, start));
      builder.append("<span class=\"highlight_word\">");
      builder.append(value.subSequence(start, end)).append("</span>");
      int nextEnd = findEnd(value, end, size);
      if(end < nextEnd) {
        builder.append(value.subSequence(end, nextEnd));
      }
      if(count(builder) > 150) return true;
      return true;
    }
    return false;
  }
  
  private int findStart(String value, int index, int size) {
    int counter = 0;
    while(index > -1) {
      char c = value.charAt(index);
      if(!Character.isLetterOrDigit(c)) counter++;
      if(counter >= size) return index;
      index--;
    }
    return Math.max(0, index);
  }
  
  private int findEnd(String value, int index, int size) {
    int counter = 0;
    while(index < value.length()) {
      char c = value.charAt(index);
      if(!Character.isLetterOrDigit(c)) counter++;
      if(counter >= size) return index;
      index++;
    }
    return Math.min(index, value.length() - 1);
  }
  
  public int count(CharSequence charSeq){
    int start = 0;
    int counter = 0;
    Matcher matcher = wordPattern.matcher(charSeq);
    while(matcher.find(start)) {
      start = matcher.start() + 1;
      counter++;
    }
    return counter;
  }
  
  private void splitPattern(List<String> list, String pattern) {
    pattern = pattern.trim();
    int index = pattern.toUpperCase().indexOf(AND);
    while(index > -1) {
      String value = pattern.substring(0, index);
      splitOr(list, value);
      pattern = pattern.substring(index+AND.length());
      index = pattern.toLowerCase().indexOf(AND);
    }
    splitOr(list, pattern);
  }
  
  private void splitOr(List<String> list, String pattern) {
    pattern = pattern.trim();
    int index = pattern.toLowerCase().indexOf(OR);
    while(index > -1) {
      String value = pattern.substring(0, index);
      trimQuote(list, value);
      pattern = pattern.substring(index+OR.length());
      index = pattern.toLowerCase().indexOf(OR);
    }
    trimQuote(list, pattern);
  }
  
  private void trimQuote(List<String> list, String pattern) {
    pattern = pattern.trim();
    String [] elements = pattern.split("\"");
    if(elements.length < 2) elements = pattern.split(" ");
    for(String ele : elements) {
      if((ele = ele.trim()).isEmpty()) continue;
      list.add(ele);
    }
  }
  
}
