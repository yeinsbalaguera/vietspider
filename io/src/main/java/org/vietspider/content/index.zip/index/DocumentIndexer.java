/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Apr 24, 2009  
 */
public class DocumentIndexer {
  
  final public static String FIELD_ID      = "id" ;
  final public static String FIELD_DATE    = "date" ;
  final public static String FIELD_TITLE   = "title" ;
  final public static String FIELD_DESC    = "desc" ;
  final public static String FIELD_CONTENT  = "content" ;
  final public static String FIELD_DOMAIN   = "domain" ;
  final public static String FIELD_IMAGE   = "image" ;
  
  static Document toDocument(IndexEntry entry) {
    if(entry.getContent() == null || entry.getContent().trim().isEmpty()) return null;

    Document doc = new Document();

    doc.add(new Field(FIELD_ID, entry.getId(), Field.Store.YES, Field.Index.NOT_ANALYZED));
    doc.add(new Field(FIELD_DATE, entry.getDate(), Field.Store.YES, Field.Index.NOT_ANALYZED));

    Field titleField = new Field(FIELD_TITLE, entry.getTitle(), Field.Store.YES, Field.Index.ANALYZED) ;
    titleField.setBoost(2.0f) ;
    doc.add(titleField);

    if(entry.getDesc() != null) {
      Field descField = new Field(FIELD_DESC, entry.getDesc(), Field.Store.YES, Field.Index.ANALYZED) ;
      descField.setBoost(1.0f) ;
      doc.add(descField);
    }

    doc.add(new Field(FIELD_CONTENT, entry.getContent(), Field.Store.YES, Field.Index.ANALYZED));

    if(entry.getImage() != null) {
      doc.add(new Field(FIELD_IMAGE, entry.getImage(), Field.Store.YES, Field.Index.NOT_ANALYZED));
    }

    if(entry.getDomain() != null) {
      doc.add(new Field(FIELD_DOMAIN, entry.getDomain(), Field.Store.YES, Field.Index.NOT_ANALYZED));
    }

    return doc;
  }

}
