/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.RAMDirectory;
import org.headvances.vietspider.database.MetaList;
import org.vietspider.bean.Article;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.index.HitDoc;
import org.vietspider.index.HitDocCollector;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 4, 2008  
 */
class DbDomainSearcher extends DbSearcher1 {
  
  public void search(MetaList metas, String [] values) throws Exception {
    List<Document> documents = search(values, metas);
    List<Article> articles = new ArrayList<Article>(PAGE_SIZE);
    for(int i = 0; i < documents.size(); i++) {
      Article article = toArticle(null, documents.get(i));
      articles.add(article);
    }
    metas.setData(articles);
  }
  
  public List<Document> search(String [] fieldValues, MetaList metas) throws Exception {
    File file  = UtilFile.getFolder("content/dbindexed/index/");
    
    RAMDirectory ramDir = null;
    IndexReader reader = null;
    IndexSearcher indexSearcher = null;

    List<Document> list =  new ArrayList<Document>();
    try {
      ramDir = new RAMDirectory(file);
      reader = IndexReader.open(ramDir);
      indexSearcher = new IndexSearcher(reader);
      
      BooleanQuery booleanQuery = new BooleanQuery(true);
      for(int i = 0; i < fieldValues.length; i++) {
        TermQuery query = new TermQuery(new Term(DocumentIndexer.FIELD_DOMAIN, fieldValues[i]));
        booleanQuery.add(new BooleanClause(query, BooleanClause.Occur.SHOULD));
      }
      
//      SortField sortField = new SortField(DocumentIndexer.FIELD_ID, SortField.STRING);
      
      HitDocCollector collector = new HitDocCollector(1000) ;
      indexSearcher.search(booleanQuery, null, collector) ;
      HitDoc[] hitDocs = collector.getHitDoc();
      
//      Hits hits = indexSearcher.search(booleanQuery, new Sort(sortField));
      
      metas.setTotalPage(hitDocs.length / PAGE_SIZE + 1);
      int page = metas.getCurrentPage();
      int start = (page - 1) * PAGE_SIZE;
      int end = page * PAGE_SIZE;
      
//      DbCleanerService dbCleaner = new DbCleanerService();
      for(int i = start; i < Math.min(hitDocs.length, end); i++) {
        int docId = hitDocs[i].getDocId();
        Document doc = indexSearcher.doc(docId);
        if(doc != null) list.add(doc);
      }
//      dbCleaner.clean();
    } finally {
      try {
        if(indexSearcher != null) indexSearcher.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }

      try {
        if(reader != null) reader.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }

      try {
        if(ramDir != null) ramDir.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }

    return list;
  }
  
}
