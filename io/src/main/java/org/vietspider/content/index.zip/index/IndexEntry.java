/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index;

import org.vietspider.serialize.NodeMap;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Apr 28, 2008  
 */
@NodeMap("index-entry")
public class IndexEntry {
  
  final public static int DELETE = 0, ADD = 1;

  @NodeMap("id")
  private String id;
  
  @NodeMap("date")
  private String date;
  
  @NodeMap("title")
  private String title;
  
  @NodeMap("desc")
  private String desc;
  
  @NodeMap("content")
  private String content;
  
  @NodeMap("domain")
  private String domain;
  
  @NodeMap("image")
  private String image;
  
  private int status = ADD;
  
  public IndexEntry() {    
  }
  
  public String getId() { return id; }
  public void setId(String id) { this.id = id; }

  public String getDate() { return date; }
  public void setDate(String date) { this.date = date; }

  public String getTitle() { return title; }
  public void setTitle(String title) { this.title = title; }

  public String getDesc() { return desc; }
  public void setDesc(String desc) { this.desc = desc; }

  public String getContent() { return content;  }
  public void setContent(String content) { this.content = content; }

  public int getStatus() { return status; }
  public void setStatus(int status) { this.status = status; }

  public String getDomain() { return domain; }
  public void setDomain(String domain) { this.domain = domain; }

  public String getImage() { return image; }
  public void setImage(String image) { this.image = image; }
  
}
