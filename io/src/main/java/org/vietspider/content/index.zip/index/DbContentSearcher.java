/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.RAMDirectory;
import org.headvances.vietspider.database.MetaList;
import org.vietspider.bean.Article;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.index.HitDoc;
import org.vietspider.index.HitDocCollector;
/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 4, 2008  
 */
class DbContentSearcher extends DbSearcher1 {
  
  public void searchByQuery(MetaList metas, String query) throws Exception {
    List<Document> documents = search(query, metas);
    List<Article> articles = new ArrayList<Article>(PAGE_SIZE);
    for(int i = 0; i < documents.size(); i++) {
      Article article = toArticle(null, documents.get(i));
      articles.add(article);
    }
    metas.setData(articles);
  }
  
  public void search(MetaList metas, String pattern) throws Exception {
    StringBuilder builder = new StringBuilder();
    builder.append(DocumentIndexer.FIELD_TITLE).append(':').append(pattern).append(" OR ");
    builder.append(DocumentIndexer.FIELD_DESC).append(':').append(pattern).append(" OR ");
    builder.append(DocumentIndexer.FIELD_CONTENT).append(':').append(pattern);
    
    List<Document> documents = search(builder.toString(), metas);
    List<Article> articles = new ArrayList<Article>(PAGE_SIZE);
    DescriptionExtractor descriptionExtractor = new DescriptionExtractor(pattern);
    for(int i = 0; i < documents.size(); i++) {
      Article article = toArticle(descriptionExtractor, documents.get(i));
      articles.add(article);
    }
    metas.setData(articles);
  }
  
  public List<Document> search(String queryValue, MetaList metas) throws Exception {
    File file  = UtilFile.getFolder("content/dbindexed/index/");
    
    RAMDirectory ramDir = null;
    IndexReader reader = null;
    IndexSearcher indexSearcher = null;

    List<Document> list =  new ArrayList<Document>();
    try {
      ramDir = new RAMDirectory(file);
      reader = IndexReader.open(ramDir);
      indexSearcher = new IndexSearcher(reader);
      
      QueryParser parser = new QueryParser(DocumentIndexer.FIELD_CONTENT, new StandardAnalyzer());
      Query query = parser.parse(queryValue);
      
      HitDocCollector collector = new HitDocCollector(1000) ;
      indexSearcher.search(query, null, collector) ;
      HitDoc[] hitDocs = collector.getHitDoc();
      
      /*Hits hits = null;
      if(sort) {
        SortField sortField = new SortField(DocumentIndexer.FIELD_ID, SortField.STRING);
        hits = indexSearcher.search(query, new Sort(sortField));
      } else {
        hits = indexSearcher.search(query);
      }*/
      
      metas.setTotalPage(hitDocs.length / PAGE_SIZE + 1);
      int page = metas.getCurrentPage();
      int start = (page - 1) * PAGE_SIZE;
      int end = page * PAGE_SIZE;
      
//      DbCleanerService dbCleaner = new DbCleanerService();
      for(int i = start; i < Math.min(hitDocs.length, end); i++) {
        int docId = hitDocs[i].getDocId();
        Document doc = indexSearcher.doc(docId);
        if(doc != null) list.add(doc);
      }
      
//      dbCleaner.clean();
    } finally {
      try {
        if(indexSearcher != null) indexSearcher.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }

      try {
        if(reader != null) reader.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }

      try {
        if(ramDir != null) ramDir.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }

    return list;
  }

}
