package org.vietspider.content.index;


import org.vietspider.content.index.IndexEntry;
import org.vietspider.token.attribute.*;
import org.vietspider.parser.xml.XMLNode;
import org.vietspider.serialize.Object2XML;
import org.vietspider.serialize.XML2Object;
import org.vietspider.serialize.SerializableMapping;


public class IndexEntry_MappingImpl implements SerializableMapping<IndexEntry> {

	private final static int code=18034470;

	public IndexEntry create() {
		return new IndexEntry();
	}

	public void toField(IndexEntry object, XMLNode node, String name, String value) throws Exception {
		if(name.equals("id")) {
			object.setId(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("date")) {
			object.setDate(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("title")) {
			object.setTitle(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("desc")) {
			object.setDesc(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("content")) {
			object.setContent(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("domain")) {
			object.setDomain(XML2Object.getInstance().toValue(String.class, value));
			return;
		}
		if(name.equals("image")) {
			object.setImage(XML2Object.getInstance().toValue(String.class, value));
			return;
		}

	}

	public XMLNode toNode(IndexEntry object) throws Exception {
		XMLNode node = new XMLNode("index-entry");
		Attributes attrs  = new Attributes(node);
		Object2XML mapper = Object2XML.getInstance();
		mapper.addNode(object.getId(), node, false, "id");
		mapper.addNode(object.getDate(), node, false, "date");
		mapper.addNode(object.getTitle(), node, false, "title");
		mapper.addNode(object.getDesc(), node, false, "desc");
		mapper.addNode(object.getContent(), node, false, "content");
		mapper.addNode(object.getDomain(), node, false, "domain");
		mapper.addNode(object.getImage(), node, false, "image");
		return node;
	}
}
