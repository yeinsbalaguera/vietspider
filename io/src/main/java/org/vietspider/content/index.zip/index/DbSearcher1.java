/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.vietspider.bean.Article;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Meta;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 19, 2008  
 */
public class DbSearcher1 {
  
  protected final static int PAGE_SIZE = 10;
  
  protected Article toArticle(DescriptionExtractor buildDesc, Document document)  {
    Article article = new Article();
    
    Meta meta = new Meta();
    Field field = document.getField(DocumentIndexer.FIELD_ID);
    meta.setId(field.stringValue());
    
    field = document.getField(DocumentIndexer.FIELD_TITLE);
    if(buildDesc != null) {
      try {
        meta.setTitle(buildDesc.build(field.stringValue()));
      } catch (Exception e) {
        meta.setTitle(field.stringValue());
      }
    } else {
      meta.setTitle(field.stringValue());
    }
    
    field = document.getField(DocumentIndexer.FIELD_IMAGE);
    if(field != null) meta.setImage(field.stringValue());
    
    field = document.getField(DocumentIndexer.FIELD_DATE);
    if(field != null) meta.setTime(field.stringValue());
    
    field = document.getField(DocumentIndexer.FIELD_DOMAIN);
    if(field != null) {
      Domain domain = new Domain();
      String [] elements = field.stringValue().split("\\.");
      if(elements.length > 2) {
        domain.setGroup(elements[0]);
        domain.setCategory(elements[1]);
        domain.setName(elements[2]);
        article.setDomain(domain);
      }
    }
    
    field = document.getField(DocumentIndexer.FIELD_DESC);
    String desc = "...";
    if(field != null) desc = field.stringValue();
    
    field = document.getField(DocumentIndexer.FIELD_CONTENT);
    String content = "...";
    if(field != null) content = field.stringValue();
    
    if(buildDesc == null) {
      meta.setDesc(desc);
    } else {
      try {
        meta.setDesc(buildDesc.build(desc, content));
      } catch (Exception e) {
        meta.setDesc(desc);
      }
    }
    
    article.setMeta(meta);
    
    return article;
  }

}
