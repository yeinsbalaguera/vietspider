/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Apr 28, 2008  
 */
public class DbIndexer {

  private IndexWriter writer;
  private volatile boolean isOptimize = false;
  
  public DbIndexer() {
    writer = createIndexModifier(true);
  }

  public void index(IndexEntry entry) {
    if(writer == null || entry == null) return;

    if(entry.getStatus() == IndexEntry.DELETE) {
      if(entry.getId() != null && !entry.getId().trim().isEmpty()) {
        try {
          writer.deleteDocuments(new Term(DocumentIndexer.FIELD_ID, entry.getId()));
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }  
      } else if(entry.getDate() != null && !entry.getDate().trim().isEmpty()) {
        try {
          writer.deleteDocuments(new Term(DocumentIndexer.FIELD_DATE, entry.getDate()));
          writer.optimize();
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }
      }
      return;
    } 

    try {
      Document document = DocumentIndexer.toDocument(entry);
      if(document != null) writer.addDocument(document);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }
  
  public void optimize() {
    if(writer == null) return;
    isOptimize = true;
    try {
      writer.optimize();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
    isOptimize = false;
  }
  
  public void commit() {
    if(writer == null) return;
    if(isOptimize) return;
    try {
      writer.commit();
    } catch (Exception exp) {
      LogService.getInstance().setThrowable(exp);
      try {
        writer.close();
        writer = createIndexModifier(true);
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
  }
  
  public  void close() {
    if(writer == null) return;
    try {
      writer.close();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }

  protected IndexWriter createIndexModifier (boolean recursive) {
    File file = UtilFile.getFolder("content/dbindexed/index/");

    MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
    if(file.exists() && file.listFiles().length > 0) {
      try {
        return new IndexWriter(file, new WhitespaceAnalyzer(), false, mfl);
      } catch (IOException e) {
        try {
          Directory directory  = FSDirectory.getDirectory(file.getAbsolutePath());
          if(IndexWriter.isLocked(directory)) IndexWriter.unlock(directory) ;
          if(recursive) return createIndexModifier(false); 
        } catch (Exception e2) {
          LogService.getInstance().setThrowable(e);
        }
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
        return null;
      }   
    } 

    try {
      if(!file.exists()) file.createNewFile();
      return new IndexWriter(file, new WhitespaceAnalyzer(), true, mfl);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      return null;
    }
  }

}
