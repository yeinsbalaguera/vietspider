/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index3;

import java.util.ArrayList;
import java.util.List;

import org.vietspider.bean.Article;
import org.vietspider.common.io.LogService;
import org.vietspider.db.database.MetaList;
import org.vietspider.index.result.CachedEntry2;
import org.vietspider.index.result.DocEntry;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 25, 2009  
 */
public class DefaultArticleHandler2 implements ArticleHandler2 {

  private HighlightBuilder descBuilder;
  private ArticleLoader articleLoader;
  
  public DefaultArticleHandler2(ArticleLoader loader, HighlightBuilder descBuilder) {
    this.articleLoader = loader;
    this.descBuilder = descBuilder;
  }

 public void loadArticles(MetaList metas, CachedEntry2 pageIO) {
    metas.setTotalPage(pageIO.getTotalPage(metas.getPageSize()));
    int page = metas.getCurrentPage();
    List<DocEntry> entries = pageIO.loadPageByAsc(page, metas.getPageSize());

    List<Article> articles = new ArrayList<Article>(metas.getPageSize());
    if(entries.size() < 1) {
      metas.setData(articles);
      return ;
    }

    for(int i = 0; i < entries.size(); i++) {
      try {
        String metaId = String.valueOf(entries.get(i).getMetaId());
        Article article = articleLoader.load(metaId);
        if(article == null) continue;

        descBuilder.build(article);
        articles.add(article);

      } catch (Exception e) {
        LogService.getInstance().setMessage(e, e.toString());
      } 
    }

    metas.setData(articles);
  }


}
