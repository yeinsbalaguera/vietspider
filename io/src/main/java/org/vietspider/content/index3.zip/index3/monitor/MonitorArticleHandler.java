/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index3.monitor;

import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.vietspider.bean.Article;
import org.vietspider.bean.Relation;
import org.vietspider.common.io.LogService;
import org.vietspider.content.index3.HighlightBuilder;
import org.vietspider.db.database.DatabaseService;
import org.vietspider.index.result.DocEntry;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 25, 2009  
 */
public class MonitorArticleHandler  {

  private List<Relation> saveRelations = new ArrayList<Relation>();
  //  private List<ContentIndex> removeIndexs = new ArrayList<ContentIndex>();
  private List<Article> removeArticles = new ArrayList<Article>();
  private HighlightBuilder descBuilder;

  public MonitorArticleHandler() {
  }

  public MonitorArticleHandler(HighlightBuilder descBuilder) {
    this.descBuilder = descBuilder;
  }

  public void loadArticles(List<DocEntry> entries) {
    int start = 0;
    int size = entries.size();
    //    System.out.println(" tong cong co "+ size);
    int end = Math.min(50, size);
    while(start < size) {
      //      System.out.println(" start "+ start+  " end "+ end);
      load(entries.subList(start, end));
      start = end;
      end = Math.min(start + 50, size);
    }
    commit();
  }

  public int handleArticles(ConcurrentLinkedQueue<Article> articles) {
    List<Computor.Element> elements = new ArrayList<Computor.Element>(50);

    Computor computor = new Computor(removeArticles, saveRelations);
    int counter = 0;

    Iterator<Article> iterator = articles.iterator();
    //    System.out.println("tinh toan memory "+articles.size());
    while(iterator.hasNext()) {
      Article article = iterator.next();
      iterator.remove();
      counter++;

      if(article.getDomain() == null 
          || "XML".equals(article.getDomain().getGroup())) {
        article.setStatus(Article.DELETE);
        removeArticles.add(article);  
        continue;
      }

      String host = null;
      try {
        host = new URL(article.getMeta().getSource()).getHost();
      } catch (Exception e) {
      }
      if(host == null) continue;

      Integer score = new Integer((int)article.getScore());
      computor.compute(elements, new Computor.Element(article, score, host));
    }
    //    System.out.println("tinh toan memory "+articles.size());
    commit();
    return counter;
  }

  private void load(List<DocEntry> subEentries) {
    List<Computor.Element> elements = new ArrayList<Computor.Element>(50);

    Computor computor = new Computor(removeArticles, saveRelations);

    for(int i = 0; i < subEentries.size(); i++) {
      String metaId = String.valueOf(subEentries.get(i).getMetaId());
      Article article = null;
      try {
        article = DatabaseService.getLoader().loadArticle(metaId, Article.SIMPLE);
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
        continue;
      }
      if(article == null || article.getMeta() == null) continue;

      if(article.getDomain() == null 
          || "XML".equals(article.getDomain().getGroup())) {
        article.setStatus(Article.DELETE);
        removeArticles.add(article);  
        continue;
      }


      article.setScore(subEentries.get(i).getScore());

      descBuilder.build(article);

      String host = null;
      try {
        host = new URL(article.getMeta().getSource()).getHost();
      } catch (Exception e) {
      }
      if(host == null) return;

      Integer score = new Integer((int)article.getScore());
      computor.compute(elements, new Computor.Element(article, score, host));
    }
  }

  private void commit() {
    if(saveRelations.size() < 1 && removeArticles.size() < 1) return;

    //    System.out.println("chuan bi commit "+ saveRelations.size()+ " / "+ removeContents.size());

    try {
      DatabaseService.getSaver().save(saveRelations);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }

    //    TpDatabases tpDatabases = TpDatabases.getInstance();
    for(int i = 0; i < removeArticles.size(); i++) {
      //      ContentIndex contentIndex = removeIndexs.get(i);

      //        IDatabases.getInstance().save(removeArticles.get(i));
      try {
        DatabaseService.getSaver().save(removeArticles.get(i));
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }

      //      System.out.println(" delete element "+ contentIndex.getId());
      //      if(tpDatabases != null) {
      //        tpDatabases.getDbIndexers().index(contentIndex);  
      //      } else {
      //        DbIndexers.getInstance().index(contentIndex);
      //      }
    }
  }

  /*  public List<ArticleEntry> loadArticles(List<DocEntry> entries) throws Exception {
    List<ArticleEntry> articleEntries = new ArrayList<ArticleEntry>();
    for(int i = 0; i < entries.size(); i++) {
      DocEntry entry = entries.get(i);
      if(entry.getStatus() == -1) continue;
      String metaId = String.valueOf(entry.getMetaId());
      Article article = IDatabases.getInstance().loadArticle(metaId);
      if(article == null) continue;
      ArticleEntry articleEntry = new ArticleEntry(entry, article);
      articleEntries.add(articleEntry);
    }
    return articleEntries;
  }
   */
}
