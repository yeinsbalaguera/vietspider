/***************************************************************************
 * Copyright 2003-2007 by VietSpider - All rights reserved.                *    
 **************************************************************************/
package org.vietspider.content.index3.monitor;

import java.util.Collections;
import java.util.List;

import org.vietspider.bean.Article;
import org.vietspider.common.io.LogService;
import org.vietspider.content.index3.ArticleLoader;
import org.vietspider.content.index3.HighlightBuilder;
import org.vietspider.db.ContentIndexers;
import org.vietspider.db.database.DatabaseService;
import org.vietspider.index.CoreDbIndexers;
import org.vietspider.index.SearchQuery;
import org.vietspider.index.result.DocEntry;

public class MonitorDataSearcher2 {

  private ArticleLoader articleLoader;

  public MonitorDataSearcher2() {
  }
  
  ArticleLoader getArticleLoader() {
    if(articleLoader != null) return articleLoader;
    articleLoader = new ArticleLoader() {
      public Article load(String id) {
        try {
          return DatabaseService.getLoader().loadArticle(id);
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
          return null;
        }
      }
    };
    return articleLoader;
  }
  
  public void setArticleLoader(ArticleLoader articleLoader) {
    this.articleLoader = articleLoader;
  }

  public void search(SearchQuery query) throws Exception {
    HighlightBuilder builder = new HighlightBuilder(query.getLPattern());
    MonitorArticleHandler handler = new MonitorArticleHandler(builder);
    handler.loadArticles(startSearch(query));
  }
  
  private List<DocEntry> startSearch(SearchQuery query) throws Exception {
//    File tempFile = UtilFile.getFolder("content/search/");
    CoreDbIndexers dbIndexers = ContentIndexers.getInstance().getDbIndexers();
    DbMonitorSearcher2 searcher = new DbMonitorSearcher2(dbIndexers, "content/cindexed");
    List<DocEntry> entries = searcher.search(query);
    Collections.sort(entries, new DocEntry.DocEntryComparator());
    return entries;
  }

}


