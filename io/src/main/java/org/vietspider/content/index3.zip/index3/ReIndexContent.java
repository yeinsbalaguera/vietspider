/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index3;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.vietspider.bean.Article;
import org.vietspider.bean.Content;
import org.vietspider.bean.Meta;
import org.vietspider.common.Application;
import org.vietspider.common.io.DataReader;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;
import org.vietspider.content.nlp.CityCodeDetector;
import org.vietspider.db.ContentIndex;
import org.vietspider.db.ContentIndexers;
import org.vietspider.db.database.DatabaseService;
import org.vietspider.db.database.DatabaseReader.IArticleIterator;
import org.vietspider.html.HTMLDocument;
import org.vietspider.html.parser.HTMLParser2;
import org.vietspider.html.renderer.TextRenderer;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Sep 8, 2009  
 */
public class ReIndexContent {
  
  private HTMLParser2 parser = new HTMLParser2();
  private CityCodeDetector regionDetector = new CityCodeDetector();

  //http://192.168.1.31:4529/vietspider/DOMAIN/1/01.10.2009
  public void reindex(String date) throws Exception {
//    if(IDatabases.getInstance() instanceof EntireDatabase) {
    if(DatabaseService.isMode(DatabaseService.ENTIRE)) {
      reindex1(null);
      return;
    }
    
    File file  = new File(UtilFile.getFolder("system"), "reindex");
    if(file.exists() && file.length() > 0) {
      byte [] bytes = new DataReader().load(file);
      String text = new String(bytes, Application.CHARSET);
      String [] elements = text.split("\n");
      for(int i = 0; i < elements.length; i++) {
        date = elements[i].trim();
        if(date.isEmpty()) continue;
        reindex1(date);
      }
      file.delete();
      return;
    }
  }
  
  public void reindex1(String date) throws Exception {
//    System.out.println(" ====  > "+date);
    Date dateInst = null; 
    if(date != null) {
      SimpleDateFormat dateFormat = CalendarUtils.getDateFormat();
      dateInst = dateFormat.parse(date);
    }
//    SimpleDateFormat folderFormat = CalendarUtils.getFolderFormat();
//    String folderName = folderFormat.format(dateInst);
    
    IArticleIterator iterator = DatabaseService.getLoader().getIterator(dateInst, true);
//    IDatabases databases = IDatabases.getInstance();
//    ArticleDatabase database = (ArticleDatabase)databases.getDatabase(dateInst, true);
//    IArticleIterator iterator = database.getIterator() ;

//    RandomAccessFile random = null;
    try {
//      random = new RandomAccessFile(file, "r");
//      long length  = random.length();

      LogService.getInstance().setMessage(null, "Start reindex " +  date+"...");
//      while(random.getFilePointer() < length) {
      while(iterator.hasNext()) {
//        String metaId = String.valueOf(random.readLong());
//        int status  = random.readInt();
//        if(status == -1) continue;
        try {
          Article article = iterator.next(Article.SIMPLE); //DatabaseService.getLoader().loadArticle(metaId);
          ContentIndex contentIndex = toIndexContent(article);
          if(contentIndex == null) continue;
          ContentIndexers.getInstance().index(contentIndex);
        } catch (Throwable e) {
          LogService.getInstance().setMessage(new Exception(e), e.toString());
        }
      }
      LogService.getInstance().setMessage(null, "Finish reindex " +  date+"...");
    } catch (Throwable e) {
      LogService.getInstance().setThrowable(e);
      LogService.getInstance().setMessage(null, "Reindex " +  date + " is failed!");
    } finally {
//      try {
//        if(random != null) random.close();
//      } catch (Exception e) {
//        LogService.getInstance().setThrowable(e);
//      }
    }
  }

  private ContentIndex toIndexContent(Article article)  throws Exception  {
    ContentIndex entry = new ContentIndex();

    Meta meta = article.getMeta();
    Content content = article.getContent();

    if(meta == null || content == null) return null;

    entry.setId(meta.getId());
    entry.setTitle(meta.getTitle());
    entry.setDescription(meta.getDesc());

    StringBuilder builder = new StringBuilder();
    builder.append(meta.getTitle()).append('\n');
    builder.append(meta.getDesc()).append('\n');
    
    HTMLDocument document = parser.createDocument(content.getContent().toCharArray());
    TextRenderer textRenderer = new TextRenderer(document.getRoot(), TextRenderer.RENDERER);
    builder.append(textRenderer.getTextValue());
    
    String region = meta.getPropertyValue("region");
    if(region == null || region.trim().isEmpty()) {
      region = regionDetector.detect(builder.toString());
      meta.putProperty("region", region);
    }
    
    entry.setContent(builder.toString());
    entry.setRegion(region);

    String date = meta.getTime();
    int index = date.indexOf(' ');
    if(index  < 0)  return null;
    date = date.substring(0, index);
    //    System.out.println(" thay co "+ date);
    entry.setDate(date);

    return entry;
  }

  public static void main(String[] args) throws Exception {
    File file = new File("D:\\java\\headvances3\\trunk\\vietspider\\startup\\src\\test\\data\\");
    System.setProperty("vietspider.data.path", file.getCanonicalPath());
    ReIndexContent reindex  = new ReIndexContent();
    reindex.reindex("07/09/2009");

  }


}
