/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index3;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.document.Document;
import org.vietspider.bean.Article;
import org.vietspider.common.io.LogService;
import org.vietspider.db.ContentIndex;
import org.vietspider.db.database.MetaList;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 25, 2009  
 */
public class DefaultArticleHandler implements ArticleHandler {

  private HighlightBuilder descBuilder;
  private ArticleLoader articleLoader;
  
  public DefaultArticleHandler(ArticleLoader loader, HighlightBuilder descBuilder) {
    this.articleLoader = loader;
    this.descBuilder = descBuilder;
  }

 public void loadArticles(MetaList metas, File [] files) {
    metas.setTotalPage(files.length / metas.getPageSize() + 1);
    int page = metas.getCurrentPage();
    int start = (page - 1) * metas.getPageSize();
    int end = page * metas.getPageSize();

    //    DbCleanerService dbCleaner = new DbCleanerService();
    List<Article> articles = new ArrayList<Article>(metas.getPageSize());
    if(start < 0) {
      metas.setData(articles);
      return ;
    }

    for(int i = start; i < Math.min(files.length, end); i++) {
      FileInputStream inputStream = null;
      try {
        inputStream = new FileInputStream(files[i]);
        ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
        Document doc = (Document)objectInputStream.readObject();

        ContentIndex contentIndex = new ContentIndex();
        contentIndex.fromDocument(doc);

        Article article = articleLoader.load(contentIndex.getId());
        if(article == null) continue;
        
        descBuilder.build(article);
        articles.add(article);

        objectInputStream.close();
      } catch (Exception e) {
        LogService.getInstance().setMessage(e, e.toString());
        files[i].delete();
      } finally {
        try {
          if(inputStream != null) inputStream.close();
        } catch (Exception e) {
        }
      }
    }

    metas.setData(articles);
  }
 

}
