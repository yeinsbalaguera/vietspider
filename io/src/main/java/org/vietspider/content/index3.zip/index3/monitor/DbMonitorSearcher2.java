/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.index3.monitor;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.TopDocs;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.index.CoreDbIndexers;
import org.vietspider.index.IIndexEntry;
import org.vietspider.index.IndexSearchers;
import org.vietspider.index.SearchQuery;
import org.vietspider.index.result.DocEntry;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 4, 2008  
 */
class DbMonitorSearcher2 {

  private File[] indexFiles;
  private String indexFolder;
  private int size = 500;

  private CoreDbIndexers dbIndexers;
  //  private List<DocEntry> entries = new ArrayList<DocEntry>();

  DbMonitorSearcher2(CoreDbIndexers indexers, String _indexFolder) {
    this.dbIndexers = indexers;
    this.indexFolder = _indexFolder;
  }

  //  List<DocEntry> getEntries() { return entries; }

  List<DocEntry> search(SearchQuery query) throws Exception {
    List<DocEntry> entries = new ArrayList<DocEntry>();
    indexFiles = IndexSearchers.getInstance().getFiles(indexFolder);
    if(indexFiles.length < 1) return entries;
    
    query.setTotal(search1(entries, query.createQuery()));
//    System.out.println(" ta duoc "+ entries.size());
    return entries;
  }

  int search(List<DocEntry> entries, File indexFile, Query query, int max) throws Exception {
//    System.out.println("search "+ indexFile.getName() +  " max " + max);
    Searcher indexSearcher = IndexSearchers.getInstance().getSearcher(dbIndexers, indexFile, false);
//    System.out.println("max doc "+indexSearcher.maxDoc());

    TopDocs topDocs = indexSearcher.search(query, null, max);
    ScoreDoc [] docs = topDocs.scoreDocs;

//              System.out.println(" thay co ket qua   : "+ docs.length);
    int maxDoc = Math.min(docs.length, max);
    for(int i = 0; i < maxDoc; i++) {
      if(size < 1) break;
      int docId = docs[i].doc;
      Document doc = indexSearcher.doc(docId);
      //        doc.setBoost(hitDocs[i].getScore());
      if(doc == null) continue;
      Field field = doc.getField(IIndexEntry.FIELD_ID);
      if(field == null) continue;
      long id  = Long.parseLong(field.stringValue());
      int score = (int)(docs[i].score*1000);
//      System.out.println(doc + " / "+ score);
      if(score < 100) continue;
      
//      System.out.println(field.stringValue() + " / " + docs[i].score);

      //        System.out.println(field.stringValue() + " / " + hitDocs[i].getScore());
      DocEntry entry = new DocEntry(id, score);
      //          System.out.println(field.stringValue() + " / " + score);
      entries.add(entry);
      size--;
    }
    
    return docs.length;
  }

  private int search1(List<DocEntry> entries, Query query) {
    int total = 0;
    for(int i = 0; i < Math.min(3, indexFiles.length); i++) {
      try {
        total += search(entries, indexFiles[i], query, 300);
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }

    File tempIndex = UtilFile.getFolder("content/temp/indexed");
    try {
      total += search(entries, tempIndex, query, 5000);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
    return total;
  }


}
