/***************************************************************************
 * Copyright 2003-2007 by VietSpider - All rights reserved.                *    
 **************************************************************************/
package org.vietspider.content.index3;

import java.io.File;

import org.vietspider.bean.Article;
import org.vietspider.common.io.LogService;
import org.vietspider.db.ContentIndexers;
import org.vietspider.db.database.DatabaseService;
import org.vietspider.db.database.MetaList;
import org.vietspider.index.ACachedSearcher;
import org.vietspider.index.CoreDbIndexers;
import org.vietspider.index.DbCachedSearcher;
import org.vietspider.index.DbCachedSearcher2;
import org.vietspider.index.IndexSearchers;
import org.vietspider.index.SearchQuery;
import org.vietspider.index.result.CachedEntry2;

public class ContentSearcher2 {
  
  public final static short SIMPLE = 0;
  public final static short TEMP_INDEX = 1;
  
  private final static long EXPIRE = 15*60*1000l;

  private ArticleLoader articleLoader;
  private File tempFolder;
  private short type = 0;
  
  public ContentSearcher2(short type, File tempFolder) {
    this.type = type;
    this.tempFolder = tempFolder;
  }
  
  public ArticleLoader getArticleLoader() {
    if(articleLoader != null) return articleLoader;
    articleLoader = new ArticleLoader() {
      public Article load(String id) {
        try {
          return DatabaseService.getLoader().loadArticle(id);
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
          return null;
        }
      }
    };
    return articleLoader;
  }
  
  public void setArticleLoader(ArticleLoader articleLoader) {
    this.articleLoader = articleLoader;
  }

  public void search(MetaList metas, SearchQuery query) throws Exception {
    HighlightBuilder descExtractor = new HighlightBuilder(query.getLPattern());
    ArticleHandler2 articleHandler = new DefaultArticleHandler2(getArticleLoader(), descExtractor);
    search(metas, query, articleHandler);
  }

  public void search(MetaList metas, SearchQuery query, ArticleHandler2 articleHandler) throws Exception {
    CachedEntry2 cachedEntry = IndexSearchers.getInstance().getCachedEntry(query.getCode()) ;
    boolean isNew = false;
    if(cachedEntry  == null) {
      cachedEntry = startSearch(query);
      isNew = true;
    } 
    
//    else {
//      IndexSearchers.getInstance().putCachedEntry(query.getCode(), cachedEntry);
//    }
   
    if(cachedEntry == null) return;
    articleHandler.loadArticles(metas, cachedEntry);
    if(isNew && metas.getData().size() > 9) {
      IndexSearchers.getInstance().putCachedEntry(query.getCode(), cachedEntry);
    }
  }
  
  private CachedEntry2 startSearch(SearchQuery query) throws Exception {
//    File tempFile = UtilFile.getFolder("content/search/");
    File tempFile = new File(tempFolder, String.valueOf(query.getCode())+".idx");
    
    CoreDbIndexers dbIndexers = ContentIndexers.getInstance().getDbIndexers();
    
    ACachedSearcher cachedSearcher = null;
    if(type == SIMPLE) {
      cachedSearcher = new DbCachedSearcher(dbIndexers, "content/cindexed", tempFile);
    } else {
      cachedSearcher = new DbCachedSearcher2(dbIndexers, "content/cindexed", tempFile);  
    }
    
    if(tempFile.exists() && tempFile.length() > 0 
        && System.currentTimeMillis() - tempFile.lastModified() < EXPIRE) {
      return cachedSearcher.getCachedEntry();
    }
    
    tempFile.delete();
    
//    System.out.println(tempFile.hashCode()+ " : "+ tempFile.getAbsolutePath());
    
    try {
      tempFile.createNewFile();
    } catch (Exception e) {
      LogService.getInstance().setMessage(e, e.toString());
    }
    
//    BooleanQuery booleanQuery = query.createQuery();
//    System.out.println("search query " + booleanQuery);
    cachedSearcher.search(query);
    
    return cachedSearcher.getCachedEntry();
  }

}


