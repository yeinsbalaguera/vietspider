/***************************************************************************
 * Copyright 2003-2007 by VietSpider - All rights reserved.                *    
 **************************************************************************/
package org.vietspider.content.index3;

import java.io.File;
import java.util.Comparator;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.TermQuery;
import org.vietspider.bean.Article;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.db.ContentIndex;
import org.vietspider.db.ContentIndexers;
import org.vietspider.db.database.DatabaseService;
import org.vietspider.db.database.MetaList;
import org.vietspider.index.CommonSearchQuery;
import org.vietspider.index.CoreDbIndexers;
import org.vietspider.index.DbCachedSearcher2;
import org.vietspider.index.QueryParser;
import org.vietspider.serialize.NodeMap;

public class ContentSearcher {

  private Comparator<File> comparator;
  private ArticleLoader articleLoader;

  public ContentSearcher() {
    comparator = new Comparator<File>(){

      public int compare(File o1, File o2) {
        try {
          int boost1 = getIntValue(o1.getName());
          int boost2 = getIntValue(o2.getName());
          return boost2 - boost1;
        } catch (Exception e) {
          return 0;
        }
      }
      
      private int getIntValue(String name) {
        try {
          int idx = name.indexOf('.');
          if(idx > 0) name = name.substring(idx+1);
          return Integer.parseInt(name);
//          return (int)(Float.parseFloat(name)*1000000);
        } catch (Exception e) {
          return 0;
        }
      }
    };
  }
  
  public ArticleLoader getArticleLoader() {
    if(articleLoader != null) return articleLoader;
    articleLoader = new ArticleLoader() {
      
      public Article load(String id) {
        try {
          return DatabaseService.getLoader().loadArticle(id);
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
          return null;
        }
      }
    };
    return articleLoader;
  }
  
  public void setArticleLoader(ArticleLoader articleLoader) {
    this.articleLoader = articleLoader;
  }

  public void searchByQuery(MetaList metas, String queryValue) throws Exception {
    File tempFolder = startSearch(queryValue);
    File [] files = UtilFile.listFiles(tempFolder, null, comparator);
    if(files == null) return;
    new DefaultArticleHandler(getArticleLoader(), null).loadArticles(metas, files);
  }

  public void searchByDomain(MetaList metas, String [] values) throws Exception {
    File tempFolder = searchByDomain(values);
    File [] files = UtilFile.listFiles(tempFolder, null, comparator);

    if(files == null) return;
    new DefaultArticleHandler(getArticleLoader(), null).loadArticles(metas, files);
  }

  public File searchByDomain(String [] fieldValues) throws Exception {
    BooleanQuery booleanQuery = new BooleanQuery(true);
    for(int i = 0; i < fieldValues.length; i++) {
      TermQuery query = new TermQuery(new Term(ContentIndex.FIELD_DOMAIN, fieldValues[i]));
      booleanQuery.add(new BooleanClause(query, BooleanClause.Occur.SHOULD));
    }

    StringBuilder builder = new StringBuilder();
    for(String ele : fieldValues) {
      if(builder.length() > 0) builder.append('/');
      builder.append(ele);
    }

    String code = String.valueOf(builder.toString().hashCode());
    File tempFolder = UtilFile.getFolder("content/temp/search/" + code +"/");
    File [] files = UtilFile.listFiles(tempFolder);
    if(files != null && files.length > 0 
        && System.currentTimeMillis() - files[0].lastModified() < 5*60*1000l) return tempFolder;

//    File folder = UtilFile.getFolder("content/cindexed");
    
    CoreDbIndexers dbIndexers = ContentIndexers.getInstance().getDbIndexers();
    DbCachedSearcher2 searcher = new DbCachedSearcher2(dbIndexers, "content/cindexed", tempFolder);

    searcher.search(new SimpleSearchQuery(booleanQuery));
    return tempFolder;
  }
  
  public void search(MetaList metas, String pattern) throws Exception {
    HighlightBuilder descExtractor = new HighlightBuilder(pattern);
    ArticleHandler articleHandler = new DefaultArticleHandler(getArticleLoader(), descExtractor);
    search(metas, pattern, articleHandler);
  }

  public void search(MetaList metas, String pattern, ArticleHandler articleHandler) throws Exception {
    File tempFolder = startSearch(pattern);
    File [] files = UtilFile.listFiles(tempFolder, null, comparator);
    if(files == null) return;
    articleHandler.loadArticles(metas, files);
  }

  private File startSearch(String pattern) throws Exception {
    File tempFolder = UtilFile.getFolder("content/temp/search/" + String.valueOf(pattern.hashCode())+"/");
    File [] files = UtilFile.listFiles(tempFolder);
    if(files != null && files.length > 0 
        && System.currentTimeMillis() - files[0].lastModified() < 15*60*1000l) return tempFolder;
    
    QueryParser parser = new QueryParser();
    BooleanQuery booleanQuery = parser.createQuery(pattern);
    
//    System.out.println("search query " + booleanQuery);
    
//    File folder = UtilFile.getFolder("content/cindexed");
    
    CoreDbIndexers dbIndexers = ContentIndexers.getInstance().getDbIndexers();
    DbCachedSearcher2 searcher = new DbCachedSearcher2(dbIndexers, "content/cindexed", tempFolder);
//    DbCachedSearcher searcher = new DbCachedSearcher(folder, tempFolder);

    searcher.search(new SimpleSearchQuery(booleanQuery));
    return tempFolder;
  }
  
  @NodeMap("simple-query")
  public static class SimpleSearchQuery extends CommonSearchQuery {
    
    private BooleanQuery query;
    
    SimpleSearchQuery(BooleanQuery query) {
      this.query = query;
    }

    public BooleanQuery createQuery() throws Exception { return query; }

    public void savePattern() {
    }
    
  }

}


