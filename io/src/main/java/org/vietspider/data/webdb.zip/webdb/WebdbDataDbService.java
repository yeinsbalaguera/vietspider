/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.data.webdb;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.headvances.storage.v3.StorageException;
import org.headvances.vietspider.CrawlerConfig;
import org.headvances.vietspider.SystemProperties;
import org.vietspider.bean.Article;
import org.vietspider.bean.Content;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Meta;
import org.vietspider.common.Application;
import org.vietspider.common.io.LogService;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Dec 29, 2008  
 */
//dataCleaner=org.vietspider.data.DefaultDataCleaner
//dataGetter=org.vietspider.data.webdb.WebdbDataGetter
//dataSaver=org.vietspider.data.webdb.WebdbDataSetter
//dataUtils=org.vietspider.data.DefaultDataUtils

public class WebdbDataDbService extends Thread {
  
  private static WebdbDataDbService INSTANCE;
  
  public static synchronized WebdbDataDbService getService() {
    if(INSTANCE == null) {
      INSTANCE  = new WebdbDataDbService();
    }
    return INSTANCE;    
  }
  
  private volatile int commitSize = 500 ;
  private volatile int commitPeriod = 30*1000 ;
  
  private volatile int sleep = 15*1000;
  
  protected volatile Queue<Article> waitData;
  private volatile int dataCounter = 0; 
  private long lastCommitTime = 0 ;
  private volatile boolean execute = true;
  
  private volatile WebdbBakup webdbBakup;
  private volatile WebdbDataPersistence persistence;
  private volatile RemoteDatabase remote;
  
  protected WebdbDataDbService()  {
    webdbBakup = new WebdbBakup();
    remote = new RemoteDatabase();
    waitData = new ConcurrentLinkedQueue<Article>();
    try {
      persistence = new WebdbDataPersistence();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      System.exit(0);
    }
//    remoteDb = new RemoteWebDb();
    
    
    Application.addShutdown(new Application.IShutdown() {
      public void execute() {
        execute = false;
        try {
          if(persistence != null) persistence.commit();
          remote.sync();
         /*DBRepository repo = persistence.getDBRepository() ;
          for(DBTypeRepository dbtype : repo.getDBTypes()) {
            Segment segment = dbtype.getCurrentSegment() ;
            segment.commit() ;
            segment.getSegmentIndexer().commit();
          }*/
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }
        
        try {
          if(persistence != null)  persistence.close();
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }
      }
    });
    
    String expire = SystemProperties.getInstance().getValue("delete.expire.data");
    if("true".equalsIgnoreCase(expire)) {
      SystemProperties.getInstance().putValue("delete.expire.data", "false");
    }
    
    int totalExecutor = CrawlerConfig.TOTAL_EXECUTOR;
    if(totalExecutor >= 20 && totalExecutor < 30) {
      commitSize = 700 ;
      commitPeriod = 45*1000 ;
      sleep = 25*1000;
    } else if(totalExecutor >= 30 && totalExecutor < 50) {
      commitSize = 1000 ;
      commitPeriod = 60*1000 ;
      sleep = 30*1000;
    } else if(totalExecutor >= 50) {
      commitSize = 3000 ;
      commitPeriod = 2*60*1000 ;
      sleep = 45*1000;
    }
    
    
    
    this.start();
  }
  
  public void save(Meta meta, Domain domain, Content content) throws Exception {
    waitData.add(new Article(domain, meta, content));
    dataCounter++;
  }
  
  public List<Article> loadArticles(String...metaIds) throws Exception {
    List<Article> articles = new ArrayList<Article>();
    Iterator<Article> iterator = waitData.iterator();
    while(iterator.hasNext()) {
      Article article = iterator.next();
      for(int i = 0; i < metaIds.length; i++) {
        if(metaIds[i] == null) continue;
        if(article.getMeta().getId().equals(metaIds[i])) {
          articles.add(article);
          metaIds[i] = null;
        }
      }
    }
    List<Long> listId = new ArrayList<Long>();
    for(int i = 0; i < metaIds.length; i++) {
      if(metaIds[i] == null) continue;
      try {
        listId.add(Long.parseLong(metaIds[i]));
      } catch (Exception e) {
      }
    }
    long [] ids = new long[listId.size()];
    for(int i = 0; i < listId.size(); i++) {
      ids[i] = listId.get(i);
    }
    
    if(persistence == null || persistence.isClose()) return articles;
    
    articles.addAll(persistence.search(ids));
    
    return articles;
  }
  
  public void run() {
    while(execute) {
      boolean commit = false ;
      if(dataCounter > commitSize) {
        commit = true ;
      } else if(System.currentTimeMillis() - lastCommitTime > commitPeriod) {
        commit = true ;
      }
      
      boolean error = false;
      
      if(commit) {
        int total = 0;
        while(!waitData.isEmpty()) {
          Article article = waitData.poll();
          total++;
          Meta meta = article.getMeta();
          Domain domain = article.getDomain();
          Content content = article.getContent();
          try {
            persistence.save(meta, domain, content);
            remote.add(domain, meta, content);
          } catch (StorageException e) {
            error = true;
            Application.addError(WebdbDataDbService.this);
            LogService.getInstance().setThrowable("SOURCE", e, meta.getSource());
          } catch (Exception e) {
            LogService.getInstance().setThrowable("SOURCE", e, meta.getSource());
          }
        }
        
        
        if(total > 0){
//          new Thread() {
//            public void run() {
//              remoteDb.commit();
//            }
//          }.start();
          
          remote.sync();

          try {
            persistence.commit();
          } catch (FileNotFoundException e) {
            error = true;
            Application.addError(WebdbDataDbService.this);
            LogService.getInstance().setThrowable(e);
            System.exit(0);
          } catch (Exception e) {
            error = true;
            Application.addError(WebdbDataDbService.this);
            LogService.getInstance().setThrowable(e);
          }
        }
        
        dataCounter -= total;
        if(dataCounter < 0) dataCounter = 0;
        lastCommitTime = System.currentTimeMillis() ;
      }
      
      if(error) {
        try {
          if(persistence.checkAndRepair()) {
            Application.removeError(WebdbDataDbService.this);
          }
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }
      }
      
      try {
        //bakup data
        if(webdbBakup.isBackup()) {
          try {
            persistence.close();
            
            webdbBakup.backup();
            persistence = null;
            
          } catch (Exception e) {
            LogService.getInstance().setThrowable(e);
            Application.addError(WebdbDataDbService.this);
            persistence.checkAndRepair();
            Application.removeError(WebdbDataDbService.this);
          }
          persistence = new WebdbDataPersistence();
        }
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
      
      if(persistence == null || persistence.isClose()) {
        try {
          persistence = new WebdbDataPersistence();
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
          System.exit(0);
        }
      }
      
      try {
        Thread.sleep(sleep) ;
      } catch(Exception ex) {
      }
    }
  }
  
  public void setCommitSize(int commitSize) { this.commitSize = commitSize; }

  public void setCommitPeriod(int commitPeriod) { this.commitPeriod = commitPeriod; }
  
}
