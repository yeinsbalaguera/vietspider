/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.data.webdb;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.headvances.nlp.v2.LanguageDetector;
import org.headvances.nlp.v2.NLPEnv;
import org.headvances.nlp.v2.extract.CallBack;
import org.headvances.storage.v3.UTF8String;
import org.headvances.storage.v3.db.Database;
import org.headvances.storage.v3.db.DatabaseDefragmenter;
import org.headvances.util.html.HtmlUtil;
import org.headvances.util.html.URL;
import org.headvances.webdb.v3.storage.DB;
import org.headvances.webdb.v3.storage.DBRepository;
import org.headvances.webdb.v3.storage.DBSegment;
import org.headvances.webdb.v3.storage.WebPageExtraData;
import org.headvances.webdb.v3.storage.WebPageRecord;
import org.headvances.webdb.v3.storage.WebPageRecordId;
import org.headvances.webdb.v3.storage.WebPageType;
import org.headvances.webdb.v3.storage.analysis.DateExtractorCallBack;
import org.headvances.webdb.v3.storage.analysis.ExtractCallBack;
import org.headvances.webdb.v3.storage.index.HitDoc;
import org.headvances.webdb.v3.storage.index.HitDocs;
import org.headvances.webdb.v3.storage.index.SearchQuery;
import org.vietspider.bean.Article;
import org.vietspider.bean.Content;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Meta;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Mar 11, 2009  
 */
class WebdbDataPersistence {

  private volatile DBRepository dbrepo;

  private LanguageDetector languageDetector = new LanguageDetector();
  
  private volatile boolean close = false;
  
  WebdbDataPersistence() throws Exception {
    createDBRepository();
  } 

  public WebPageRecord save(Meta meta, Domain domain, Content content) throws Exception {
    String time = meta.getSourceTime() ;
    Date createdDate = null ;
    WebPageExtraData extraData = new WebPageExtraData() ;
    if(time == null) {
      time = meta.getTime() ;
      createdDate = CalendarUtils.getDateTimeFormat().parse(time) ;
    } else {
      createdDate = CalendarUtils.getDateTimeFormat().parse(time) ;
      extraData.setSourceTime(createdDate) ;
    }

    byte type = getType(domain.getGroup() + "." + domain.getCategory()) ;
    String uri = meta.getSource() ;
    String title = getTitle(meta, uri) ;
    String description = meta.getDesc() ;
    if(description != null) description = description.trim() ;

    else description = "" ;
    String resourceContent = content.getContent() ;
    if(resourceContent == null || resourceContent.length() == 0) {
//    System.out.println("  Content is null or empty");
      return null;
    }

    WebPageRecordId id = new WebPageRecordId(new URL(uri), type , createdDate.getTime()) ;

    WebPageRecord record = new WebPageRecord() ;
    record.setCacheData(extraData) ;
    record.setId(id) ;
    record.setVietspiderId(Long.parseLong(meta.getId())) ;
    record.setUri(new UTF8String(uri)) ;
    record.setTitle(new UTF8String(title)) ;
    record.setDescription(new UTF8String(description)) ;
    record.setSymbolicImageURL(new UTF8String(meta.getImage())) ;
    record.setContent(new UTF8String(resourceContent)) ;
    String contentData = HtmlUtil.removeTag(title + "\n" + description + "\n" + resourceContent, true) ;
    String language = languageDetector.getLanguage(contentData) ;
    record.setLanguage(new String[]{language}) ;

    DBRepository repo = getDBRepository() ;
    DB db = repo.getDBByType(record.getId().getType(), true) ;
//    DBTypeRepository dbtype = repo.getDBTypeRepository(record.getId().getType()) ;

    synchronized(this) {
//      WebdbMetaDataDbService.getService().insert(uri, id.getMD5Hash(), meta.getId(), domain.toString());
      int count = db.insert(record) ;
      if(count > 0) {
        db.getDBSegment().getSegmentIndexer().indexMeta(record, true) ;
      } else {
        db.getDBSegment().getSegmentIndexer().indexMeta(record, false) ;
      }
    }
    
    return record;
  }

  private byte getType(String category) {
    if(category.startsWith("STORY")) {
      return WebPageType.LITERATURE ;
    } else if(category.startsWith("LYRICS")) {
      return WebPageType.LYRIC ;
    } else if(category.equalsIgnoreCase("FORUM.Hỏi đáp")) {
      return WebPageType.FORUM ;
    } else if(category.equalsIgnoreCase("PROFILE.Kết bạn")) {
      return WebPageType.PROFILE ;
    } else if(category.equalsIgnoreCase("PROFILE.Người tìm việc")) {
      return WebPageType.PROFILE ;
    } else if(category.equalsIgnoreCase("PROFILE.Hồ sơ")) {
      return WebPageType.PROFILE ;
    } else if(category.equalsIgnoreCase("SEARCHTIONARY.Trang vàng")) {
      return WebPageType.YELLOWPAGE  ;
    } else if(category.equalsIgnoreCase("SEARCHTIONARY.Dictionary")) {
      return WebPageType.SEARCHTIONARY ;
    } else if(category.equalsIgnoreCase("SEARCHTIONARY.Wiki") || category.startsWith("WIKI")) {
      return WebPageType.SEARCHTIONARY ;
    } else { 
      int idx = category.indexOf('.') ;
      String type = category.substring(0, idx) ;
      return WebPageType.getTypeFromString(type) ;
    }
  }

  private String getTitle(Meta meta, String defaultValue) {
    try {
      String title = meta.getTitle() ;
      if(title == null || title.length() == 0) title = defaultValue ;
      return title ;
    } catch(Exception ex) {
      LogService.getInstance().setThrowable(ex);
    }
    return defaultValue ;
  }
  
  final void createDBRepository() throws Exception {
    synchronized (this) {
      CallBack[] callbacks = {new ExtractCallBack(), new DateExtractorCallBack() } ;
      NLPEnv nlpEnv = new NLPEnv("./conf/nlp", callbacks) ;
      NLPEnv.setCurrentInstance(nlpEnv) ;

      File dbdir = UtilFile.getFolder("content/webdb");
      if(!dbdir.exists()) dbdir.mkdirs();
      if(dbrepo != null) return;
      dbrepo = new DBRepository("webdb", dbdir.getAbsolutePath()) ;
    }
  }


  final DBRepository getDBRepository() throws Exception {
    return dbrepo ;
  }

 public final List<Article> search(long[] id) throws Exception {
    List<Article> articles = new ArrayList<Article>() ;
    
    List<HitDocs> hdocsHolder = new ArrayList<HitDocs>() ;
    DBRepository repository = getDBRepository() ;
    SearchQuery squery = new SearchQuery(WebPageType.ALL, id) ;
    List<HitDoc> holder = new ArrayList<HitDoc>(id.length) ;
    DB[] all = repository.getAllDB() ;
    for(DB db : all) {
      if(db.getDBSegment().getDatabase().isClose()) return articles;
      DBSegment segment = db.getDBSegment() ;
      segment.getSegmentIndexer().update() ;
      HitDocs hdocs = segment.getSegmentIndexer().search(squery, 1000, 10) ;
      //hdocs.setSegmentId(segment.getSegmentInfo().getSegmentId()) ;
      hdocsHolder.add(hdocs) ;
      HitDoc[] hitDoc = hdocs.getAll();
      for(int j = 0; j < hitDoc.length; j++) {
        //hitDoc[j].setSegmentId(hdocs.getSegmentId()) ;
        holder.add(hitDoc[j]) ;
        if(holder.size() == id.length) break; 
      }
      if(holder.size() == id.length) break;
    }

    DateFormat dateTimeFormat = CalendarUtils.getDateTimeFormat();
    for(int i = 0; i < holder.size(); i++) {
      HitDoc hdoc = holder.get(i) ;
      //SegmentId sid = hdoc.getSegmentId() ;
      WebPageRecord record = null;
      try {
        DB db = repository.getWebDBById(hdoc.getDBId()) ;
        record = db.get(hdoc) ;
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
      
      if(record != null) {
        String time = dateTimeFormat.format(new Date(record.getId().getTime())) ;
//      Domain domain = new Domain(time, "ARTICLE", "TW", "Vietnamnet") ;
        Meta meta = new Meta() ;
        meta.setId(String.valueOf(record.getVietspiderId())) ;
        meta.setSource(record.getUri().getString()) ;
        meta.setTitle(record.getTitle().getString()) ;
        meta.setDesc(record.getDescription().getString()) ;
        meta.setImage(record.getSymbolicImageURL().getString()) ;
        meta.setTime(time) ;

        Content content = new Content() ;
        content.setContent(record.getContent().getString()) ;
        articles.add(new Article(null, meta, content)) ;
      }
    }
    return articles ;
  }

  synchronized final void commit() throws Exception {
    DBRepository repo = getDBRepository() ;
    DB[] all = repo.getAllDB() ;
    for(DB db : all) {
      db.commit() ;
      try {
        db.getDBSegment().getSegmentIndexer().commit() ;
      } catch (IOException e) {
        try {
          db.getDBSegment().getSegmentIndexer().optimize();
        } catch (Exception e2) {
          LogService.getInstance().setThrowable(e2);
        }
        
        try {
          db.getDBSegment().getSegmentIndexer().close();
        } catch (Exception e2) {
          LogService.getInstance().setThrowable(e2);
        }
        
        db.getDBSegment().reopenIndexer();
      }
    }
  }
  
  public void close() throws Exception {
    close = true;
    DBRepository repo = getDBRepository() ;
    DB[] all = repo.getAllDB() ;
    for(DB db : all) {
      db.commit() ;
      db.getDBSegment().getSegmentIndexer().commit() ;
      db.close() ;
    }
  }
  
  public boolean isClose() { return close; }
  
  public final boolean checkAndRepair() throws Exception {
    DBRepository repo = getDBRepository() ;
    DB[] all = repo.getAllDB() ;
    LogService.getInstance().setMessage("APPLICATION", null, "Start repair webdb database!");
    boolean successfull = true;
    for(DB db : all) {
      Database<WebPageRecord, WebPageRecordId> database = db.getDBSegment().getDatabase();
      if(!database.hasError()) continue;
      DatabaseDefragmenter<WebPageRecord, WebPageRecordId> optimizer = 
        new DatabaseDefragmenter<WebPageRecord, WebPageRecordId>(database) ;
      optimizer.setIgnoreCorruptedRecord(true);
      try {
        optimizer.run() ;
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
        if(successfull) successfull = false;
      }
    }
    
    if(successfull) {
      LogService.getInstance().setMessage("APPLICATION", null, "Repair webdb database successful!");
    } 
    LogService.getInstance().setMessage("APPLICATION", null, "Finished repair webdb database!");
    return successfull;
  }
}
