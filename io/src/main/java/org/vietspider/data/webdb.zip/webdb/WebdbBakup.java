/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.data.webdb;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.headvances.vietspider.SystemProperties;
import org.vietspider.common.Application;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Mar 21, 2009  
 */
public class WebdbBakup  {

  private long lastBackup = 0;
  private int schedule = 0;
  private File folder;

  private String id = "";
  private long unit = 60*60*1000;
//  private long unit = 60*60*1000;

  public WebdbBakup() {
    SystemProperties properties = SystemProperties.getInstance();
    try {
      String value  = properties.getValue("webdb.bakup.last");
      if(value != null && value.trim().length() > 0) {
        lastBackup = Long.parseLong(value);
      } else {
        properties.putValue("webdb.bakup.last", "0");
      }
    } catch (Exception e) {
    }
    if(lastBackup < 1) {
      lastBackup = System.currentTimeMillis();
      properties.putValue("webdb.bakup.last", String.valueOf(lastBackup));
    }

    try {
      String value  = properties.getValue("webdb.bakup.schedule");
      if(value != null && value.trim().length() > 0) {
        schedule = Integer.parseInt(value);
      } else {
        properties.putValue("webdb.bakup.schedule", "0");
      }
    } catch (Exception e) {
    }

    try {
      id = properties.getValue("port");
    } catch (Exception e) {

    }

    String value  = properties.getValue("webdb.bakup.path");
    try {
      if(value != null && value.trim().length() > 0) {
        folder = new File(value);
      } else {
        folder = null;
      }
    } catch (Exception e) {
      LogService.getInstance().setThrowable("APPLICATION", e, value);
    }
    if(folder == null) folder = UtilFile.getFolder("content");

    if(!folder.exists()) { 
      folder = UtilFile.getFolder("content");
      LogService.getInstance().setMessage("APPLICATION", null, value + "  not exists.");
    } else  if(!folder.isDirectory()) { 
      folder = UtilFile.getFolder("content");
      LogService.getInstance().setMessage("APPLICATION", null, value + "  not is directory.");
    }
    //    System.out.println("se move vao "+ folder.getAbsolutePath());
    properties.putValue("webdb.bakup.path", folder.getAbsolutePath());
  }
  
  synchronized boolean isBackup() throws Exception {
    if(schedule < 1) return false;
    long current  = System.currentTimeMillis();
    if(current - lastBackup < schedule*unit) return false;


    File file  = UtilFile.getFolder("content/webdb/");
    if(!file.exists()) {
      lastBackup = System.currentTimeMillis();
      LogService.getInstance().setMessage(null, "Backup: Webdb is not found!");
      return false;
    }
    
    if(UtilFile.length(file) < 1024) {
      lastBackup = System.currentTimeMillis();
      LogService.getInstance().setMessage(null, "Backup: Webdb is small!");
      return false;
    }
    
    return true;
  }

  synchronized void backup() throws Exception  {
    LogService.getInstance().setMessage(null, "Start backup webdb data.");
    Application.addError(WebdbBakup.this);
    
    try {
      try {
        Thread.sleep(5*1000);
      } catch (Exception e) {
      }
      
      
      File file  = UtilFile.getFolder("content/webdb/");
      String location = file.getAbsolutePath();
      final File bakFile  = getFile(location+"bak", 0);
      
      for(int i = 0; i < 6; i++) { 
        if(file.renameTo(bakFile)) break;
        
        if(i >= 5) {
          LogService.getInstance().setMessage(null, "Backup: Cann't rename webdb to backup file!");
          lastBackup += 2*unit; 
          return;
        }
        
        try {
          Thread.sleep(5*1000);
        } catch (Exception e) {
        }
      }

      new Thread() {
        public void run() {
          try {
            moveBackup(bakFile);
          } catch (Exception e) {
            LogService.getInstance().setThrowable(e);
          }
        }
      }.start();

      lastBackup = System.currentTimeMillis();
      SystemProperties.getInstance().putValue("webdb.bakup.last", String.valueOf(lastBackup));
      LogService.getInstance().setMessage(null, "Finish backup webdb data.");
    } finally {
      Application.removeError(WebdbBakup.this);
    }
  }

  private void moveBackup(File file) throws Exception {
    if(folder == null || !folder.exists()) return;
    //    System.out.println(" chuan bi move to "+ folder.getAbsolutePath());
    if(file.getParentFile().getAbsolutePath().equals(folder.getAbsolutePath())) return;
    File logFile = new File(folder, file.getName()+".log");
    logFile.createNewFile();

    File newFile = new File(folder, file.getName()+"/");
    file.renameTo(newFile);

    logFile.delete();
  }

  private File getFile(String path, int index) throws Exception {
    Calendar calendar = Calendar.getInstance();
    StringBuilder builder = new StringBuilder(path).append('_').append(id);

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
    builder.append('_').append(dateFormat.format(calendar.getTime())).append('_');

    String value = builder.toString();

    File file = new File(value + String.valueOf(index)+"/");
    while(file.exists()) {
      if(file.isFile()) file.delete();
      index++;
      file = new File(value + String.valueOf(index)+"/");
    }
    return file;
  }
  

}
