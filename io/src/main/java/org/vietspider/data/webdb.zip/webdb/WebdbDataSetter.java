package org.vietspider.data.webdb;

import java.util.List;

import org.headvances.vietspider.database.DatabaseWriter;
import org.vietspider.bean.Content;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Image;
import org.vietspider.bean.Meta;
import org.vietspider.bean.Relation;

public class WebdbDataSetter implements DatabaseWriter {
  
  
  public WebdbDataSetter() throws Exception {
  }
  
  public void save(Meta meta, Domain domain, Content content) throws Exception {
    WebdbDataDbService.getService().save(meta, domain, content);
  }

  public void save(Relation relation) throws Exception {
//    System.out.println("call public void save(Relation relation) throws Exception");
  }

  public void save(List<Relation> relations) throws Exception {
//    System.out.println("call public void save(List<Relation> relations) throws Exception");
  }

  public void save(Image image) throws Exception {
    //System.out.println("call public void save(Image image) throws Exception") ;
  }

  public void set(Content content) throws Exception {
//    System.out.println("call public void set(Content content) throws Exception") ;
  }

}