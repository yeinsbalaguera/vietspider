package org.vietspider.data.webdb;

import java.util.List;

import org.headvances.vietspider.database.DatabaseReader;
import org.headvances.vietspider.database.MetaList;
import org.vietspider.bean.Article;
import org.vietspider.bean.Content;
import org.vietspider.bean.Domain;
import org.vietspider.bean.Image;
import org.vietspider.bean.Meta;
import org.vietspider.bean.Relation;

public class WebdbDataGetter implements DatabaseReader {
  
  public Article loadArticle(String id) throws Exception {
//    System.out.println("call public Article loadArticle(String id) throws Exception") ;
    List<Article> articles = WebdbDataDbService.getService().loadArticles(id);
    if(articles == null || articles.size() < 1) return null ;
//    for(int  i = 0; i < articles.size(); i++) {
//      System.out.println("=== >"+ articles.get(i).getMeta().getId());
//    }
//    if(articles.size() > 1) return null; 
//    {
//      throw new Exception("Expect return 0 or 1 result but return " + articles.size()) ;
//    }
    return articles.get(0) ;
  }

  public List<Article> loadArticles(String[] metaIds) throws Exception {
    return WebdbDataDbService.getService().loadArticles(metaIds) ;
  }

  public Content loadContent(String metaId) throws Exception {
    List<Article> articles = WebdbDataDbService.getService().loadArticles(metaId);
    if(articles == null || articles.size() == 0) return null ;
    if(articles.size() > 1) return null;
//    {
//      throw new Exception("Expect return 0 or 1 result but return " + articles.size()) ;
//    }
    return articles.get(0).getContent();
  }

  public List<Content> loadContentForMining() throws Exception {
//    System.out.println("call public List<Content> loadContentForMining() throws Exception") ;
    return null;
  }

  public List<String> loadDateFromDomain() throws Exception {
//    System.out.println("call public List<String> loadDateFromDomain() throws Exception") ;
    return null;
  }

  public Domain loadDomainById(String id) throws Exception {
//    System.out.println("call public Domain loadDomainById(String id) throws Exception") ;
    return null;
  }

  public Image loadImage(String id) throws Exception {
//    System.out.println("call public Image loadImage(String id) throws Exception") ;
    return null;
  }

  public List<Image> loadImages(String metaId) throws Exception {
//    System.out.println("call public List<Image> loadImages(String metaId) throws Exception") ;
    return null;
  }

  public Meta loadMeta(String id) throws Exception {
//    System.out.println("call public Meta loadMeta(String id) throws Exception") ;
    return null;
  }

  public void loadMetaFromDomain(Domain domain, MetaList list) throws Exception {
//    System.out.println("call public void loadMetaFromDomain(Domain domain, MetaList list) throws Exception") ;
  }

  public List<Meta> loadMetaFromDomain(String id) throws Exception {
//    System.out.println("call public List<Meta> loadMetaFromDomain(String id) throws Exception") ;
    return null;
  }

  public List<Relation> loadRelation(String metaId) throws Exception {
//    System.out.println("call public List<Relation> loadRelation(String metaId) throws Exception") ;
    return null;
  }
}