/***************************************************************************
 * Copyright 2001-2007 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.monitor;

import java.io.EOFException;
import java.io.File;
import java.io.RandomAccessFile;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.vietspider.cache.InmemoryCache;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;
import org.vietspider.monitor.MenuInfo;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Nov 27, 2007  
 */
class MonitorReader {
  
  private InmemoryCache<String, MenuInfo> caches;
  
  public MonitorReader() {
    caches = new InmemoryCache<String, MenuInfo>("menu", 3);
    caches.setLiveTime(3*60);
  }

  String [] loadDate() {
    List<String> list = new ArrayList<String>(); 
    try {
      File folder = UtilFile.getFolder("content/summary/");
      File [] files = UtilFile.listFiles(folder);
      DateFormat folderDateFormat = CalendarUtils.getFolderFormat();
      DateFormat dateFormat = CalendarUtils.getDateFormat();
      for(File ele : files) {
        if(ele.isDirectory()) continue;
        Date date = folderDateFormat.parse(ele.getName());
        list.add(dateFormat.format(date));
      }
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
    return list.toArray(new String[list.size()]);
  }

  MenuInfo loadData(String date, boolean cache) {
    MenuInfo menuInfo = null;
    String cacheKey = date;
    if(cache) {
      menuInfo = caches.getCachedObject(cacheKey); 
      if(menuInfo != null ) return menuInfo.clone();
    }
    
    menuInfo = new MenuInfo();
    RandomAccessFile random = null;

    try {
      Date instanceDate = CalendarUtils.getDateFormat().parse(date);
      date = CalendarUtils.getFolderFormat().format(instanceDate);
      File file = UtilFile.getFile("content/summary/", date);
      random = new RandomAccessFile(file, "r");

      if(random == null) return menuInfo;
      while(random.getFilePointer() < random.length()) {
        String line = random.readUTF();
        int visit = random.readInt();
        int data = random.readInt();
        long link = random.readLong();
        menuInfo.add(line, visit, data, link, 0, 0);
      }
    } catch (EOFException e) {
      LogService.getInstance().setMessage(e, null);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    } finally {
      try {
        if(random != null) random.close();
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
    caches.putCachedObject(cacheKey, menuInfo);
    return menuInfo;
  }
}
