/***************************************************************************
 * Copyright 2001-2007 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.monitor;

import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.vietspider.bean.SourceMonitor;
import org.vietspider.common.Application;
import org.vietspider.common.io.DataOfDay;
import org.vietspider.common.io.LogService;
import org.vietspider.model.Source;
import org.vietspider.monitor.MenuInfo;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Nov 26, 2007  
 */
class SourceMonitorService extends Thread {
  
  private static final SourceMonitorService INSTANCE = new SourceMonitorService();

  public static final SourceMonitorService getInstance() { return INSTANCE; }
  
  private ConcurrentLinkedQueue<SourceMonitor> queueMonitors;
  private MonitorWriter writer;
  private MonitorReader reader;
  
  private boolean work = true;

  public SourceMonitorService() {
    queueMonitors = new ConcurrentLinkedQueue<SourceMonitor>();
    writer = new MonitorWriter();
    reader = new MonitorReader();
    
    Application.addShutdown(new Application.IShutdown() {
      public void execute() {
        work = false;
        synchronizeWriter();
        if(queueMonitors.size() > 0) {
          writer.putQueue(queueMonitors);
        }
        synchronizeWriter();
      }
    });

//    start();
  }

  public void run() {
    while(work) {
      synchronizeWriter();
      if(queueMonitors.size() > 0) {
        writer.putQueue(queueMonitors);
      }
      try {
        Thread.sleep(10*1000);
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }
    }
  }
  
  void synchronizeWriter() {
    synchronized (writer) {
      while(writer.isWriting()) {
        try {
          writer.wait();
        } catch (InterruptedException e) {
        }
      }
    }
  }

  void save(Source source, int link) {
    String sourceName = source.getFullName();
    String dateValue = DataOfDay.getDateValue();

    Iterator<SourceMonitor> iterator = queueMonitors.iterator();
    while(iterator.hasNext()) {
      SourceMonitor element = iterator.next();
      if(!element.getSource().equals(sourceName) 
          || !element.getDate().equals(dateValue) ) continue;
      element.setLinkCounter(element.getLinkCounter()+ link);
      return;
    }
    queueMonitors.add(new SourceMonitor(sourceName, dateValue, 0, link, 0, 0, 0));
  }

  void save(Source source, int link, int data) {
    String sourceName = source.getFullName();
    String dateFolder = DataOfDay.getDateValue();

    Iterator<SourceMonitor> iterator = queueMonitors.iterator();
    while(iterator.hasNext()) {
      SourceMonitor element = iterator.next();
      if(!element.getSource().equals(sourceName) 
          || !element.getDate().equals(dateFolder) ) continue;
      element.setLinkCounter(element.getLinkCounter()+ link);
      element.setDataCounter(element.getDataCounter()+ data);
      return;
    }
    queueMonitors.add(new SourceMonitor(sourceName, dateFolder, 0, link, data, 0, 0));
  }

  void save(Source source) {
    String sourceName = source.getFullName();
    String dateFolder = DataOfDay.getDateValue();

    Iterator<SourceMonitor> iterator = queueMonitors.iterator();
    while(iterator.hasNext()) {
      SourceMonitor element = iterator.next();
      if(!element.getSource().equals(sourceName) 
          || !element.getDate().equals(dateFolder) ) continue;
      element.setCrawlTime(element.getCrawlTime()+ 1);
      return;
    }
    queueMonitors.add(new SourceMonitor(sourceName, dateFolder, 1, 0, 0, 0, 0));
  }
  
 void save(String sourceName, String date, int data) {
    Iterator<SourceMonitor> iterator = queueMonitors.iterator();
    while(iterator.hasNext()) {
      SourceMonitor element = iterator.next();
      if(!element.getSource().equals(sourceName) 
          || !element.getDate().equals(date) ) continue;
      element.setDataCounter(element.getDataCounter() + data);
      return;
    }
    queueMonitors.add(new SourceMonitor(sourceName, date, 0, 0, data, 0, 0));
  }
  
  public String [] loadDate(){  return reader.loadDate(); }
  
  public MenuInfo loadData(String date, boolean cache) {
    return reader.loadData(date, cache);
  }
  
 /* public static void main(String[] args) {
    UtilFile.FOLDER_DATA = "D:\\Temp\\folder_data";
    SourceMonitorService service = new SourceMonitorService();
    
    for(int i = 0; i < 100; i++) {
      Source source = new Source();
      source.setName("aaa"+String.valueOf(i));
      source.setCategory("bbb");
      source.setGroup("ccc");
      
      service.save(source, 1);
    }
   
    Calendar calendar = Calendar.getInstance();
    calendar.set(Calendar.DATE, calendar.get(Calendar.DATE)-1);
    DateFormat dateFormat = CalendarUtils.getDateFormat();
    String dateValue = dateFormat.format(calendar.getTime());
    
    for(int i = 100; i < 110; i++) {
      Source source = new Source();
      source.setName("aaa"+String.valueOf(i));
      source.setCategory("bbb");
      source.setGroup("ccc");
      
      service.save(source.getFullName(), dateValue, 1);
    }
    
    
    calendar = Calendar.getInstance();
    calendar.set(Calendar.DATE, calendar.get(Calendar.DATE)+1);
    dateValue = dateFormat.format(calendar.getTime());
    
    for(int i = 110; i < 160; i++) {
      Source source = new Source();
      source.setName("aaa"+String.valueOf(i));
      source.setCategory("bbb");
      source.setGroup("ccc");
      
      service.save(source.getFullName(), dateValue, 1);
    }
    
    calendar = Calendar.getInstance();
    calendar.set(Calendar.DATE, calendar.get(Calendar.DATE)+2);
    dateValue = dateFormat.format(calendar.getTime());
    
    for(int i = 150; i < 200; i++) {
      Source source = new Source();
      source.setName("aaa"+String.valueOf(i));
      source.setCategory("bbb");
      source.setGroup("ccc");
      
      service.save(source.getFullName(), dateValue, 1);
    }
  }*/

}
