/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.io.monitor;

import java.io.EOFException;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.vietspider.bean.SourceMonitor;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 28, 2008  
 */
public class MonitorWriter implements Runnable {
  
  private ArrayList<SourceMonitor> monitors = new ArrayList<SourceMonitor>();
  private String date = null;
  
  private RandomAccessFile random = null;
  private String fileName = null;
  
  public synchronized void run() {
    write();
    if(monitors.size() > 0) {
      write();
      monitors.clear();
      date = null;
    }
    notifyAll();
  }
  
  boolean isWriting() { return monitors.size() > 1; }
  
  void putQueue(ConcurrentLinkedQueue<SourceMonitor> queue) {
    date = null;
    Iterator<SourceMonitor> iterator = queue.iterator();
    while(iterator.hasNext()) {
      SourceMonitor monitor = iterator.next();
      if(monitor == null) break;
      if(date == null) {
        date = monitor.getDate();
        monitors.add(monitor);
        iterator.remove();
      } else if (date.equals(monitor.getDate())) {
        monitors.add(monitor);
        iterator.remove();
      }      
    }
    new Thread(this).start();
  }
  
  private void write() {
    Date dateValue = null;
    try {
      dateValue = CalendarUtils.getDateFormat().parse(date);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
      return;
    }

    String name = CalendarUtils.getFolderFormat().format(dateValue);
    if(fileName == null || !fileName.equals(name)) {
      fileName = name;
      File file  = new File(UtilFile.getFolder("content/summary/"), name);
      try {
        if(!file.exists()) file.createNewFile();
        if(random != null) random.close();
        random = new RandomAccessFile(file, "rwd");
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
        return ;
      }
    }

    try {
      random.seek(0);
      try { 
        String line  = null;
        while((line = random.readUTF()) != null) {
          long start = random.getFilePointer();
          int visit = random.readInt();
          int data = random.readInt();
          long link = random.readLong();
          for(SourceMonitor monitor : monitors) {
            if(!line.equals(monitor.getSource())) continue;
            random.seek(start);
            random.writeInt(monitor.getCrawlTime() + visit);
            if(monitor.getDataCounter() + data < 1) {
              random.writeInt(0);
            } else {
              random.writeInt(monitor.getDataCounter() + data);  
            }
            random.writeLong(monitor.getLinkCounter() + link);
            monitors.remove(monitor);
            break;
          }
        }
      } catch (EOFException e) {
      } catch (Exception e) {
        LogService.getInstance().setThrowable(e);
      }

      for(SourceMonitor monitor : monitors) {
        long link = monitor.getLinkCounter();
        int data = monitor.getDataCounter();
        if(link < 1 && data < 1) continue;
        try {
          random.seek(random.length());
          random.writeUTF(monitor.getSource());
          random.writeInt(monitor.getCrawlTime());
          random.writeInt(data);
          random.writeLong(link);
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }
      }
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
  }
  
}
