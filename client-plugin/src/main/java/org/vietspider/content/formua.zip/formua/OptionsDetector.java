/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.formua;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.vietspider.browser.HttpSessionUtils;
import org.vietspider.common.io.PropertiesFile;
import org.vietspider.html.HTMLDocument;
import org.vietspider.html.HTMLNode;
import org.vietspider.html.Name;
import org.vietspider.html.NodeIterator;
import org.vietspider.html.parser.HTMLParser2;
import org.vietspider.model.plugin.formua.XMLForMuaConfig;
import org.vietspider.model.plugin.formua.XMLForMuaConfig.Category;
import org.vietspider.model.plugin.formua.XMLForMuaConfig.Option;
import org.vietspider.net.client.HttpMethodHandler;
import org.vietspider.net.client.WebClient;
import org.vietspider.token.attribute.Attribute;
import org.vietspider.token.attribute.Attributes;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 24, 2009  
 */
public class OptionsDetector {

  private XMLForMuaConfig config;

  private  WebClient webClient = new WebClient();

  private List<Category> categories = new ArrayList<Category>();
  private List<Option> regions = new ArrayList<Option>();
  
  private String urlService = "http://4mua.vn:81/services/get_by_category.php?category_id=";
  private String charset = "utf-8";

  public OptionsDetector(XMLForMuaConfig config) {
    this.config = config;
  }

  public void detect(String url) throws Exception {
    String homepage = config.getHomepage();
    String loginURL = config.getLoginAddress();

    String username = config.getUsername();
    String password = config.getPassword();
    
    webClient.setURL(homepage, new URL(homepage), false);
    
    HttpMethodHandler handler = new HttpMethodHandler(webClient);
    HttpSessionUtils httpSession = new HttpSessionUtils(handler, "Error");
    StringBuilder builder = new StringBuilder(loginURL).append('\n');
    builder.append(username).append(':').append(password);
    boolean login = httpSession.login(builder.toString(), "utf-8", new URL(homepage), homepage);
    if(!login) throw new Exception("Cann't login to website!");

    HTMLDocument document = new HTMLParser2().createDocument(get(url), "utf-8");
    NodeIterator iterator = document.getRoot().iterator();
    while(iterator.hasNext()) {
      HTMLNode node = iterator.next();
      if(!node.isNode(Name.SELECT)) continue;
      Attributes attributes = node.getAttributes(); 
      Attribute attribute = attributes.get("name");
      if(attribute == null) continue;
      if("cbo_category".equalsIgnoreCase(attribute.getValue())) {
        detectCategories(node);
      } else if("cbo_zone".equalsIgnoreCase(attribute.getValue())) {
        detectRegions(node);
      }
    }
  }

  private void detectRegions(HTMLNode root) {
    NodeIterator iterator = root.iterator();
    while(iterator.hasNext()) {
      HTMLNode node = iterator.next();
      if(!node.isNode(Name.OPTION)) continue;
      
      Option option = createOption(node);
      if(option == null) continue;
      regions.add(option);
    }
  }
  
  private void detectCategories(HTMLNode root) throws Exception {
    NodeIterator iterator = root.iterator();
    while(iterator.hasNext()) {
      HTMLNode node = iterator.next();
      if(!node.isNode(Name.OPTION)) continue;
      
      Option option = createOption(node);
      if(option == null) continue;
      Category category = new Category(option);      
      category.setSubOptions(detectOptions(category, "model"));
      category.setPurposes(detectOptions(category, "need"));
      categories.add(category);
    }
  }
  
  private Option createOption(HTMLNode node) {
    if(node.getChildren().size() < 1) return null;
    Attributes attributes = node.getAttributes(); 
    Attribute attr = attributes.get("value");
    if(attr == null) return null;
    String id = attr.getValue();
    String name = node.getChild(0).getTextValue().trim();
    if(name.charAt(0) == '(') return null;
    return new Option(id, name);
  }
  
  private List<Option> detectOptions(Category category, String type) throws Exception {
    String url = urlService+category.getId()+"&type="+type;
    String value  = new String(get(url), charset);
//    System.out.println("url + "+ url);
//    System.out.println("value na "+ value);
    
    return parseJSon(value);
  }
  
  private static List<Option> parseJSon(String value) {
    List<Option> options = new ArrayList<Option>();
    int start = value.indexOf('[');
    int end = value.indexOf(']');
    if(start < 0 || end < 0) return options;
    value  = value.substring(start+1, end);
    start = 0;
    end = 0;
    while(true) {
      start = value.indexOf('{', end);
      if(start < 0) break;
      end = value.indexOf('}', start);
      if(end < 0) break;
      String json = value.substring(start+1, end);
      String [] elements = json.split(",");
      if(elements.length < 2) continue;
      String keyData  = parseValue(elements[0]);
      String valueData  = parseValue(elements[1]);
      if(keyData == null || valueData == null) continue;
      valueData = PropertiesFile.convert(valueData);
      options.add(new Option(keyData, valueData));
    }
    
    return options;
  }
  
  private static String parseValue(String data) {
    int start = data.indexOf(':');
    if(start < 0) return null;
    data = data.substring(start+1).trim();
    if(data.charAt(0) == '\"') data = data.substring(1);
    if(data.charAt(data.length()-1) == '\"') {
      data = data.substring(0, data.length()-1);
    }
    return data;
  }

  public List<Category> getCategories() { return categories; }
  
  public List<Option> getRegions() { return regions; }

  public byte[] get(String url) throws Exception{
    HttpMethodHandler httpMethod = new HttpMethodHandler(webClient);
    HttpResponse response = httpMethod.execute(url, config.getLoginAddress());
    if(response == null) throw new Exception("No response!");

    StatusLine statusLine = response.getStatusLine();
    int statusCode = statusLine.getStatusCode();

    switch (statusCode) {
    case HttpStatus.SC_NOT_FOUND:
    case HttpStatus.SC_NO_CONTENT:
    case HttpStatus.SC_BAD_REQUEST:
    case HttpStatus.SC_REQUEST_TIMEOUT:
    case HttpStatus.SC_NOT_ACCEPTABLE:
    case HttpStatus.SC_SERVICE_UNAVAILABLE:
    case 999:{
      throw new Exception(url + " " + statusLine.getReasonPhrase());
    }
    default:
      break;
    }

    byte [] data = httpMethod.readBody();
    return data;
  }


  public static void main(String[] args) {
    String value = "{\"items\":[{\"key\":47,\"value\":\"C\u1ea7n b\u00e1n\"},{\"key\":48,\"value\":\"C\u1ea7n mua\"},{\"key\":49,\"value\":\"C\u1ea7n thu\u00ea\"},{\"key\":66,\"value\":\"Cho thu\u00ea\"},{\"key\":67,\"value\":\"Kh\u00e1c\"}]}";
    parseJSon(value);
  }

}
