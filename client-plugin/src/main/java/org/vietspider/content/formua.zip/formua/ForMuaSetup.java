/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.formua;

import java.util.List;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.common.Application;
import org.vietspider.common.Install;
import org.vietspider.common.io.GZipIO;
import org.vietspider.common.util.Worker;
import org.vietspider.model.plugin.formua.XMLForMuaConfig;
import org.vietspider.net.server.URLPath;
import org.vietspider.serialize.Bean2XML;
import org.vietspider.serialize.XML2Bean;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.services.ClientRM;
import org.vietspider.ui.widget.ApplicationFactory;
import org.vietspider.ui.widget.ShellGetter;
import org.vietspider.ui.widget.ShellSetter;
import org.vietspider.ui.widget.UIDATA;
import org.vietspider.ui.widget.waiter.ThreadExecutor;
import org.vietspider.ui.widget.waiter.WaitLoading;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 15, 2008  
 */
class ForMuaSetup {

 // user: vietspider; pass: abc123; url: http://4mua.vn/admin_post/
//  http://4mua.vn:81/services/get_by_category.php?category_id=1&type=model
  private Shell shell;

  private Text txtHomepage;
  private Text txtPostAddress;
  private Text txtCharset;
  private Text txtLogin;

  private Text txtUsername;
  private Text txtPassword;

  private Button butAlertWhenComplete;
  private Button butAutoSync;
  
  protected TabFolder tab;
  
  private XMLForMuaConfig config;

  private Button butOk ;

  ForMuaSetup(Shell parent) {
    shell = new Shell(parent, SWT.TITLE | SWT.RESIZE | SWT.APPLICATION_MODAL);
    ApplicationFactory factory = new ApplicationFactory(shell, "ForMuaSyncArticle", getClass().getName());
    shell.setText(factory.getLabel("title"));
    factory.setComposite(shell);
    shell.setLayout(new GridLayout(2, false));

    GridData gridData;

    tab = new TabFolder(shell, SWT.TOP);
    tab.setFont(UIDATA.FONT_10);
    gridData = new GridData(GridData.FILL_BOTH);     
    gridData.grabExcessHorizontalSpace = true;
    gridData.horizontalSpan = 3;
    tab.setLayoutData(gridData);

    TabItem tabItem;

    Composite commonConfig = new Composite(tab, SWT.NONE);
    tabItem = new TabItem(tab, SWT.NONE);
    tabItem.setText("Common Config");
    tabItem.setControl(commonConfig);

    commonConfig.setLayout(new GridLayout(2, false));
    factory.setComposite(commonConfig);

    factory.createLabel("lblHomepage");  
    txtHomepage = factory.createText();
    txtHomepage.setFont(UIDATA.FONT_10);
    gridData = new GridData(GridData.FILL_HORIZONTAL);   
    txtHomepage.setLayoutData(gridData);  
    txtHomepage.setText("http://4mua.vn/");

    // login config
    
    factory.createLabel("lblLogin");  
    txtLogin = factory.createText();
    txtLogin.setFont(UIDATA.FONT_10);
    gridData = new GridData(GridData.FILL_HORIZONTAL);   
    txtLogin.setLayoutData(gridData); 
    txtLogin.setText("http://4mua.vn/sign_in/");
    
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    gridData.horizontalSpan = 2;
    Group userGroup = factory.createGroup("", gridData, new GridLayout(2, false));
    factory.setComposite(userGroup);
    
    factory.setComposite(userGroup);

    Composite composite = new Composite(userGroup, SWT.NONE);
    composite.setLayout(new GridLayout(2, false));
    factory.setComposite(composite);

    factory.createLabel("lblUsername");   
    txtUsername = factory.createText();
    gridData = new GridData();
    gridData.widthHint = 120;
    txtUsername.setLayoutData(gridData);
    txtUsername.setText("vietspider");

    composite = new Composite(userGroup, SWT.NONE);
    composite.setLayout(new GridLayout(2, false));
    factory.setComposite(composite);

    factory.createLabel("lblPassword");   
    txtPassword = factory.createText(SWT.BORDER | SWT.PASSWORD);
    gridData = new GridData(SWT.BORDER | SWT.PASSWORD);
    gridData.widthHint = 120;
    txtPassword.setLayoutData(gridData);
    txtPassword.setText("abc123");
    
    //end account input
    
    factory.setComposite(commonConfig);

    factory.createLabel("lblCharset");  
    txtCharset = factory.createText();
    txtCharset.setFont(UIDATA.FONT_10);
    gridData = new GridData();
    gridData.widthHint = 50;
    txtCharset.setLayoutData(gridData);
    txtCharset.setText("utf-8");

    factory.createLabel("lblPostAddress");  
    txtPostAddress = factory.createText();
    txtPostAddress.setFont(UIDATA.FONT_10);
    gridData = new GridData(GridData.FILL_HORIZONTAL);   
    txtPostAddress.setLayoutData(gridData); 
    txtPostAddress.setText("http://4mua.vn/admin_post/");
    
    GridLayout gridLayout = new GridLayout(4, false);
    Group groupAutoSync = factory.createGroup("", new GridData(), gridLayout);
    factory.setComposite(groupAutoSync);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    gridData.horizontalSpan = 2;
    groupAutoSync.setLayoutData(gridData);

    butAutoSync = factory.createButton(SWT.CHECK, factory.getLabel("butAutoSync"));
    butAutoSync.setSelection(true);
    butAutoSync.setEnabled(Application.LICENSE != Install.PERSONAL);
    
    butAlertWhenComplete = factory.createButton(SWT.CHECK, factory.getLabel("butAlertWhenComplete"));
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    gridData.horizontalSpan = 2;
    butAlertWhenComplete.setLayoutData(gridData);
    butAlertWhenComplete.setSelection(true);

    Composite bottom = new Composite(shell, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    gridData.horizontalSpan = 2;
    bottom.setLayoutData(gridData);
    RowLayout rowLayout = new RowLayout();
    bottom.setLayout(rowLayout);
    rowLayout.justify = true;

    factory.setComposite(bottom);
    
    factory.createButton("butClear", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        clear() ;
      }   
    }); 

    butOk = factory.createButton("butOk", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        if(!check()) return;
        createConfig();
//        if(getCategoriesData().length < 1) {
        detectCategories();
//        } else {
//          saveConfig() ;
//        }
      }   
    }); 
    
    factory.createButton("butClose", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        new ShellSetter(ForMuaSetup.this.getClass(), shell);
        shell.close();
      }   
    });

    loadConfig();

    Rectangle displayRect = UIDATA.DISPLAY.getBounds();
    int x = (displayRect.width - 350) / 2;
    int y = (displayRect.height - 300)/ 2;
    shell.setImage(parent.getImage());
    new ShellGetter(ForMuaSetup.class, shell, 550, 350, x, y);
    shell.open();
  }

  private void loadConfig() {
    Worker excutor = new Worker() {

      private String error = null;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
      }

      public void execute() {
        try {
          Header [] headers = new Header[] {
              new BasicHeader("zip", "true"),
              new BasicHeader("action", "load.file"),
              new BasicHeader("file", "system/plugin/formua.config")
          };

          ClientConnector2 connector = ClientConnector2.currentInstance();
          byte [] bytes = connector.post(URLPath.FILE_HANDLER, new byte[0], headers);
          bytes = new GZipIO().unzip(bytes);

          config = XML2Bean.getInstance().toBean(XMLForMuaConfig.class, bytes);
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(shell, new Exception(error));
          return;
        }
        if(config == null) return;
        txtHomepage.setText(config.getHomepage());
        txtLogin.setText(config.getLoginAddress());
        txtCharset.setText(config.getCharset());
        txtPostAddress.setText(config.getPostAddress());

        txtUsername.setText(config.getUsername());
        txtPassword.setText(config.getPassword());

        butAlertWhenComplete.setSelection(config.isAlertMessage());
        butAutoSync.setSelection(config.isAuto());
      }
    };
    new ThreadExecutor(excutor, txtHomepage).start();
  }

  private void saveConfig() {
    butOk.setEnabled(false);
    Worker excutor = new Worker() {

      private String error = null;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {

      }

      public void execute() {
        if(config == null) return;
        try {
          Bean2XML bean2XML = Bean2XML.getInstance();
          String xml = bean2XML.toXMLDocument(config).getTextValue();


          Header [] headers =  new Header[] {
              new BasicHeader("action", "save"),
              new BasicHeader("file", "system/plugin/formua.config")
          };

          ClientConnector2 connector = ClientConnector2.currentInstance();
          byte [] bytes = xml.getBytes(Application.CHARSET);
          connector.post(URLPath.FILE_HANDLER, bytes, headers);
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(shell, new Exception(error));
          return;
        }
        shell.close();
      }
    };
    new ThreadExecutor(excutor, txtHomepage).start();
  }

  private void detectCategories() {
    if(!check()) return;
    
    Worker excutor = new Worker() {

      private String error = null;
      private OptionsDetector detector;
      
      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
        detector = new OptionsDetector(config);
      }

      public void execute() {
        try {
          detector.detect(config.getPostAddress());
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(shell, new Exception(error));
          return;
        }
        List<XMLForMuaConfig.Category> categories = detector.getCategories();
        config.setCategories(categories.toArray(new XMLForMuaConfig.Category[categories.size()]));
        List<XMLForMuaConfig.Option> regions = detector.getRegions();
        config.setRegions(regions.toArray(new XMLForMuaConfig.Option[regions.size()]));
        
        if(categories.size()< 1) {
          Exception exception = new Exception("Warning: No categories from server. Try again.");
          ClientLog.getInstance().setMessage(shell, exception);
          return;
        }
        saveConfig();
      }
    };
    
    WaitLoading loading = new WaitLoading(txtHomepage, excutor);
    loading.open();
  }
  
  private void clear() {
    txtHomepage.setText("");
    txtLogin.setText("");
    txtCharset.setText("utf-8");
    txtPostAddress.setText("");
    
    txtUsername.setText("");
    txtPassword.setText("");
    
    butAutoSync.setSelection(false);
    butAlertWhenComplete.setSelection(true);
    
  }
  
  public boolean check(){
    ClientRM resources = new ClientRM("JoomlaSyncArticle");
    Text [] texts = new Text[] {
        txtHomepage, txtLogin, txtPostAddress, txtCharset, txtUsername, txtPassword
        
    };
    String [] labels = new String[]{
        "Homepage", "Login", "PostAddress", "Charset", "Username", "Password"
        
    };
    for(int i = 0; i < labels.length; i++) {
      if(!check(resources, texts[i], labels[i])) return false; 
    }
    
    return true;
  }   
  
  private boolean check(ClientRM resources, Text text, String label) {
    String value = text.getText().trim();
    if(value.length() == 0){
      String message = resources.getLabel(getClass().getName()+".msgErrorEmpty" + label);
      ClientLog.getInstance().setMessage(shell, new Exception(message));
      return false;
    }
    return true;
  }
  
  private void createConfig() {
    config = new XMLForMuaConfig();
    config.setHomepage(txtHomepage.getText());
    config.setLoginAddress(txtLogin.getText());
    config.setPostAddress(txtPostAddress.getText());
    
    config.setUsername(txtUsername.getText());
    config.setPassword(txtPassword.getText());
    
    config.setAuto(butAutoSync.getSelection());
    config.setAlertMessage(butAlertWhenComplete.getSelection());
  }


}
