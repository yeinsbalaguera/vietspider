/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.formua;

import java.util.HashMap;

import org.eclipse.swt.widgets.Combo;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 2, 2009  
 */
class ContentUtils {
  
  static String cleanData(String text) {
    StringBuilder builder = new StringBuilder();
    
    String [] elements = text.split("\n");
    for(int i = 0; i < elements.length; i++) {
//      if(elements[i].trim().isEmpty()) continue;
      String lower = elements[i].toLowerCase(); 
      if(lower.startsWith("ngày đăng") 
          || lower.indexOf("lượt xem") > -1) continue;
      if(builder.length() > 0) builder.append('\n');
      builder.append(elements[i]);
    }
    
    return builder.toString();
  }
  
 private static HashMap<String,String[]> regions = new HashMap<String, String[]>();
  
  static {
    regions.put("hà nội", new String[]{"hn"});
    regions.put("tp hcm", new String[]{"hcm","sài gòn", "hồ chí minh"});
    regions.put("tt huế", new String[]{"huế", "thừa thiên"});
    regions.put("br - vt", new String[]{"bà rịa", "vũng tàu"});
  }
  
  static void searchRegion(Combo cboRegions, String text) {
    String [] items = cboRegions.getItems();
    for(int i = 0; i < items.length; i++) {
      String value = items[i].toLowerCase().trim();
      int index = text.indexOf(value);
      
      if(index < 0) {
        String [] maps = regions.get(value);
        if(maps != null) {
          for(int k = 0; k < maps.length; k++) {
            index = text.indexOf(maps[k]);
            if(index > -1) break;
          }
        }
      }
      
      if(index < 0) continue;
      cboRegions.select(i);
      return;
    }
    
    if(cboRegions.getItemCount() > 0) cboRegions.select(0);
  }
   
  private static HashMap<String,String[]> purposes = new HashMap<String, String[]>();
  
  static {
    purposes.put("cần bán", new String[]{"bán","thanh lý"});
    purposes.put("cần mua", new String[]{"mua"});
    purposes.put("sửa chữa", new String[]{"sửa"});
  }
  
  static void searchPurpose(Combo cboPurpose, String text) {
    String [] items = cboPurpose.getItems();
    for(int i = 0; i < items.length; i++) {
      String value = items[i].toLowerCase().trim();
      int index = text.indexOf(value);
      
      if(index < 0) {
        String [] maps = purposes.get(value);
        if(maps != null) {
          for(int k = 0; k < maps.length; k++) {
            index = text.indexOf(maps[k]);
            if(index > -1) break;
          }
        }
      }
      
      if(index < 0) continue;
      cboPurpose.select(i);
      return;
    }
    if(cboPurpose.getItemCount() > 0) cboPurpose.select(0);
  }
  
}
