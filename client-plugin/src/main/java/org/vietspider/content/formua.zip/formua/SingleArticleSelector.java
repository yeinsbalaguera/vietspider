package org.vietspider.content.formua;

import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.forms.widgets.Section;
import org.vietspider.model.plugin.formua.ForMuaSyncData;
import org.vietspider.model.plugin.formua.XMLForMuaConfig.Category;
import org.vietspider.model.plugin.formua.XMLForMuaConfig.Option;
import org.vietspider.ui.widget.ApplicationFactory;
import org.vietspider.ui.widget.UIDATA;

public class SingleArticleSelector extends Composite {

  private Combo cboCategories;
  private Combo cboSubCategories;
  private Combo cboPurposes;
  private Combo cboRegions;

  private Button butTitle;
  private Text txtValue;

  private Category [] categories;
  private Option [] regions;
  
  private String articleId;
  private int index;
  private Section section;
  
  private boolean isShowMessage = true;
  
  public SingleArticleSelector(ApplicationFactory factory, int index) {
    super(factory.getComposite(), SWT.NONE);
    this.index = index;

    GridLayout gridLayout = new GridLayout(1, false);
    setLayout(gridLayout);

    GridData gridData;
    
    section = new Section(this, Section.TWISTIE  | Section.EXPANDED);
    
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    section.setLayoutData(gridData);
    section.setFont(UIDATA.FONT_8TB);

    Composite group = new Composite(section, SWT.NONE);
    gridLayout = new GridLayout(4, false);
    group.setLayout(gridLayout);
    gridData = new GridData(GridData.FILL_BOTH);
    group.setLayoutData(gridData);
    section.setClient(group);
//    group.setText("Content " + String.valueOf(index));
    
    Composite categoriesComposite = new Composite(group, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    categoriesComposite.setLayoutData(gridData);
    gridLayout = new GridLayout(2, false);
    categoriesComposite.setLayout(gridLayout);
    factory.setComposite(categoriesComposite);

    cboCategories = createSelector(factory, "lblCategories");
    cboCategories.setVisibleItemCount(10);
    cboCategories.addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent event) {
        selectCategory();
      }
    });

    Composite subCategoriesComposite = new Composite(group, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    subCategoriesComposite.setLayoutData(gridData);
    gridLayout = new GridLayout(2, false);
    subCategoriesComposite.setLayout(gridLayout);
    factory.setComposite(subCategoriesComposite);
    cboSubCategories = createSelector(factory, "lblSubCategories");

    Composite purposeComposite = new Composite(group, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    purposeComposite.setLayoutData(gridData);
    gridLayout = new GridLayout(2, false);
    purposeComposite.setLayout(gridLayout);
    factory.setComposite(purposeComposite);    
    cboPurposes = createSelector(factory, "lblPurpose");

    Composite regionComposite = new Composite(group, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    regionComposite.setLayoutData(gridData);
    gridLayout = new GridLayout(2, false);
    regionComposite.setLayout(gridLayout);
    factory.setComposite(regionComposite);  
    cboRegions= createSelector(factory, "lblRegions");
    cboRegions.setVisibleItemCount(10);

    factory.setComposite(group);
    txtValue = factory.createText(SWT.BORDER | SWT.MULTI | SWT.WRAP | SWT.V_SCROLL);
    gridData = new GridData(GridData.FILL_BOTH);
    gridData.horizontalSpan = 4;
    gridData.heightHint = 150;
    txtValue.setLayoutData(gridData);
    txtValue.addModifyListener(new ModifyListener() {

      @Override
      @SuppressWarnings("unused")
      public void modifyText(ModifyEvent arg0) {
        String lower = txtValue.getText().toLowerCase();
        ContentUtils.searchRegion(cboRegions, lower);
        ContentUtils.searchPurpose(cboPurposes, lower);
      }
    });
    
    butTitle = new Button(section, SWT.CHECK);
    butTitle.setSelection(true);
    gridData = new GridData(GridData.FILL_HORIZONTAL | GridData.HORIZONTAL_ALIGN_END);
    gridData.horizontalSpan = 4;
    butTitle.setLayoutData(gridData);
    butTitle.setText("Post to 4Mua?");
    butTitle.setFont(UIDATA.FONT_8TB);
    section.setTextClient(butTitle);
  }

  private Combo createSelector(ApplicationFactory factory, String label) {
    factory.createLabel(label);  
    Combo cbo = factory.createCombo(SWT.BORDER);
    cbo.setFont(UIDATA.FONT_10);
    GridData gridData = new GridData(GridData.FILL_HORIZONTAL);   
    cbo.setLayoutData(gridData);
    return cbo;
  }

  public boolean enableSelection() {  return true; }

  public void setCategories(Category[] categories, Option [] regions) {
    this.categories = categories;
    this.regions = regions;
    
    for(Category category : categories) {
      cboCategories.add(category.getName());
    }
    if(categories.length > 0) cboCategories.select(0);
    selectCategory();
    
    for(Option region : regions) {
      cboRegions.add(region.getName()); 
    }
    String lower = txtValue.getText().toLowerCase();
    ContentUtils.searchRegion(cboRegions, lower);
  }
  
  private void selectCategory() {
    if(categories == null) return;
    int idx = cboCategories.getSelectionIndex();
    if(idx < 0) return;
    
    Category category = categories[idx];
    List<Option> subCategories = category.getSubOptions();
    cboSubCategories.removeAll();
    
    for(int i = 0; i < subCategories.size(); i++) {
      cboSubCategories.add(subCategories.get(i).getName());
    }
    if(subCategories.size() > 0) cboSubCategories.select(0);
    
    List<Option> purposes = category.getPurposes();
    cboPurposes.removeAll();
    for(int i = 0; i < purposes.size(); i++) {
      cboPurposes.add(purposes.get(i).getName());
    }
    if(purposes.size() > 0) cboPurposes.select(0);
    
    String lower = txtValue.getText().toLowerCase();
    ContentUtils.searchPurpose(cboPurposes, lower);
  }
  
  void setArticle(String id, String title) {
    this.articleId = id;
    section.setText(String.valueOf(index)+". " + title);
    section.setExpanded(false);
    butTitle.setEnabled(id != null && id.trim().length() > 0);
    butTitle.setSelection(true);
    cboCategories.setEnabled(id != null && id.trim().length() > 0);
    cboSubCategories.setEnabled(id != null && id.trim().length() > 0);
    cboRegions.setEnabled(id != null && id.trim().length() > 0);
    cboPurposes.setEnabled(id != null && id.trim().length() > 0);
    txtValue.setEnabled(id != null && id.trim().length() > 0);
    
    section.setTitleBarForeground(new Color(getDisplay(), 0, 0, 0));
    section.setExpanded(true);
    
    if(articleId == null || articleId.trim().isEmpty()) return;
    new LoadContentWorker(articleId, txtValue);
  }
  
  ForMuaSyncData getSyncData() {
    if(!butTitle.isEnabled()) return null;
    if(!butTitle.getSelection()) return null;

    ForMuaSyncData syncData = new ForMuaSyncData();
    syncData.setArticleId(articleId);
    
    int idx = cboCategories.getSelectionIndex();
    if(idx < 0) return null;
    Category category = categories[idx];
    syncData.setCategoryId(category.getId());
    
    idx = cboSubCategories.getSelectionIndex();
    if(idx < 0) return null;
    syncData.setSubCategoryId(category.getSubOptions().get(idx).getId());
    
    idx = cboPurposes.getSelectionIndex();
    if(idx < 0) return null;
    syncData.setPurpose(category.getPurposes().get(idx).getId());
    
    idx = cboRegions.getSelectionIndex();
    if(idx < 0) return null;
    syncData.setRegion(regions[idx].getId());
    
    syncData.setShowMessage(isShowMessage);
    syncData.setContent(txtValue.getText());
    
    butTitle.setEnabled(false);
    return syncData;
  }

  void setShowMessage(boolean isShowMessage) {
    this.isShowMessage = isShowMessage;
  }


}
