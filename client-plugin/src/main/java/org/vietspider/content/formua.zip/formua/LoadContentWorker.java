/***************************************************************************
 * Copyright 2001-2009 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.formua;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.eclipse.swt.widgets.Text;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.common.Application;
import org.vietspider.common.util.Worker;
import org.vietspider.net.server.URLPath;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * May 2, 2009  
 */
class LoadContentWorker  extends Worker {
  
  private String metaId;   
  private String error = null;
  private String content = "";
  private Text txtValue;
  
  LoadContentWorker(String metaId, Text txtValue) {
    this.metaId = metaId;
    this.txtValue = txtValue;
    
    new ThreadExecutor(this, txtValue).start();
  }

  public void abort() {
    ClientConnector2.currentInstance().abort();
  }

  public void before() {}

  public void execute() {
    try {
      Header [] headers = new Header[] {
          new BasicHeader("action", "load.content"),
          new BasicHeader("plugin.name", "4mua.sync.article.plugin")
      };
      
      ClientConnector2 connector = ClientConnector2.currentInstance();
      byte [] bytes = metaId.getBytes();
      bytes = connector.post(URLPath.DATA_PLUGIN_HANDLER, bytes, headers);

      content = new String(bytes, Application.CHARSET);
      if(content.startsWith("Error")) {
        error = content;
        content = "";
      } else {
        content = ContentUtils.cleanData(content);
      }
      
    } catch (Exception e) {
      error = e.toString();
    }
  }

  public void after() {
    if(error != null && !error.isEmpty()) {
      ClientLog.getInstance().setMessage(txtValue.getShell(), new Exception(error));
      return;
    }
    txtValue.setText(content);
  }

  
}
