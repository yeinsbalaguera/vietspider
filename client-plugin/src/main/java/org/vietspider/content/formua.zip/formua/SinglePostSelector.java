/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.formua;

import java.util.List;
import java.util.prefs.Preferences;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.common.io.GZipIO;
import org.vietspider.common.util.Worker;
import org.vietspider.content.cms.CMSChannelSelector;
import org.vietspider.content.cms.sync.SyncManager2;
import org.vietspider.model.plugin.formua.ForMuaSyncData;
import org.vietspider.model.plugin.formua.XMLForMuaConfig;
import org.vietspider.model.plugin.formua.XMLForMuaConfig.Category;
import org.vietspider.model.plugin.formua.XMLForMuaConfig.Option;
import org.vietspider.net.server.URLPath;
import org.vietspider.serialize.XML2Bean;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.ApplicationFactory;
import org.vietspider.ui.widget.ShellGetter;
import org.vietspider.ui.widget.ShellSetter;
import org.vietspider.ui.widget.UIDATA;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 15, 2008  
 */
class SinglePostSelector {
  
  private Shell shell;
  
  private Combo cboCategories;
  private Combo cboSubCategories;
  private Combo cboPurposes;
  private Combo cboRegions;
  
  private Text txtValue;
  
  private XMLForMuaConfig config;
  
  private boolean destroy = false;
  
  protected String metaId;
  
  SinglePostSelector(Shell parent) {
    ApplicationFactory factory = new ApplicationFactory(parent, "ForMuaSyncArticle", getClass().getName());
    shell = new Shell(parent, SWT.TITLE | SWT.RESIZE | SWT.APPLICATION_MODAL);
    factory.setComposite(shell);
    shell.setText("4Mua Categories Selector");
    shell.setLayout(new GridLayout(4, false));
    
    GridLayout gridLayout;
    GridData gridData;
    
//    Group group = new Group(shell, SWT.NONE);
//    GridLayout gridLayout = new GridLayout(4, false);
//    group.setLayout(gridLayout);
//    GridData gridData = new GridData(GridData.FILL_HORIZONTAL);
//    group.setLayoutData(gridData);
    
    Composite categoriesComposite = new Composite(shell, SWT.NONE);
    gridData = new GridData();
    categoriesComposite.setLayoutData(gridData);
    gridLayout = new GridLayout(2, false);
    categoriesComposite.setLayout(gridLayout);
    factory.setComposite(categoriesComposite);
    
    cboCategories = createSelector(factory, "lblCategories");
    cboCategories.setVisibleItemCount(10);
    cboCategories.addSelectionListener(new SelectionAdapter() {
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent event) {
        selectCategory();
      }
    });
    
    Composite subCategoriesComposite = new Composite(shell, SWT.NONE);
    gridData = new GridData();
    subCategoriesComposite.setLayoutData(gridData);
    gridLayout = new GridLayout(2, false);
    subCategoriesComposite.setLayout(gridLayout);
    factory.setComposite(subCategoriesComposite);
    cboSubCategories = createSelector(factory, "lblSubCategories");
    
    Composite purposeComposite = new Composite(shell, SWT.NONE);
    gridData = new GridData();
    purposeComposite.setLayoutData(gridData);
    gridLayout = new GridLayout(2, false);
    purposeComposite.setLayout(gridLayout);
    factory.setComposite(purposeComposite);    
    cboPurposes = createSelector(factory, "lblPurpose");
    
    Composite regionComposite = new Composite(shell, SWT.NONE);
    gridData = new GridData();
    regionComposite.setLayoutData(gridData);
    gridLayout = new GridLayout(2, false);
    regionComposite.setLayout(gridLayout);
    factory.setComposite(regionComposite);  
    cboRegions= createSelector(factory, "lblRegions");
    cboRegions.setVisibleItemCount(10);
    
    factory.setComposite(shell);
    txtValue = factory.createText(SWT.BORDER | SWT.MULTI | SWT.WRAP | SWT.V_SCROLL);
    gridData = new GridData(GridData.FILL_BOTH);
    gridData.horizontalSpan = 4;
    txtValue.setLayoutData(gridData);
    txtValue.addModifyListener(new ModifyListener() {

      @Override
      @SuppressWarnings("unused")
      public void modifyText(ModifyEvent arg0) {
        String lower = txtValue.getText().toLowerCase();
        ContentUtils.searchRegion(cboRegions, lower);
        ContentUtils.searchPurpose(cboPurposes, lower);
      }
      
    });
    
    final KeyAdapter keyAdapter = new KeyAdapter() {
      public void keyPressed(KeyEvent event) {
        if(event.keyCode == SWT.CR) sync();
      }
    };
    
    createButton(factory, keyAdapter);
    
    loadCategries();
  }
  
  protected void createButton(ApplicationFactory factory, KeyAdapter keyAdapter) {
    Composite bottom = new Composite(shell, SWT.NONE);
    GridData gridData = new GridData(GridData.FILL_HORIZONTAL);
    gridData.horizontalSpan = 4;
    bottom.setLayoutData(gridData);
    RowLayout rowLayout = new RowLayout();
    bottom.setLayout(rowLayout);
    rowLayout.justify = true;
    
    factory.setComposite(bottom);
    
    factory.createButton("butConfig", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        shell.setVisible(false);
        destroy = true;
        invokeSetup();
      }   
    }); 
    
    Button butOk = factory.createButton("butOk", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        sync();
      }   
    }); 
    butOk.addKeyListener(keyAdapter);
    
    Button button = factory.createButton("butClose", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        new ShellSetter(SinglePostSelector.this.getClass(), shell);
        Preferences prefs = Preferences.userNodeForPackage(CMSChannelSelector.class);
        shell.setVisible(false);
      }   
    });
    button.addKeyListener(keyAdapter);
    
    
    shell.setImage(shell.getShell().getImage());
    shell.addKeyListener(keyAdapter);
  }
  
  
  public void invokeSetup() {
    new ForMuaSetup(shell.getShell());
  }
  
  public void sync() {
    shell.setVisible(false);
    if(config == null) return;
    
    if(txtValue.getText().isEmpty()) {
      ClientLog.getInstance().setMessage(shell, new Exception("No content"));
      return;
    }
    
    ForMuaSyncData forMuaSyncData = new ForMuaSyncData();

    forMuaSyncData.setArticleId(metaId);
    
    int index = cboCategories.getSelectionIndex();
    if(index < 0) return;
    Category category = config.getCategories()[index];
    forMuaSyncData.setCategoryId(category.getId());
    
    index = cboSubCategories.getSelectionIndex();
    if(index < 0) return;
    forMuaSyncData.setSubCategoryId(category.getSubOptions().get(index).getId());
    
    index = cboPurposes.getSelectionIndex();
    if(index < 0) return;
    forMuaSyncData.setPurpose(category.getPurposes().get(index).getId());
    
    index = cboRegions.getSelectionIndex();
    if(index < 0) return;
    forMuaSyncData.setRegion(config.getRegions()[index].getId());
    
    forMuaSyncData.setContent(txtValue.getText());
    forMuaSyncData.setShowMessage(config.isAlertMessage());
    
    SyncManager2.getInstance(shell).sync(forMuaSyncData);
  }
  
  public void loadCategries() {
    Worker excutor = new Worker() {

      private String error = null;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
      }

      public void execute() {
        try {
          Header [] headers = new Header[] {
              new BasicHeader("zip", "true"),
              new BasicHeader("action", "load.file"),
              new BasicHeader("file", "system/plugin/formua.config")
          };
          
          ClientConnector2 connector = ClientConnector2.currentInstance();
          byte [] bytes = connector.post(URLPath.FILE_HANDLER, new byte[0], headers);
          bytes = new GZipIO().unzip(bytes);

          config = XML2Bean.getInstance().toBean(XMLForMuaConfig.class, bytes);
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(shell, new Exception(error));
          return;
        }
        if(config == null) return;
        
        Category [] categories = config.getCategories();
        for(Category category : categories) {
          cboCategories.add(category.getName());
        }
        if(categories.length > 0) cboCategories.select(0);
        selectCategory();
        
        Option [] regions = config.getRegions();
        for(Option region : regions) {
          cboRegions.add(region.getName()); 
        }
        String lower = txtValue.getText().toLowerCase();
        ContentUtils.searchRegion(cboRegions, lower);
        
        Rectangle displayRect = UIDATA.DISPLAY.getBounds();
        int x = (displayRect.width - 200) / 2;
        int y = (displayRect.height - 400)/ 2;
        new ShellGetter(SinglePostSelector.class, shell, 200, 150, x, y);
        shell.open();
      }
    };
    new ThreadExecutor(excutor, shell).start();
  }
  
  private Combo createSelector(ApplicationFactory factory, String label) {
    factory.createLabel(label);  
    Combo cbo = factory.createCombo(SWT.BORDER);
    cbo.setFont(UIDATA.FONT_10);
    GridData gridData = new GridData(GridData.FILL_HORIZONTAL);   
    cbo.setLayoutData(gridData);
    return cbo;
  }
  
  private void selectCategory() {
    if(config == null) return;
    int index = cboCategories.getSelectionIndex();
    if(index < 0) return;
    
    Category category = config.getCategories()[index];
    List<Option> subCategories = category.getSubOptions();
    cboSubCategories.removeAll();
    
    for(int i = 0; i < subCategories.size(); i++) {
      cboSubCategories.add(subCategories.get(i).getName());
    }
    if(subCategories.size() > 0) cboSubCategories.select(0);
    
    List<Option> purposes = category.getPurposes();
    cboPurposes.removeAll();
    for(int i = 0; i < purposes.size(); i++) {
      cboPurposes.add(purposes.get(i).getName());
    }
    if(purposes.size() > 0) cboPurposes.select(0);
    
    String lower = txtValue.getText().toLowerCase();
    ContentUtils.searchPurpose(cboPurposes, lower);
  }
  
  public void show() {
    shell.setVisible(true); 
    if(config == null) loadCategries();
  }

  public void dispose() { shell.dispose(); }
  
  public boolean isDestroy() { return destroy; }
  
  public void setMetaId(String metaId) { 
    this.metaId = metaId;
    new LoadContentWorker(metaId, txtValue);
  }
}
