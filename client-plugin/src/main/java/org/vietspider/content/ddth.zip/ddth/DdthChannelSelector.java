/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.content.ddth;

import java.io.File;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.vietspider.client.common.ClientConnector2;
import org.vietspider.client.common.PluginClientHandler;
import org.vietspider.common.Application;
import org.vietspider.common.io.DataWriter;
import org.vietspider.common.io.RWData;
import org.vietspider.common.util.Worker;
import org.vietspider.ui.services.ClientLog;
import org.vietspider.ui.widget.ApplicationFactory;
import org.vietspider.ui.widget.UIDATA;
import org.vietspider.ui.widget.waiter.ThreadExecutor;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Aug 15, 2008  
 */
class DdthChannelSelector {
  
  private Shell shell;

  private Button [] buttons;
  private Text txtThread;
  
  private String metaId;
  
  private String [] lblCategories = {"Tin tức CNTT", "Chat Chit", "Góc thư giãn", "Text", "Relation"};
  private String [] valueCategories = {"123", "85", "6", "-1", "-2"};
  
  DdthChannelSelector(Shell parent) {
    shell = new Shell(parent, SWT.TITLE | SWT.RESIZE | SWT.APPLICATION_MODAL);
    ApplicationFactory factory = new ApplicationFactory(shell, "DdthSyncArticle", getClass().getName());
    factory.setComposite(shell);
    shell.setLayout(new GridLayout(1, false));
    
    org.eclipse.swt.widgets.Group group ;
    factory.setComposite(shell);
    
    GridData gridData = new GridData(GridData.FILL_BOTH);
    GridLayout gridLayout = new GridLayout(5, false);
    group = factory.createGroup("grpChannel", gridData, gridLayout);
    factory.setComposite(group);
    
    buttons = new Button[lblCategories.length];
    for(int i = 0; i < buttons.length; i++) {
      buttons[i] = new Button(group, SWT.RADIO);
      buttons[i].setText(lblCategories[i]);
      buttons[i].setFont(UIDATA.FONT_9);
    }
    buttons[0].setSelection(true);
    
    txtThread = new Text(shell, SWT.SINGLE | SWT.BORDER);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
    txtThread.setLayoutData(gridData);
    txtThread.setFont(UIDATA.FONT_9);
    
    Composite imageComposite = new Composite(shell, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
//    gridData.horizontalSpan = 2;
    imageComposite.setLayoutData(gridData);
    RowLayout rowLayout = new RowLayout();
    imageComposite.setLayout(rowLayout);
    rowLayout.justify = true;
    factory.setComposite(imageComposite);
    
    Composite bottom = new Composite(shell, SWT.NONE);
    gridData = new GridData(GridData.FILL_HORIZONTAL);
//    gridData.horizontalSpan = 2;
    bottom.setLayoutData(gridData);
    rowLayout = new RowLayout();
    bottom.setLayout(rowLayout);
    rowLayout.justify = true;
    
    factory.setComposite(bottom);
    
    factory.createButton("butOk", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        for(int i = 0; i < buttons.length; i++) {
          if(!buttons[i].getSelection()) continue;
          synchronizedData(valueCategories[i]);
          break;
        }
      }   
    }); 
    
    factory.createButton("butClose", new SelectionAdapter(){
      @SuppressWarnings("unused")
      public void widgetSelected(SelectionEvent evt) {
        shell.setVisible(false);
      }   
    });
    
    shell.setSize(550, 150);
    Rectangle displayRect = UIDATA.DISPLAY.getBounds();
    int x = (displayRect.width - 350) / 2;
    int y = (displayRect.height - 300)/ 2;
    shell.setImage(parent.getImage());
    shell.setLocation(x, y);
    shell.open();
  }
  
  public void show() {  shell.setVisible(true);  }

  public void setMetaId(String metaId) { this.metaId = metaId; }
  
  private void synchronizedData(final String selectedChannel) {
    shell.setVisible(false);
    Worker excutor = new Worker() {

      private String error = null;
      private String value;

      public void abort() {
        ClientConnector2.currentInstance().abort();
      }

      public void before() {
        String thread = txtThread.getText().trim();
        if(thread.isEmpty() || !thread.toLowerCase().startsWith("http")) {
          value = metaId+"."+selectedChannel;
        } else {
          int idx = thread.lastIndexOf('=');
          if(idx > 0) thread = thread.substring(idx+1);
          value = metaId+".thread"+thread;
        }
      }

      public void execute() {
        try {
          PluginClientHandler handler = new PluginClientHandler();
          error = handler.send("ddth.sync.article.plugin", "send.article", value);
        } catch (Exception e) {
          error = e.toString();
        }
      }

      public void after() {
        if(error.startsWith("show ")) {
          String path = txtThread.getText();
          error = error.substring(5);
          if(path.trim().isEmpty()) {
            show(error);
          } else {
            File file  = new File(path);
            try {
              byte [] bytes =  ("\n"+error.trim()).getBytes(Application.CHARSET);
              RWData.getInstance().append(file, bytes);
            } catch (Exception e) {
              ClientLog.getInstance().setMessage(shell, e);
            }
          }
          return;
        }
        if (error != null && !error.isEmpty()) {
          ClientLog.getInstance().setMessage(shell, new Exception(error));
          return;
        }
      }
    };
    new ThreadExecutor(excutor, shell).start();
  }
  

  private void show(String value) {
    Shell txtShell = new Shell(shell, SWT.TITLE | SWT.RESIZE | SWT.APPLICATION_MODAL | SWT.CLOSE);
    txtShell.setLayout(new FillLayout());
    
    Text text = new Text(txtShell, SWT.BORDER | SWT.WRAP | SWT.V_SCROLL);
    text.setText(value);
    
    txtShell.setSize(550, 350);
    Rectangle displayRect = UIDATA.DISPLAY.getBounds();
    int x = (displayRect.width - 350) / 2;
    int y = (displayRect.height - 300)/ 2;    
    txtShell.setImage(shell.getImage());
    txtShell.setLocation(x, y);
    txtShell.open();
  }
}
