package org.vietspider.content.ddth;

import org.eclipse.swt.widgets.Control;
import org.vietspider.client.ClientPlugin;
import org.vietspider.ui.services.ClientRM;

/***************************************************************************
 * Copyright 2001-2008 The VietSpider         All rights reserved.  		 *
 **************************************************************************/

/**
 * Author : Nhu Dinh Thuan nhudinhthuan@yahoo.com Aug 13, 2008
 */

public class DdthSyncArticlePlugin extends ClientPlugin {

	private String label;
	private DdthChannelSelector selector;

	public DdthSyncArticlePlugin() {
		ClientRM resources = new ClientRM("DdthSyncArticle");
		label = resources.getLabel(getClass().getName() + ".itemSendContent");
		enable = true;
	}

	public String getConfirmMessage() { return null; }

  public String getLabel() { return label; }

  @Override
  public boolean isValidType(int type) { return type == CONTENT; }

	@Override
	public void invoke(Object... objects) {
		if (!enable || values == null || values.length < 1)	return;
		final Control link = (Control) objects[0];

		if(selector == null) {
		  selector = new DdthChannelSelector(link.getShell());
		} else {
	    selector.show();
		}
		selector.setMetaId(values[0]);
	}

}