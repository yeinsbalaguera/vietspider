/***************************************************************************
 * Copyright 2001-2011 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.solr2.rel;

import java.io.Serializable;

/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 19, 2011  
 */
public class RelModel implements Serializable {
  
  private static final long serialVersionUID = 10L;

  private Long storageId;
  private String id;
  private String rel;
  private String date;
  
  public RelModel() {
  }
  
  public RelModel(String id) {
    this.id = id;
  }
  
  public String getId() { return id; }
  public void setId(String id) { this.id = id; }
  
  public Long getStorageId() { return storageId; }
  public void setStorageId(Long storageId) { this.storageId = storageId; }

  public String getRel() { return rel; }
  public void setRel(String rel) { this.rel = rel; }

  public String getDate() { return date; }
  public void setDate(String date) { this.date = date; }
  
}
