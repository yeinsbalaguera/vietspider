/***************************************************************************
 * Copyright 2001-2011 The VietSpider         All rights reserved.  		 *
 **************************************************************************/
package org.vietspider.solr2.rel;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.vietspider.common.Application;
import org.vietspider.common.io.LogService;
import org.vietspider.common.io.UtilFile;
import org.vietspider.common.text.CalendarUtils;


/** 
 * Author : Nhu Dinh Thuan
 *          nhudinhthuan@yahoo.com
 * Feb 19, 2011  
 */
public class RelService extends Thread {

  private static RelService service;

  public synchronized final static RelService getInstance() {
    if(service == null) service = new RelService();
    return service;
  }

  private RelStorage storage;

  private volatile boolean execute = true;
  protected volatile java.util.Queue<RelModel> queue = new ConcurrentLinkedQueue<RelModel>();

  private RelService() {
    File file = new File(UtilFile.getFolder("content/solr2/rel/"), "data");
    try {
      storage = new RelStorage(file);
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
    if(storage != null) start();

    Application.addShutdown(new Application.IShutdown() {

      public String getMessage() { return "Close Duplicated Database";}

      public void execute() {
        execute = false;
        commit();
        try {
          if(storage != null) storage.close();
        } catch (Throwable e) {
          LogService.getInstance().setThrowable(e);
        }
      }
    });
  }

  public void run() {
    while(execute) {
      commit();
      try {
        Thread.sleep(15*1000l);
      } catch (Exception e) {
      }
    }
  }

  private void commit() {
    while(!queue.isEmpty()) {
      RelModel model = queue.poll();
      if(isDuplicate(model)) continue;
      
      //      System.out.println("save "+ model.getId());
      try {
        storage.write(model);
      } catch (Throwable e) {
        LogService.getInstance().setThrowable(e);
      }
    }

    try {
      if(storage.isCommit()) storage.commit();
    } catch (Throwable e) {
      LogService.getInstance().setThrowable(e);
    }

  }
  
  private boolean isDuplicate(RelModel model) {
    List<RelModel> list = storage.getById(model.getId());
    if(list == null) return false;
    for(int i = 0; i < list.size(); i++) {
      if(model.getRel().equals(list.get(i).getRel())) return true;
    }
    return false;
  }

  public void save(String id, String rel) {
    try {
      if(storage == null) return;
      RelModel model = new RelModel(id);
      model.setRel(rel);
      queue.add(model);
    } catch (Throwable e) {
      LogService.getInstance().setThrowable(e);
    }
    return;
  }

  public RelStorage getStorage() { return storage; }

  public void deleteExpire(int expireDate) {
    Calendar calendar = Calendar.getInstance();
    calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) - expireDate);
    SimpleDateFormat dateFormat = CalendarUtils.getDateFormat();
    for(int i = 0; i < 3; i++) {
      calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) - 1);
      storage.deleteExpire(dateFormat.format(calendar.getTime()));
    }
    
    try {
      storage.commit();
    } catch (Throwable e) {
      LogService.getInstance().setThrowable(e);
    }
    
    try {
      storage.defrag(null);
    } catch (Throwable e) {
      LogService.getInstance().setThrowable(e);
    }
  }

}
