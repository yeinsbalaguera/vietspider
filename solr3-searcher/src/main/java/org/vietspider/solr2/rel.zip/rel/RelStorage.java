package org.vietspider.solr2.rel;

import java.io.File;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;

import jdbm.PrimaryStoreMap;
import jdbm.RecordManager;
import jdbm.RecordManagerFactory;
import jdbm.SecondaryKeyExtractor;
import jdbm.SecondaryTreeMap;

import org.vietspider.common.io.LogService;

//http://code.google.com/p/jdbm2/

public class RelStorage {

  private final static int MAX_RECORD = 100;

  private RecordManager recman;
  private PrimaryStoreMap<Long, RelModel> main;

  private SecondaryTreeMap<String, Long, RelModel> idIndex;
  private SecondaryTreeMap<String, Long, RelModel> dateIndex;

  private long lastCommit = System.currentTimeMillis();
  private int counter = 0;
  //	
  private boolean defrag = false;

  public RelStorage(File file) throws Exception {
    recman = RecordManagerFactory.createRecordManager(file.getAbsolutePath());
    //class jdbm.helper.PrimaryStoreMapImpl
    main = recman.storeMap("rel");

    idIndex = main.secondaryTreeMap("idIndex",
        new SecondaryKeyExtractor<String, Long, RelModel>() {
      public String extractSecondaryKey(Long key, RelModel value) {
        return value.getId();
      }					
    });

    dateIndex = main.secondaryTreeMap("dateIndex",
        new SecondaryKeyExtractor<String, Long, RelModel>() {
      public String extractSecondaryKey(Long key, RelModel value) {
        return value.getDate();
      }         
    });
  }

  public long size() { return main.size(); }

  public List<RelModel> getById(String id) {
    Iterable<Long> iterable = idIndex.get(id);
    if(iterable == null) return null;
    Iterator<Long> keyIterator = iterable.iterator();
    List<RelModel> list = new ArrayList<RelModel>();
    while(keyIterator.hasNext()) {
      Long key = keyIterator.next();
      if(key == null) continue;
      RelModel model = main.get(key) ;
      if(model == null) continue;
      model.setStorageId(key);  
      list.add(model);
    }
    
    return list;
  }

  public void deleteExpire(String date) {
    deleteExpire(date, 0);
  }

  private void deleteExpire(String date, int time) {
    if(time >= 3) return;
    Iterable<Long> iterable = dateIndex.get(date);
    if(iterable == null) return;
    Iterator<Long> keyIterator = iterable.iterator();
    try {
      while(keyIterator.hasNext()) {
        Long key = keyIterator.next();
        if(key == null) continue;
//        NlpTptModel model = main.get(key) ;
//        if(model != null) {
//          System.out.println(model.getId() + " : "+ key);
//        }
        try {
          main.remove(key);
        } catch (Exception e) {
//          LogService.getInstance().setThrowable(e);
//          LogService.getInstance().setMessage(e, e.toString());
        }
        keyIterator.remove();
      }
    } catch (ConcurrentModificationException e) {
      deleteExpire(date, time+1);
    }
  }

  public List<RelModel> getByDate(String date) {
    return this.<String>get(date, dateIndex);
  }

  private <T> List<RelModel> get(String fieldValue, 
      SecondaryTreeMap<T, Long, RelModel> index) {
    List<RelModel> list = new ArrayList<RelModel>();

    Iterable<Long> iterable = index.get(fieldValue);
    if(iterable == null) return list;

    Iterator<Long> keyIterator = iterable.iterator();
    while(keyIterator.hasNext()) {
      Long key = keyIterator.next();
      if(key == null) continue;
      RelModel model = main.get(key);
      if(model == null) continue;
      model.setStorageId(key);
      list.add(model);
    }

    return list;
  }

  public void write(RelModel model) throws Throwable {
    try {
      main.putValue(model);
    } catch (Error e) {
      defrag(model);
      throw e;
    }
    counter++;
  }

  public void remove(RelModel model) throws Exception {
    if(model.getStorageId() == null) {
      throw new Exception ("Storage id not found!");
    }
    main.remove(model.getStorageId());
    counter++;
  }

  void commit() throws Throwable {
    //	  System.out.println("commit counter "+ counter);
    counter = 0; 
    recman.commit();
    lastCommit = System.currentTimeMillis();
  }

  void defrag(final RelModel model) {
    new Thread() {
      public void run() {
        defrag = true;
        try {
          recman.defrag();
        } catch (Exception e) {
          LogService.getInstance().setThrowable(e);
        }
        if(model != null)  main.putValue(model);
        defrag = false;
      }
    }.start();

  }

  boolean isCommit() {
    if(counter < 1 || defrag) return false;
    if(counter >= MAX_RECORD) return true;
    return System.currentTimeMillis() - lastCommit >= 15*60*1000l;
  }

  public void close() throws Exception {
    counter = 0; 
    try {
      recman.commit();
    } catch (Exception e) {
      LogService.getInstance().setThrowable(e);
    }
    recman.close();
  }

}
